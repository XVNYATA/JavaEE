package org.fkjava.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * LoginController
 * @author LEE.SIU.WAH
 * @email lixiaohua7@163.com
 * @date 2015年5月9日 下午5:04:17
 * @version 1.0
 * 
 * http://127.0.0.1:8080/springmvc/user/login1
 */
@Controller
@RequestMapping("/user")//看成struts2中命名空间  springmvc零配置   全部采用注解
public class Login1Controller {
	
	
	/** 配置请求URL映射     如果处理异步请求需要在方法上加上   @ResponseBody注解*/ 
	@RequestMapping(value="/login1", method={RequestMethod.POST, RequestMethod.GET})
	public String login1(User user,Model model){
		
		System.out.println(user + "=="+user.getName());
		/** 利用model来封装响应数据 */
		model.addAttribute("user", user);
		/** 返回一个jsp页面的文件名      /WEB-INF/bbb.jsp*/
		return "bbb";    
	}
	
}
