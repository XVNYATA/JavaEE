package org.fkjava.springmvc.controller;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * LoginController
 * @author LEE.SIU.WAH
 * @email lixiaohua7@163.com
 * @date 2015年5月9日 下午5:04:17
 * @version 1.0
 */
@Controller
@RequestMapping("/admin")  // namespaces 
public class LoginController {
	
	/** 配置请求URL映射     actionname   */
	@RequestMapping(value="/login", method={RequestMethod.POST, RequestMethod.GET})
	//@RequestParam("userId"):必须传递该参数  不传递会报错
	public String login(HttpServletRequest request,@RequestParam("userId") String userId, 
						@RequestParam("pwd") String pwd,Model model){
		System.out.println(userId + "==" + pwd);
		//获取参数的第二种方式
		//String name = request.getParameter("userId");
	
		
		/** 利用model来封装响应数据: 存放在model中的数据等价于存放在request中数据*/
		model.addAttribute("tip", userId + ", 您登录成功！");
		
		//farward   redirect
		/** 返回一个jsp页面的文件名 */
		//重定向  以及请求转发
		//return "forward:/user/login1";   
		//return "redirect:/user/login1";
		//跳转至页面     /WEB-INF/succ.jsp
		return "succ";
	}
	
}
