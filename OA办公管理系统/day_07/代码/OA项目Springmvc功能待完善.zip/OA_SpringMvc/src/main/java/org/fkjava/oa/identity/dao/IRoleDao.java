package org.fkjava.oa.identity.dao;

import java.util.List;

import org.fkjava.oa.identity.bean.Role;
import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.identity.dao.base.HibernateDao;
import org.fkjava.oa.util.webTage.PageModel;

public interface IRoleDao extends HibernateDao{

	//角色分页查询
	List<Role> selectRoleByPage(PageModel pageModel);

	//删除角色
	void deleteRoleByIds(String[] ids);

	//获取当前角色已绑定的用户
	List<User> findBindUserByRoleId(Long id, PageModel pageModel);

	 //获取当前角色未绑定的用户信息
	List<User> selectUnBindUserByRoleId(Long id,PageModel pageModel);

}
