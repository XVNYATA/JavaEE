package org.fkjava.oa.identity.action;


import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.identity.service.IdentityServiceI;
import org.fkjava.oa.util.CookieUtils;
import org.fkjava.oa.util.OAContant;
import org.fkjava.oa.util.webTage.PageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("/user")
public class UserAction{

	 @Autowired(required=true)
	 public IdentityServiceI identityService;

	 //多条件分页查询用户信息
	@RequestMapping("/selectUser.jspx")
	 public String selectUserByPage(User user,Model model,PageModel pageModel){ 
		 List<User> users = identityService.selectUserByPage(user,pageModel);
		 model.addAttribute("users", users);
		return "user/user"; 
	 }
	 
	 //添加用户
	@RequestMapping("/addUser.jspx")
	 public String addUser(User user,Model model,HttpServletRequest request){
		 try {
			 model.addAttribute("tip","添加成功！");
			 identityService.saveUser(user,request);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip","添加失败！");
		}
		 
		 return "user/addUser";
	 }
	 
	 //根据用户id获取用户信息
	 @RequestMapping("/showUpdateUser.jspx")
	 public String showUpdateUser(User user,Model model){
		 
		 user = identityService.findUserByName(user.getUserId());
		 model.addAttribute("user", user);
		 return "user/updateUser";
	 }
	 
	 
	 //修改用户
	 @RequestMapping("/updateUser.jspx")
	 public String updateUser(User user,Model model,HttpServletRequest request){
		 try {
			 model.addAttribute("tip","修改成功！");
			 identityService.updateUser(user,request);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip","修改失败！");
		}
		 
		 return "user/updateUser";
	 }
	 
	 
	 
	 //异步登录
	 @ResponseBody
	 @RequestMapping("/ajaxLogin.jspx")
	 public String ajaxLogin(HttpServletRequest request,HttpServletResponse response,String vcode,String userName,String key){
		 
		
		 //获取session中的验证码
		 String code = (String)request.getSession().getAttribute(OAContant.VCODE);
		 String tip = "";
		 try {
		 //判断验证码是否正确
		 if(!code.equals(vcode)){
			 tip = "您输入的验证码不正确，请核实！";
		 }else{
			 //根据登录名获取用户信息
			 User user = identityService.findUserByName(userName);
			 if(user!=null){
				 
				 //判断密码是否输入正确
				 //if(!user.getPassWord().equals(MD5.getMD5(password))){
				 if(false){
					 tip = "您输入密码不正确，请核实！";
				 }else{
					 //将用户信息存放在session中
					 request.getSession().setAttribute(OAContant.SESSION_USER, user);

					 //用户登录成功时，将用户的权限信息存放在session中
					 List<String> userOperas = identityService.findUsetOperasByUserId(userName);
					 request.getSession().setAttribute(OAContant.USER_POPEDOM, userOperas);
					//判断是否记住用户
					 if("1".equals(key)){
						 //将用户信息存放在cookie中    第一个参数：cookie名字   第二个参数：用户名（唯一）  第三个参数：单位 为秒   
						 CookieUtils.addCookie(OAContant.COOKNAME,userName,7 * 24 * 60 *60,response,request);
					 }
				 }
				 
			 }else{
				 tip = "您输入登录名不正确，请核实！";
			 }
		 }
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return tip;
	 }
	 
	 
	 //验证用户名是否存在
	 @ResponseBody
	 @RequestMapping("/validUserName.jspx")
	 public String validUserName(User user,String userName){
		 
		//根据用户名获取用户信息
		 user = identityService.findUserByName(userName);
		 if(user!=null){
			 try {
				return null;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 
		
		 return "您输入的用户名已存在请重新输入！";
	 }
	 
	 
	 //用户退出
	 @RequestMapping("/userLogout.jspx")
	 public String userLogout(HttpServletRequest request,HttpServletResponse response){
		 //将用户信息从session中清除
		 request.getSession().removeAttribute(OAContant.SESSION_USER);
		 //将用户信息从cookie中清除
		 CookieUtils.removeCookie(OAContant.COOKNAME,response,request);
		 return "login";
	 }
	 
	 //删除用户信息
	 @RequestMapping("/deleteUser.jspx")
	 public String deleteUser(String ids,Model model){
		 
		 try {
			 identityService.deleteByIds(ids.split(","));
			 model.addAttribute("tip","删除成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			 model.addAttribute("tip",e.getMessage());
		}
		 return "forward:/selectUser";
	 }
	 
	 //审核用户信息
	 @RequestMapping("/checkUser.jspx")
	 public String checkUser(String ids,Short status,Model model,HttpServletRequest request){
		 
		 try {
			
			 identityService.checkUserByIds(ids.split(","),status,request);
			 model.addAttribute("tip","审核成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
		 return "forward:/selectUser";
	 }
	 
	 //更新用户信息
	 @RequestMapping("/updateSelf.jspx")
	 public String updateSelf(User user,Model model){
		 
		 try {
			
			 identityService.updateSelf(user);
			 model.addAttribute("tip","更新成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
		 return "user/self";
	 }

	 
	 //展示个人信息
	 @RequestMapping("/showUserInfo.jspx")
	 public String showUserInfo(User user,Model model){
		 
		
		 return "user/self";
	 }
	
}
