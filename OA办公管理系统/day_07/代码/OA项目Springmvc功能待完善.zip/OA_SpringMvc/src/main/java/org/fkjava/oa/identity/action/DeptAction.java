package org.fkjava.oa.identity.action;

import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import org.fkjava.oa.identity.service.IdentityServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("/dept")
public class DeptAction{

	 @Autowired(required=true)
	 private IdentityServiceI identityService;
	 
	 //获取部门信息
	 @ResponseBody
	 @RequestMapping(value="/ajaxLoadDept.jspx")
	 public String getDept(HttpServletResponse response){
		 System.out.println("===========加载部门信息=========");
		 //json格式   [{id:0001,name:测试部},{id:0002,name:开发部}]
	 try {
		    String jsonStr = identityService.ajaxLoadDept();
		    response.setCharacterEncoding("utf-8");
		
			return jsonStr;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return null;
	 }
	 
	 
	    //获取部门以及职位信息
	     @ResponseBody
	     @RequestMapping("/ajaxLoadDeptAndJob.jspx")
		 public String ajaxLoadDeptAndJob(){
			 //json格式   [{id:0001,name:测试部},{id:0002,name:开发部}]
	    	try {
	    	  String jsonStr = identityService.ajaxLoadDeptAndJob();
			  return jsonStr;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 return null;
		 }
	 
	 
}
