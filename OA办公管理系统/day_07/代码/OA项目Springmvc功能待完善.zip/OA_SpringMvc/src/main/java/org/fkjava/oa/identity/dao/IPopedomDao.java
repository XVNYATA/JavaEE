package org.fkjava.oa.identity.dao;

import java.util.List;

import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.dao.base.HibernateDao;

public interface IPopedomDao extends HibernateDao{

	//加载一级二级模块
	List<Object[]> ajaxFirstAndSecondModule();

	List<Module> loadThirdModule(String parentCode);

	//获取权限信息
	List<String> getOperasByRoleIdAndCode(String parentCode, Long roleId);

	//删除当前角色在指定模块下的所有的操作
	void deletePopedomByRoleIdAndParentCode(Long roleId, String parentCode);

	//根据当前用户所拥有的角色，获取该用户拥有的操作模块
	List<String> ajaxLoadModuleByUserId(String userId);
	
	//获取用户权限信息用于控制页面中的操作按钮是显示还是隐藏
	List<String> findUsetOperasByUserId(String userId);

}
