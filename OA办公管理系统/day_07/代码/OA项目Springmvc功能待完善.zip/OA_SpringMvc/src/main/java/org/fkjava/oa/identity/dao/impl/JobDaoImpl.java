package org.fkjava.oa.identity.dao.impl;

import java.util.List;
import java.util.Map;

import org.fkjava.oa.identity.dao.IJobDao;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;


public class JobDaoImpl extends HibernateDaoImpl implements IJobDao {

	//加载职位信息
	@Override
	public List<Map<String, Object>> ajaxLoadJob() {
		// TODO Auto-generated method stub
		String hql = "select new Map(j.id as id ,j.name as name) from Job j order by id asc";
		return this.find(hql);
	}

}
