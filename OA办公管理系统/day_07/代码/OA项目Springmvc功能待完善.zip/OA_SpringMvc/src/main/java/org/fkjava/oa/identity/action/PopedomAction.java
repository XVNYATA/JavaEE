package org.fkjava.oa.identity.action;



import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.bean.Role;
import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.identity.service.IdentityServiceI;
import org.fkjava.oa.util.OAContant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("/popedom")
public class PopedomAction{
   
	
	 @Autowired(required=true)
	 public IdentityServiceI identityService;
	
	//加载一级二级模块
	@ResponseBody
	@RequestMapping("/ajaxFirstAndSecondModule.jspx")
	public String ajaxFirstAndSecondModule(){
		try {
			
			String result = identityService.ajaxFirstAndSecondModule();
			return result;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}

	//根据模块code获取模块下的所有子模块并且根据   模块code和角色id获取当前角色在该模块下已经绑定了哪些操作
	 @RequestMapping("/selectThirdModule.jspx")
	public String selectThirdModule(String parentCode,Role role,Model model){
		try {
			//根据模块code获取子模块
			List<Module> modules = identityService.loadThirdModule(parentCode);
			model.addAttribute("modules", modules);
			//获取角色信息
		    role = identityService.getRoleById(role.getId());
		    model.addAttribute("role", role);
		    List<String> operas = identityService.getOperasByRoleIdAndCode(parentCode,role.getId());
		    model.addAttribute("operas", operas);

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return "popedom/popedom";
	}

	//绑定操作
	 @RequestMapping("/bindPopedom.jspx")
	public String bindPopedom(String ids,Role role,Model model,String parentCode,HttpServletRequest request){
		try {
			identityService.bindPopedom(role.getId(),ids.split(","),parentCode,request);
			model.addAttribute("tip", "绑定成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip", e.getMessage());
		}
		return "forward:selectThirdModule";
	}
	
	//根据当前用户所拥有的角色，获取该用户拥有的操作模块
	 @ResponseBody
	 @RequestMapping("/ajaxLoadModuleByUserId.jspx")
	public String ajaxLoadModuleByUserId(HttpServletRequest request,HttpServletResponse response){
		try {
			User u = (User)request.getSession().getAttribute(OAContant.SESSION_USER);
			System.out.println("u.getUserId():"+u.getUserId());
			String result = identityService.ajaxLoadModuleByUserId(u.getUserId());
            return result;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	} 
	
	
	
	
}
