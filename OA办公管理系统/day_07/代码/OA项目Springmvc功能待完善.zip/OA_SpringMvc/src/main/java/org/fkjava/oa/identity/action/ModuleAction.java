package org.fkjava.oa.identity.action;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.service.IdentityServiceI;
import org.fkjava.oa.util.webTage.PageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/module")
public class ModuleAction{


	 @Autowired(required=true)
	 public IdentityServiceI identityService;
	 
	 
	//添加模块信息
	 @RequestMapping("/mgrModule.jspx")
	 public String mgrModule(){
		
		 return "module/moduleMain";
	 }
		 
	//加载权限树左侧页面
	 @RequestMapping("/selectModuleLeft.jspx")
	 public String selectModuleLeft(){
		
		 return "module/moduleLeft";
	 }
		 
	 //异步加载模块信息
	 @ResponseBody
	 @RequestMapping("/ajaxLoadModule.jspx")
	 public String ajaxLoadModule(){
		 
	 try {
			String moduleStr = identityService.ajaxLoadModule();
			return moduleStr;
			 
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return null; 
	 }
	 
	 //模块分页查询
	 @RequestMapping("/selectModule.jspx")
	 public String selectModule(String parentCode,PageModel pageModel,Model model){
		 try {
			List<Module> modules = identityService.selectModuleByPage(parentCode,pageModel);
			model.addAttribute("modules", modules);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}
		 return "module/module";
	 }
	 
	 //删除模块信息
	 @RequestMapping("/deleteModule.jspx")
	 public String deleteModule(Model model,String ids){
		 try {
			 identityService.deleteModule(ids.split(","));
			 model.addAttribute("tip","删除成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
		 return "forward:selectModule";
	 }
	 
	 //根据模块code获取模块信息
	 @RequestMapping("/showUpdateModel.jspx")
	 public String showUpdateModel(Model model,String code){
		 
		 try {
			Module module = identityService.getModuleByCode(code);
			model.addAttribute("module", module);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		 return "module/updateModule";
	 }
	 
	 //更新模块信息
	 @RequestMapping("/updateModule.jspx")
	 public String updateModule(Model model,Module module,HttpServletRequest request){
		try {
			
			 identityService.updateModule(module,request);
			 model.addAttribute("tip","更新成功");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
		 return "module/updateModule";
	 }

	 
	 //添加模块信息
	 @RequestMapping("/addModule.jspx")
	 public String addModule(Model model,Module module,String parentCode,HttpServletRequest request){
		try {
			
			 identityService.addModule(module,parentCode,request);
			 model.addAttribute("tip","添加成功");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
		 return "module/addModule";
	 }
	 
	
}
