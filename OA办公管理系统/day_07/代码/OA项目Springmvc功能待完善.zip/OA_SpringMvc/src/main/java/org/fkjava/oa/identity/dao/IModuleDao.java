package org.fkjava.oa.identity.dao;

import java.util.List;
import java.util.Map;

import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.dao.base.HibernateDao;
import org.fkjava.oa.util.webTage.PageModel;

public interface IModuleDao extends HibernateDao{

	//查询模块信息
	List<Map<String, Object>> ajaxLoadModule();

	//分页查询模块信息
	List<Module> selectModuleByPage(String parentCode, PageModel pageModel);

	//删除模块信息
	void deleteModule(String id);

}
