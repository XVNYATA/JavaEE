package org.fkjava.oa.util.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.util.OAContant;

/**
 * Servlet Filter implementation class LoginFilter
 */
@WebFilter("*.jspx")
public class LoginFilter implements Filter {

    /**
     * Default constructor. 
     */
    public LoginFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		User user = (User)((HttpServletRequest)request).getSession().getAttribute(OAContant.SESSION_USER);
		String uri = ((HttpServletRequest)request).getRequestURI();
		System.out.println("uri:"+uri);
		if(uri.indexOf("/createCode.jspx")!=-1||uri.indexOf("/ajaxLogin.jspx")!=-1){
			System.out.println("===========放行==============");
			chain.doFilter(request, response);
		}else{
			if(user==null){
	        	request.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(request, response);
	        }else{
	        	chain.doFilter(request, response);
	        }
		}
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
