package org.fkjava.oa.identity.action;



import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.fkjava.oa.identity.bean.Role;
import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.identity.service.IdentityServiceI;
import org.fkjava.oa.util.webTage.PageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping(value="/role")
public class RoleAction {
	 
	
	 @Autowired(required=true)
	 public IdentityServiceI identityService;
	 
	 
	 //多条件分页查询用户信息
	 @RequestMapping(value="/selectRole.jspx")
	 public String selectRoleByPage(PageModel pageModel,Model model){
		 System.out.println("======角色========");
		 try {
			 pageModel.setPageSize(3);
			 List<Role> roles = identityService.selectRoleByPage(pageModel);
			 model.addAttribute("roles", roles);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		return "role/role"; 
	 }
	 
	 //添加角色
	 @RequestMapping("/addRole.jspx")
	 public String addRole(Role role,Model model,HttpServletRequest request){ 
	  try {
			identityService.saveRole(role,request);
			model.addAttribute("tip","添加成功！");
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
	   return "role/addRole";
	 }
	 
	 
	 //跳转至修改角色页面
	 @RequestMapping("/showUpdateRole.jspx")
	 public String showUpdateRole(Role role,Model model){
		try {
			//根据角色id获取角色信息
			 role = identityService.getRoleById(role.getId());
			 model.addAttribute("role", role);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		 return "role/updateRole";
	 }
	 
	 
	 //修改角色
	 @RequestMapping("/updateRole.jspx")
	 public String updateRole(Role role,Model model,HttpServletRequest request){ 
	  try {
			identityService.updateRole(role,request);
			model.addAttribute("tip","修改成功！");
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
	   return "role/updateRole";
	 }
	 
	 //删除角色
	 @RequestMapping("/deleteRole.jspx")
	 public String deleteRole(String ids,Model model){
		try {
			 
			model.addAttribute("tip","删除成功！");
			identityService.deleteRoleByIds(ids.split(","));
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
		 return "forward:/selectRole";
	 } 
	 
	 //获取当前角色已绑定的用户
	 @RequestMapping("/selectRoleUser.jspx")
	 public String selectRoleUser(Role role,PageModel pageModel,Model model){
		 
		 try {
			 List<User> users = identityService.findBindUserByRoleId(role.getId(),pageModel);
			 model.addAttribute("users", users);
			 role  = identityService.getRoleById(role.getId());
			 model.addAttribute("role", role);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		 return "role/roleUser";
	 }
	 
	 
	 //角色解除用户   roleId   userId 
	 @RequestMapping("/unbindUser.jspx")
	 public String unbindUser(String ids,Role role,Model model){
		 
		try {
			 
			identityService.unbindUser(role.getId(),ids.split(","));
			model.addAttribute("tip","解除成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
		 return "forward:selectRoleUser";
	 }

	 //获取当前角色未绑定的用户信息
	 @RequestMapping("/selectUnBindUserByRoleId.jspx")
	 public String selectUnBindUserByRoleId(Role role,PageModel pageModel,Model model){
		 
		 try {
			
			 List<User> users = identityService.selectUnBindUserByRoleId(role.getId(),pageModel);
		     model.addAttribute("users", users);
		 } catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		 return "role/bindUser";
	 }
	 
	 
	 //角色绑定用户
	 @RequestMapping("/bindUser.jspx")
	 public String bindUser(Role role,String ids,Model model){
		 
		try {
			identityService.bindUser(role.getId(),ids.split(","));
			model.addAttribute("tip","绑定成功!");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			model.addAttribute("tip",e.getMessage());
		}
		 return "forward:selectUnBindUserByRoleId";
	 }
	 
	 
	
	 
}
