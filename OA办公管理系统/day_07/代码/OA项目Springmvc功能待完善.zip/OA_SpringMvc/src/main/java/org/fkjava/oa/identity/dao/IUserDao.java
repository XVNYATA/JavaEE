package org.fkjava.oa.identity.dao;

import java.util.List;

import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.identity.dao.base.HibernateDao;
import org.fkjava.oa.util.webTage.PageModel;

public interface IUserDao extends HibernateDao{

	//用户分页查询
	List<User> findUsersByPage(User user, PageModel pageModel);

	//删除用户
	void deleteUser(String[] ids);

}
