package org.fkjava.oa.identity.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.fkjava.oa.identity.bean.Dept;
import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.bean.Role;
import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.util.webTage.PageModel;

public interface IdentityServiceI {

	List<Dept> getAllDept();

	//根据登录名获取用户信息
	User findUserByName(String userName);

	//多条件分页查询用户信息
	List<User> selectUserByPage(User user, PageModel pageModel);

	//异步加载部门信息
	String ajaxLoadDept();

	//异步加载部门信息以及职位信息
	String ajaxLoadDeptAndJob();

	 //添加用户
	void saveUser(User user,HttpServletRequest request) throws Exception;

	//修改用户
	void updateUser(User user,HttpServletRequest request);

	//删除用户
	void deleteByIds(String[] split);

	//审核用户
	void checkUserByIds(String[] split, Short status,HttpServletRequest request);

	
	//##################################角色模块#####################################//
	List<Role> selectRoleByPage(PageModel pageModel);

	//保存角色
	void saveRole(Role role,HttpServletRequest request);

	//根据角色id获取角色信息
	Role getRoleById(Long id);

	//修改角色
	void updateRole(Role role,HttpServletRequest request);

	//删除角色
	void deleteRoleByIds(String[] split);

	 //获取当前角色已绑定的用户
	List<User> findBindUserByRoleId(Long id, PageModel pageModel);

	 //角色解除用户
	void unbindUser(Long id, String[] split);

	 //获取当前角色未绑定的用户信息
	List<User> selectUnBindUserByRoleId(Long id,PageModel pageModel);

	//角色绑定用户
	void bindUser(Long id, String[] split);

	//更新个人信息
	void updateSelf(User user);

	//#####################################操作模块########################################//
	String ajaxLoadModule();

    //分页查询模块信息
	List<Module> selectModuleByPage(String parentCode, PageModel pageModel);

	 //删除模块信息
	void deleteModule(String[] split);

	Module getModuleByCode(String code);

	//更新模块
	void updateModule(Module module,HttpServletRequest request);

	//添加模块
	void addModule(Module module,String parentCode,HttpServletRequest request);

	
	//#####################################处理用户权限########################################//
	//加载一级二级模块
	String ajaxFirstAndSecondModule();

	List<Module> loadThirdModule(String parentCode);

	//获取权限信息
	List<String> getOperasByRoleIdAndCode(String parentCode, Long id);

	//绑定操作
	void bindPopedom(Long id, String[] split, String parentCode,HttpServletRequest request);

	//根据当前用户所拥有的角色，获取该用户拥有的操作模块
	String ajaxLoadModuleByUserId(String userId);

	//获取用户权限信息用于控制页面中的操作按钮是显示还是隐藏
	List<String> findUsetOperasByUserId(String userName);

}
