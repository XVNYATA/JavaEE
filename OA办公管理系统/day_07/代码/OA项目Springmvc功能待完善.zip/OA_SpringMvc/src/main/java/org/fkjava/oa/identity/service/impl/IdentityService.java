package org.fkjava.oa.identity.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.fkjava.oa.identity.bean.Dept;
import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.bean.Popedom;
import org.fkjava.oa.identity.bean.Role;
import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.identity.dao.IDeptDao;
import org.fkjava.oa.identity.dao.IGeneralDao;
import org.fkjava.oa.identity.dao.IJobDao;
import org.fkjava.oa.identity.dao.IModuleDao;
import org.fkjava.oa.identity.dao.IPopedomDao;
import org.fkjava.oa.identity.dao.IRoleDao;
import org.fkjava.oa.identity.dao.IUserDao;
import org.fkjava.oa.identity.dao.impl.GeneralDaoImpl;
import org.fkjava.oa.identity.service.IdentityServiceI;
import org.fkjava.oa.util.MD5;
import org.fkjava.oa.util.OAContant;
import org.fkjava.oa.util.OAException;
import org.fkjava.oa.util.webTage.PageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Transactional(readOnly=false,rollbackFor={Exception.class})
@Service("identityService")
public class IdentityService implements IdentityServiceI {

	@Autowired(required=true)
	private IDeptDao deptDao;
	
	@Autowired(required=true)
	private IUserDao userDao;
	
	@Autowired(required=true)
	private IJobDao jobDao;
	
	
	@Autowired(required=true)
	private IRoleDao roleDao;
	
	@Autowired(required=true)
	private IModuleDao moduleDao;
	
	@Autowired(required=true)
	private IGeneralDao generalDao;
	
	@Autowired(required=true)
	private IPopedomDao popedomDao;
	
	
	private Logger logger = Logger.getLogger(IdentityService.class);
	
	@Override
	public List<Dept> getAllDept() {
		// TODO Auto-generated method stub
		List<Dept> depts = deptDao.find(Dept.class);
		return depts;
	}

	
	//根据登录名获取用户信息
	@Override
	public User findUserByName(String userName) {
		// TODO Auto-generated method stub
		try {
			
			return userDao.get(User.class, userName);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("根据用户名获取用户信息失败！",e);
		}
		
	}


	
	
	//多条件分页查询用户信息
	
	@Override
	public List<User> selectUserByPage(User user, PageModel pageModel) {
		// TODO Auto-generated method stub
		try {
			
			List<User> users = userDao.findUsersByPage(user,pageModel);
			for(int i=0;i<users.size();i++){
				//获取创建者
				User u = users.get(i).getCreater();
				if(u!=null) u.getName();
				
				//获取审核人
				User checker = users.get(i).getChecker();
				if(checker!=null) checker.getName();
				
				
			}
				
			return users;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("用户分页查询失败！",e);
		}
	}

	//异步加载部门信息
	@Override
	public String ajaxLoadDept() {
		// TODO Auto-generated method stub
		try {
			//[{id:0001,name:测试部},{id:0002,name:开发部}]   json格式字符窜
			//[{name=技术部, id=1}, {name=运营部, id=2}, {name=财务部, id=3}, {name=人事部, id=4}, {name=总公办, id=5}]
			List<Map<String,Object>> depts = deptDao.ajaxLoadDept();
			System.out.println("depts:"+depts);
			
			JSONArray jsonArray = new JSONArray();
			//将集合转成json格式字符窜
			return jsonArray.fromObject(depts).toString();
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("异步加载部门信息失败！",e);
		}
	}


	//异步加载部门信息以及职位信息
	@Override
	public String ajaxLoadDeptAndJob() {
		// TODO Auto-generated method stub
		try {
			
			JSONObject json = new JSONObject();
			//[{id:0001,name:测试部},{id:0002,name:开发部}]   json格式字符窜
			//[{name=技术部, id=1}, {name=运营部, id=2}, {name=财务部, id=3}, {name=人事部, id=4}, {name=总公办, id=5}]
			List<Map<String,Object>> depts = deptDao.ajaxLoadDept();
			json.put("depts", depts);
			
			
			List<Map<String,Object>> jobs = jobDao.ajaxLoadJob();
			json.put("jobs", jobs);
			return json.toString();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("异步加载部门以及职位信息失败！",e);
		}
	}

	//原子性  一致性  隔离性  持久性
	 //添加用户
	@Override
	public void saveUser(User user,HttpServletRequest request) throws Exception {
		// TODO Auto-generated method stub
		try {
			
			//密码进行MD5加密
			user.setPassWord(MD5.getMD5(user.getPassWord()));
			user.setCreateDate(new Date());
			//设置创建人
			user.setCreater(OAContant.getCurrentUser(request));
			user.setStatus(Short.valueOf("0"));
			userDao.save(user);//转账
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("用户保存失败",e);
			throw new OAException("用户保存失败",e);
		}
	}


	//修改用户
	@Override
	public void updateUser(User user,HttpServletRequest request) {
		// TODO Auto-generated method stub
		try {
			
			//设置修改人以及修改时间
			User u = userDao.get(User.class, user.getUserId());
			u.setAnswer(user.getAnswer());
			u.setDept(user.getDept());
			u.setEmail(user.getEmail());
			u.setJob(user.getJob());
			u.setModifier(OAContant.getCurrentUser(request));
			u.setModifyDate(new Date());
			u.setName(user.getName());
			u.setPhone(user.getPhone());
			u.setQqNum(user.getQqNum());
			u.setQuestion(user.getQuestion());
			u.setSex(user.getSex());
			u.setTel(user.getTel());


		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		
	}

    //删除用户
	@Override
	public void deleteByIds(String[] ids) {
		// TODO Auto-generated method stub
		try {
			userDao.deleteUser(ids);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new OAException("用户删除失败！", e);
		}
	}

    //审核用户
	@Override
	public void checkUserByIds(String[] ids, Short status,HttpServletRequest request) {
		// TODO Auto-generated method stub
			try {
				for(int i=0;i<ids.length;i++){
					User u = userDao.get(User.class,ids[i]);
					u.setChecker(OAContant.getCurrentUser(request));
					u.setCheckDate(new Date());
					u.setStatus(status);
				}

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new OAException("用户审核失败！", e);
			}
	}


	//角色分页查询
	@Override
	public List<Role> selectRoleByPage(PageModel pageModel) {
		// TODO Auto-generated method stub
		try {
			List<Role>  roles = roleDao.selectRoleByPage(pageModel);
			
			return roles;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("用户分页查询失败！",e);
		}
		
	}

	//保存角色
	@Override
	public void saveRole(Role role,HttpServletRequest request) {
		// TODO Auto-generated method stub
		try {
			role.setCreater(OAContant.getCurrentUser(request));
			role.setCreateDate(new Date());
			roleDao.save(role);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("角色保存失败！",e);
		}
	}

	//根据角色id获取角色信息
	@Override
	public Role getRoleById(Long id) {
		// TODO Auto-generated method stub
		try {
			
			return roleDao.get(Role.class, id);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("根据角色id获取角色信息失败！",e);
		}
	}

   //修改角色
	@Override
	public void updateRole(Role role,HttpServletRequest request) {
		// TODO Auto-generated method stub
          try {
			 
        	  Role r = roleDao.get(Role.class, role.getId());
        	  r.setModifier(OAContant.getCurrentUser(request));
        	  r.setModifyDate(new Date());
        	  r.setName(role.getName());
        	  r.setRemark(role.getRemark());
        	  
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("角色修改失败！",e);
		}
	}

    //删除角色
	@Override
	public void deleteRoleByIds(String[] ids) {
		// TODO Auto-generated method stub
		try {
			roleDao.deleteRoleByIds(ids);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("角色删除失败,角色以关联用户，请先处理好用户信息，或者联系管理员："+e.getMessage(),e);
		}
		
	}

	 //获取当前角色已绑定的用户
	@Override
	public List<User> findBindUserByRoleId(Long id, PageModel pageModel) {
		// TODO Auto-generated method stub
		try {
			 List<User> users = roleDao.findBindUserByRoleId(id,pageModel);
			 
			
			return users;
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("根据角色id获取已绑定的用户信息失败！",e);
		}
	}

	 //角色解除用户
	@Override
	public void unbindUser(Long id, String[] ids) {
		// TODO Auto-generated method stub
		try {
			//根据角色id获取角色
			Role role = roleDao.get(Role.class, id);
			
			//获取角色已经绑定的用户信息
			Set<User> users = role.getUsers();
			for(String userId : ids){
				//根据用户id获取用户信息
				User u = this.findUserByName(userId);
				//将用户信息从已绑定的用户集合中清除
				users.remove(u);
			}

			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("根据角色id解除用户失败！",e);
		}
		
	}

	 //获取当前角色未绑定的用户信息
	@Override
	public List<User> selectUnBindUserByRoleId(Long id,PageModel pageModel) {
		// TODO Auto-generated method stub
		try {
			
			return roleDao.selectUnBindUserByRoleId(id,pageModel);

			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("根据角色id获取未绑定的用户信息失败！",e);
		}
	}

	//角色绑定用户
	@Override
	public void bindUser(Long id, String[] ids) {
		// TODO Auto-generated method stub
     try {
			
	     //根据角色id获取角色信息
    	 Role role = roleDao.get(Role.class, id);
    	 //获取角色已经绑定的用户
    	 Set<User> users = role.getUsers();
    	 
    	 for(int i=0;i<ids.length;i++){
    		 User user = this.findUserByName(ids[i]);
    		 //将需要绑定的用户，存放在集合中
    		 users.add(user);
    	 }

			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("角色绑定用户信息失败！",e);
		}
	}

    //更新个人信息
	@Override
	public void updateSelf(User user) {
		// TODO Auto-generated method stub
		try {
	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("用户信息更新失败！",e);
		}
	}


	//异步加载模块信息
	@Override
	public String ajaxLoadModule() {
		// TODO Auto-generated method stub
		
		try {
			//[{name=系统管理, code=0001}, {name=用户管理, code=00010001}]==>[{name:系统管理, code:0001}, {name:用户管理, code:00010001}]
			List<Map<String,Object>> params = moduleDao.ajaxLoadModule();
			System.out.println("params:"+params.toString());
			JSONArray arr = new JSONArray();
			for(int i=0;i<params.size();i++){
				
				JSONObject obj = new JSONObject();
				String id = (String)params.get(i).get("code");
				obj.put("name", params.get(i).get("name"));
				obj.put("id", id);
				obj.put("pid", id.length()==4?"1":id.substring(0, id.length()-OAContant.COODLENGTH));
				arr.add(obj);
			}
			
			
           return arr.toString();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("模块信息加载失败！",e);
		}
	}


	//根据模块的code获取模块信息
	@Override
	public List<Module> selectModuleByPage(String parentCode, PageModel pageModel) {
		// TODO Auto-generated method stub
		try {
		     return moduleDao.selectModuleByPage(parentCode,pageModel);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("模块信息分页查询失败！",e);
		}
	}

   //删除模块信息
	@Override
	public void deleteModule(String[] ids) {
		// TODO Auto-generated method stub
		try {
			 for(String id : ids){
				 moduleDao.deleteModule(id+"%");
			 }
		      
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("删除失败，该模块已被其他模块关联，无法删除："+e.getMessage(),e);
		}
	}


	@Override
	public Module getModuleByCode(String code) {
		// TODO Auto-generated method stub
		try {

           return moduleDao.get(Module.class,code);
		      
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("根据模块code获取模块信息失败！",e);
		}
	}


	@Override
	public void updateModule(Module module,HttpServletRequest request) {
		// TODO Auto-generated method stub
		try {
			//持久化状态  
			Module m = moduleDao.get(Module.class, module.getCode());
		    m.setModifier(OAContant.getCurrentUser(request));
			m.setModifyDate(new Date());
			m.setRemark(module.getRemark());
			m.setName(module.getName());
			m.setUrl(module.getUrl());						
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("模块更新失败！",e);
		}
	}

    //添加模块
	@Override
	public void addModule(Module module,String parentCode,HttpServletRequest request) {
		// TODO Auto-generated method stub
		try {
			//设置模块编号    
			 module.setCode(generalDao.getModuleCode("code",Module.class,parentCode));
			 module.setCreateDate(new Date());
			 module.setCreater(OAContant.getCurrentUser(request));
			 moduleDao.save(module);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("模块添加失败！",e);
		}
	}

    //加载权限信息
	@Override
	public String ajaxFirstAndSecondModule() {
		// TODO Auto-generated method stub
		try {
			List<Object[]> list = popedomDao.ajaxFirstAndSecondModule();
			JSONArray arr  =new JSONArray();
			for(int i=0;i<list.size();i++){
				JSONObject obj = new JSONObject();
				obj.put("id", list.get(i)[0]);    
				obj.put("pid", String.valueOf(list.get(i)[0]).length() == 4?"1":list.get(i)[0].toString().substring(0, OAContant.COODLENGTH));
				obj.put("name", list.get(i)[1]);
				arr.add(obj);
				
			}
			return arr.toString();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("权限信息加载失败！",e);
		}
	}


	@Override
	public List<Module> loadThirdModule(String parentCode) {
		// TODO Auto-generated method stub
			try {
				return popedomDao.loadThirdModule(parentCode);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new OAException("模块信息加载失败！",e);
			}
	}

   //获取权限信息
	@Override
	public List<String> getOperasByRoleIdAndCode(String parentCode, Long roleId) {
		// TODO Auto-generated method stub
		try {
			return popedomDao.getOperasByRoleIdAndCode(parentCode,roleId);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("权限信息加载失败！",e);
		}
	}

	//绑定操作
	@Override
	public void bindPopedom(Long roleId, String[] ids, String parentCode,HttpServletRequest request) {
		// TODO Auto-generated method stub
		try {
			//删除当前角色在指定模块下的所有的操作
			popedomDao.deletePopedomByRoleIdAndParentCode(roleId,parentCode);

			//重新绑定操作
			for(int i=0;i<ids.length;i++){
				Popedom p = new Popedom();
				p.setCreateDate(new Date());
				p.setCreater(OAContant.getCurrentUser(request));
				
				Role r  =new Role();
				r.setId(roleId);
				p.setRole(r);
				
				Module m = new Module();
				m.setCode(parentCode);
				p.setModule(m);
				
				Module popedom = new Module();
				popedom.setCode(ids[i]);
				
				p.setOpera(popedom);
				popedomDao.save(p);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("操作绑定失败！",e);
		}
		
	}

	//根据当前用户所拥有的角色，获取该用户拥有的操作模块
	@Override
	public String ajaxLoadModuleByUserId(String userId) {
		// TODO Auto-generated method stub
		try {
			 // 0001001   00020003   二级模块
		     List<String>  moduleCodes = popedomDao.ajaxLoadModuleByUserId(userId);
		     System.out.println("moduleCodes:"+moduleCodes.toString());
		     //用于存放一级模块的code
		     Set<String> firstCodes = new HashSet<>();
		     JSONArray arr = new JSONArray();
		     //根据模块编号获取模块信息    将用户能看到的二级模块信息放在jsonArray数组中
		     for(int i = 0;i<moduleCodes.size();i++){
		    	 Module module = moduleDao.get(Module.class, moduleCodes.get(i));
		    	 JSONObject obj = new JSONObject();
		    	 obj.put("id", module.getCode());
		    	 obj.put("pid", module.getCode().substring(0, OAContant.COODLENGTH));
		    	 obj.put("name", module.getName());
		    	 obj.put("url",module.getUrl());
		    	 arr.add(obj);
		    	 
		    	 firstCodes.add(module.getCode().substring(0, OAContant.COODLENGTH));
		     }
		     
		     //填充一级模块信息
		     Iterator<String> its = firstCodes.iterator();
		     while(its.hasNext()){
		    	 //获取一级模块的code
		    	 String firstCode = its.next();
		    	 Module firstModule = moduleDao.get(Module.class, firstCode);
		    	 JSONObject obj = new JSONObject();
		    	 obj.put("id", firstModule.getCode());
		    	 obj.put("pid", "1");
		    	 obj.put("name", firstModule.getName());
		    	 obj.put("url","#");
		    	 arr.add(obj);
		     }
		     
		     return arr.toString();
		     
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("用户权限信息获取失败！",e);
		}
	}

	//获取用户权限信息用于控制页面中的操作按钮是显示还是隐藏
	@Override
	public List<String> findUsetOperasByUserId(String userId) {
		// TODO Auto-generated method stub
		try {
			 // 00010010001   000200030001   三级模块     /user/addUser.jspx    /user/updateUser.jspx
		     List<String>  moduleCodes = popedomDao.findUsetOperasByUserId(userId);
		     List<String> urls = new ArrayList<>();
		     for(int i=0;i<moduleCodes.size();i++){
		    	 Module m = moduleDao.get(Module.class, moduleCodes.get(i));
		    	 urls.add(m.getUrl());
		     }
		    
		     return urls;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new OAException("用户权限信息获取失败！",e);
		}
	}

}
