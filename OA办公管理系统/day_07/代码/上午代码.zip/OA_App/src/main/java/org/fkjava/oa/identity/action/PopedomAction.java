package org.fkjava.oa.identity.action;

import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.fkjava.oa.identity.base.BaseAction;
import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.bean.Role;
import org.fkjava.oa.util.OAContant;


public class PopedomAction extends BaseAction {

    private Role role;
    private List<Module> modules;
    private String parentCode;
    private List<String> operas; 
    private String codes;
    
    //加载一级以及二级模块
    public String ajaxLoadFirstAndSecondModule(){
    	
    	try {
			String result = identityService.ajaxLoadFirstAndSecondModule();
			ServletActionContext.getResponse().getWriter().print(result);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	return NONE;
    }
    
    
    //根据父级code获取子模块信息
    public String selectModuleByParentCode(){
    	try {
			
    		role  = identityService.getRoleById(role.getId());
    		modules = identityService.selectModuleByParentCode(parentCode);
    		//获取指定角色在指定模块下的操作权限
    		operas = identityService.getAllOperasByRoleIdAndModuleCode(role.getId(),parentCode);
    	} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	return SUCCESS;
    }
    
    //绑定操作
    public String bindPopedomByRoleIdAndModuleCode(){
    	try {
			
    		
    		identityService.bindPopedomByRoleIdAndModuleCode(role.getId(),parentCode,(codes.equals("")?null:codes.split(",")));
            tip = "绑定成功！";
    	} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
    	return SUCCESS;
    }
    
    //获取当前用户的权限
    public String ajaxLoadUserPopedoms(){
    	try {
    		//根据用户的id获取用户所拥有的权限
			String result = identityService.ajaxLoadUserPopedoms(OAContant.getCurrentUser().getUserId());
			ServletActionContext.getResponse().getWriter().print(result);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	return NONE;
    }

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}


	public List<Module> getModules() {
		return modules;
	}


	public void setModules(List<Module> modules) {
		this.modules = modules;
	}


	public String getParentCode() {
		return parentCode;
	}


	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}


	public List<String> getOperas() {
		return operas;
	}


	public void setOperas(List<String> operas) {
		this.operas = operas;
	}


	public String getCodes() {
		return codes;
	}


	public void setCodes(String codes) {
		this.codes = codes;
	}
       
       
       
       

	
}
