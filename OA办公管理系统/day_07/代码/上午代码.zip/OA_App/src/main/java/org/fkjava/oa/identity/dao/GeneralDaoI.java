package org.fkjava.oa.identity.dao;

import org.fkjava.oa.identity.dao.base.HibernateDao;

public interface GeneralDaoI extends HibernateDao{

	String getMaxCode(String parentCode, Class<?> table, String field);


}
