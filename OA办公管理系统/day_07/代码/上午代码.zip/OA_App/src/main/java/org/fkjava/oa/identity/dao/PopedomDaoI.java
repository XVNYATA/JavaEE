package org.fkjava.oa.identity.dao;

import java.util.List;
import java.util.Map;

import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.dao.base.HibernateDao;

public interface PopedomDaoI extends HibernateDao{

	List<Map<String, String>> ajaxLoadFirstAndSecondModule();

	//根据父级code获取子模块信息
	List<Module> selectModuleByParentCode(String parentCode);

	//获取指定角色在指定模块下的操作权限
	List<String> getAllOperasByRoleIdAndModuleCode(Long id, String parentCode);

	//根据角色id以及模块code删除所有的权限
	void deletePopedomByRoleIdAndCode(Long id, String parentCode);

	//根据用户的id获取用户所拥有的权限
	List<String> ajaxLoadUserPopedoms(String userId);

}
