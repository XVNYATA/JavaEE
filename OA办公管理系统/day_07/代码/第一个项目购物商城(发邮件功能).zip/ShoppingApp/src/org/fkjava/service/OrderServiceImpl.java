package org.fkjava.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.fkjava.annotation.AutoMapper;
import org.fkjava.bean.Order;
import org.fkjava.exception.ShopEexception;
import org.fkjava.mapper.OrderMapper;

public class OrderServiceImpl implements OrderService {

	@AutoMapper
	private OrderMapper orderMapper;
	
	//通过log4j记录项目异常信息
	Logger logger  =Logger.getLogger(ArticleServiceImpl.class);
		
	@Override
	public void saveOrderAndItem(Order order) {
		// TODO Auto-generated method stub
		try {
			//保存订单
			orderMapper.save(order);
			//获取主键id
			int orderId = order.getId();
			System.out.println("orderId:"+orderId);
			//将订单明细信息保存至数据库
			for(int i=0;i<order.getItems().size();i++){
				//将订单id放在订单明细中
				order.getItems().get(i).setOrderId(orderId);
				//保存订单明细
				orderMapper.saveOrderItem(order.getItems().get(i));
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("订单保存失败！",e);
			throw new ShopEexception("订单保存失败！",e);
		}
		
		
	}

	//根据用户id获取用户订单
	@Override
	public List<Order> findOrderByUserId(int userId) {
		// TODO Auto-generated method stub
		try {
			List<Order> orderList = orderMapper.findOrderByUserId(userId);
			return orderList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("订单列表获取！",e);
			throw new ShopEexception("订单列表获取！",e);
		}
		
	}
	
	
}
