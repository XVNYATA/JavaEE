package org.fkjava.util.webTag;

import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.ServletRequest;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class PageTag extends TagSupport {
	
	private String url;//当前页码  index.action
	private Page page;//分页实体

	

	@Override
	public int doStartTag() throws JspException {
		// TODO Auto-generated method stub
		//物品总记录数大于零时才分页画分页标签 
		if(this.page.getTotalNum()>0){
			//获取request对象
			ServletRequest request =  this.pageContext.getRequest();
			//获取请求的参数名
			Enumeration<String> params =  request.getParameterNames();
			StringBuffer requestParas = new StringBuffer();
			//迭代所有的参数
			while(params.hasMoreElements()){
				
				
				String name = params.nextElement();
	            if(name.equals("pageIndex")){
					continue;//跳出档次循环   继续下一次循环（因为上一页和下一页的pageIndex值是不一样的，需要通过计算）
				}
				String value = request.getParameter(name);
				requestParas.append(name).append("=").append(value).append("&");
				System.out.println("参数名："+name);
				System.out.println("参数值："+value);
			}
			
			//获取输出流用于往jsp页面输出数据
			JspWriter write =  this.pageContext.getOut();
			String requestUrl = url + "?"+requestParas.toString();
			
			//用于拼装首页以及上一页
			StringBuffer url1 = new StringBuffer();
			//用于拼装尾页以及下一页
			StringBuffer url2 = new StringBuffer();
			 //如果当前页面是第一页则 首页 上一页不能点击
			if(page.getPageIndex()==1){
				url1.append("<h3>首&nbsp;&nbsp;页</h3>").append("<h3>上一页</h3>");
			}else{
				url1.append("<h3><a href='"+requestUrl+"pageIndex=1'>首&nbsp;&nbsp;页</a></h3>");
				url1.append("<h3><a href='"+requestUrl+"pageIndex="+(this.page.getPageIndex()-1)+"'>上一页</a></h3>");
			}
			
			//如果当前页面是尾页则 尾页 下一页不能点击
			if(page.getPageIndex()==page.getTotalPageNum()){
				url2.append("<h3>下一页</h3>").append("<h3>尾&nbsp;&nbsp;页</h3>");
			}else{
				url2.append("<h3><a href='"+requestUrl+"pageIndex="+(this.page.getPageIndex()+1)+"'>下一页</a></h3>");
				url2.append("<h3><a href='"+requestUrl+"pageIndex="+page.getTotalPageNum()+"'>尾&nbsp;&nbsp;页</a></h3>");
			}

			try {
				write.print("<div class='pagebottom' id='pager' style='clear:both;'>");
				write.print(url1.toString());
				write.print(url2.toString());
				write.print("<h6>当前显示第&nbsp;<font style='color:red;'>" + this.page.getPageIndex() +"</font>");
				write.print("/"+ this.page.getTotalPageNum() + "&nbsp;页");
				write.print("</div>");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		return SKIP_BODY;
	}




	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		System.out.println("url:"+url);
		this.url = url;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		System.out.println("page:"+page);
		this.page = page;
	}
	
	
	
	

}
