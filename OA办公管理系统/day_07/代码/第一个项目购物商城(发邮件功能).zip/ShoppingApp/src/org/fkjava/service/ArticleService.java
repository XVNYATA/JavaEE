package org.fkjava.service;

import java.util.List;

import org.fkjava.bean.Article;
import org.fkjava.util.webTag.Page;

public interface ArticleService {
	
    //根据物品code以及用户输入的关键字查询物品信息
	List<Article> findArticleByCodeAndKeyWord(String keyword, String typecode,Page page);

	//根据商品id获取商品明细信息
	Article findArticleById(Integer id);

	//后去物品总记录数
	Integer findArticleCountByCodeAndKeyWord(String keyword, String typecode);

}
