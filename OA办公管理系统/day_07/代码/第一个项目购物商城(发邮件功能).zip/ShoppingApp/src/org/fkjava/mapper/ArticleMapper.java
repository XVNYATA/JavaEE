package org.fkjava.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.fkjava.bean.Article;
import org.fkjava.util.webTag.Page;

/**
 * ArticleMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-04-02 10:31:13
 * @version 1.0
 */
public interface ArticleMapper {
    
	//根据物品类型以及用户输入的关键字获取物品信息
	
	List<Article> findArticleByCodeAndKeyWord(@Param("keyword")String keyword, @Param("typecode")String typecode,@Param("page")Page page);

	//根据商品id获取商品信息
	@Select("select * from ec_article where id = #{id}")
	Article findArticleById(Integer id);

	
	//获取物品总记录数
	int findArticleCountByCodeAndKeyWord(@Param("keyword")String keyword, @Param("typecode")String typecode);



}