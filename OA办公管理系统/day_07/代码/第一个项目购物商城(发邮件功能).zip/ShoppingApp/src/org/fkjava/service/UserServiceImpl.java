package org.fkjava.service;

import org.apache.log4j.Logger;
import org.fkjava.annotation.AutoMapper;
import org.fkjava.bean.User;
import org.fkjava.exception.ShopEexception;
import org.fkjava.mapper.UserMapper;

public class UserServiceImpl implements UserService {

	@AutoMapper(required=true)
	private UserMapper userMapper;
	//通过log4j记录项目异常信息
	Logger logger  =Logger.getLogger(ArticleServiceImpl.class);
	
	//根据登录名以及密码获取用户信息
	@Override
	public User findUserByNameAndPass(String loginName, String password) {
		// TODO Auto-generated method stub
		try {
			User user = userMapper.findUserByNameAndPass(loginName,password);
			return user;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("根据用户名以及密码获取用户信息失败!", e);
			throw new ShopEexception("根据用户名以及密码获取用户信息失败!", e);
		}
		
	}

	//根据用户名获取用户信息
	@Override
	public User findUserByLoginName(String loginName) {
		// TODO Auto-generated method stub
		try {
			User user = userMapper.findUserByLoginName(loginName);
			return user;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("根据用户名获取用户信息失败!", e);
			throw new ShopEexception("根据用户名获取用户信息失败!", e);
		}
		
	}

	//保存用户信息
	@Override
	public void save(User user) {
		// TODO Auto-generated method stub
		try {
			userMapper.save(user);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("用户保存失败！",e);
			throw new ShopEexception("用户保存失败！",e);
		}
	}

	//根据激活码获取用户信息
	@Override
	public User findUserByActiveCode(String activeCode) {
		try {
			// TODO Auto-generated method stub
			return userMapper.findUserByActiveCode(activeCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("根据激活码获取用户信息失败！",e);
			throw new ShopEexception("根据激活码获取用户信息失败！",e);
		}
		
	}

	//根据激活码激活用户
	@Override
	public void activeUser(String activeCode) {
		// TODO Auto-generated method stub
		try {
			userMapper.activeUser(activeCode);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("用户激活失败！",e);
			throw new ShopEexception("用户激活失败！",e);
		}
	}
	


}
