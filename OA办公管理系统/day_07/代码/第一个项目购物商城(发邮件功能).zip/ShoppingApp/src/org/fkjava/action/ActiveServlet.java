package org.fkjava.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.User;
import org.fkjava.service.UserService;
import org.fkjava.service.UserServiceImpl;
import org.fkjava.util.ServiceProxy;


/**
 * 用户激活
 */
@WebServlet("/active.action")
public class ActiveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActiveServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		UserService userService = serviceProxy.bind(new UserServiceImpl());

		//获取激活码
		String activeCode =request.getParameter("activeCode");
		
		//根据激活码获取用户信息
		User user = userService.findUserByActiveCode(activeCode);
		try {
			if(user!=null){
				//激活用户
				userService.activeUser(activeCode);
				request.setAttribute("message", "恭喜您，激活成功！");
				
			}else{
				request.setAttribute("message", "不好意思哈，激活码已失效！");
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			request.setAttribute("message", "激活失败！");
		}
		//跳转至登录页面
		request.getRequestDispatcher("/login.action").forward(request, response);
		
	}

}
