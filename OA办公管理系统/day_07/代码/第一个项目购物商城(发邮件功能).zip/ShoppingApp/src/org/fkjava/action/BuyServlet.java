package org.fkjava.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * 将商品添加至购物车中
 */
@WebServlet("/buy.action")
public class BuyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BuyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//获取商品id
		String id = request.getParameter("id");
		//获取购买的商品数量
		String buyNum = request.getParameter("buyNum");
		//从session中获取购物车
		Map<Integer,Integer> shopCar = (Map<Integer,Integer>)request.getSession().getAttribute("shopCar");
		if(id!=null&&buyNum!=null){
			Integer articleId = Integer.valueOf(id);
			Integer articleByNum = Integer.valueOf(buyNum);
			if(shopCar==null){
				//shopCar==null:表示第一次购买商品，这时应该创建购物车
				shopCar = new HashMap<>();
				//将商品id以及商品数量存放在购物车中
				shopCar.put(articleId,articleByNum);
				
			}else{
	             //判断购物车中是否已存在该商品  ，存在则数量相加 
				 if(shopCar.containsKey(articleId)){
					 shopCar.put(articleId, articleByNum+shopCar.get(articleId));
				 }else{
					//将商品id以及商品数量存放在购物车中
					shopCar.put(articleId,articleByNum);
				 }

			}
		}else{
			//跳转至首页
			request.getRequestDispatcher("/index.action").forward(request, response);
		}
		//将购物车存放在session中
		request.getSession().setAttribute("shopCar", shopCar);
		
		//跳转至展示购物车信息的Servlet
		request.getRequestDispatcher("/showCar.action").forward(request, response);
		
	}

}
