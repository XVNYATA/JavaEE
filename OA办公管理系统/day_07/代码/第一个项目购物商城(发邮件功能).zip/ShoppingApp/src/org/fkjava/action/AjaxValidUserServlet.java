package org.fkjava.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.User;
import org.fkjava.service.UserService;
import org.fkjava.service.UserServiceImpl;
import org.fkjava.util.ServiceProxy;


/**
 * 异步请求验证用户名
 */
@WebServlet("/validUser.action")
public class AjaxValidUserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AjaxValidUserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		UserService userService = serviceProxy.bind(new UserServiceImpl());
		
		//获取用户名
		String name = request.getParameter("loginName");
		//根据用户名获取用户信息
		User user = userService.findUserByLoginName(name);
		if(user!=null){
			response.getWriter().print("您输入的用户名已存在，请重新输入！");
		}		
		
	}

}
