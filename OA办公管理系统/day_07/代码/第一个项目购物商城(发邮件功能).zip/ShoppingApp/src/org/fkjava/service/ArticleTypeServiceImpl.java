package org.fkjava.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.fkjava.annotation.AutoMapper;
import org.fkjava.bean.ArticleType;
import org.fkjava.exception.ShopEexception;
import org.fkjava.mapper.ArticleTypeMapper;
import org.fkjava.util.SessionConnectionFactory;

public class ArticleTypeServiceImpl implements ArticleTypeService {
	
	
	@AutoMapper(required=true)
	private ArticleTypeMapper articleTypeMapper;
	//通过log4j记录项目异常信息
	Logger logger  =Logger.getLogger(ArticleServiceImpl.class);
	

	//获取一级物品类型
	@Override
	public List<ArticleType> findAllFirstArticleType() {
		// TODO Auto-generated method stub
        try {
        	List<ArticleType> articleTypes = articleTypeMapper.findAllFirstArticleType();
    		return articleTypes;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("获取一级物品类型出现异常",e);
			throw new ShopEexception("获取一级物品类型出现异常",e);
		}
		
	}

	//根据物品类型的code获取物品类型名称
	@Override
	public String getArticleNameByCode(String typecode) {
		// TODO Auto-generated method stub
		try {
			String name = articleTypeMapper.getArticleNameByCode(typecode);
			return name;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("获取一级物品类型Code获取物品名称出现异常",e);
			throw new ShopEexception("获取一级物品类型Code获取物品名称出现异常",e);
		}
		
	}

	//根据以及物品类型的code获取二级物品类型
	@Override
	public List<ArticleType> findSecondArticleTypeByCode(String typecode) {
		// TODO Auto-generated method stub
        try {
        	 List<ArticleType> articleTypes = articleTypeMapper.findSecondArticleTypeByCode(typecode);
     		return articleTypes;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error("获取一级物品类型Code获取二级物品类型",e);
			throw new ShopEexception("获取一级物品类型Code获取二级物品类型",e);
		}
       
	}

	

}
