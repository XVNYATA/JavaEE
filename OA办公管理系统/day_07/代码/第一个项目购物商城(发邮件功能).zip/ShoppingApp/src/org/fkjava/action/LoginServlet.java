package org.fkjava.action;

import java.io.IOException;
import java.nio.file.attribute.UserPrincipalLookupService;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.ArticleType;
import org.fkjava.bean.User;
import org.fkjava.service.ArticleTypeService;
import org.fkjava.service.ArticleTypeServiceImpl;
import org.fkjava.service.UserService;
import org.fkjava.service.UserServiceImpl;
import org.fkjava.util.ServiceProxy;


/**
 * 用户登录
 */
@WebServlet("/login.action")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		
		//获取用户名以及密码
		String loginName = request.getParameter("loginName");
		String password = request.getParameter("password");
		System.out.println("loginName:"+loginName+" password:"+password);
		if(loginName!=null&&!loginName.equals("")&&password!=null&&!password.equals("")){
			//如果登录名以及密码不为空，说明用户点击了登录按钮
			UserService userService = serviceProxy.bind(new UserServiceImpl());
			//根据登录名以及密码获取用户信息
			User user = userService.findUserByNameAndPass(loginName,password);
			String url = "/login.action?loginName=&password=";
			if(user!=null){
				//user！=null意味该用户存在      user.getDisabled()==0:表示未激活
				if(user.getDisabled().equals("0")){
					request.setAttribute("message", "您尚未激活，请登录邮箱["+user.getEmail()+"]进行激活!");
				
				}else{
					//判断该用户是普通会员还是管理员
					if(user.getRole()==1){
						url = "/index.action";
					}else{
						//跳转至后台管理页面
						url = "/admin/jsp/index.jsp";
					}
					
					//将用户信息存放在session中
					request.getSession().setAttribute("sessionUser", user);
				}
			}else{
				//用户名获密码输入错误
				request.setAttribute("message", "您输入的用户名获密码不正确，请核实!");
			}
			//跳珠至指定页面
			request.getRequestDispatcher(url).forward(request, response);
		}else{
			
			//创建物品类型服务层对象
			ArticleTypeService articleTypeService = serviceProxy.bind(new ArticleTypeServiceImpl());
			//获取一级物品类型
			List<ArticleType> articleTypes = articleTypeService.findAllFirstArticleType();
			//将物品类型保存至request对象中
			request.setAttribute("articleTypes", articleTypes);
			//跳转至登录页面
			request.getRequestDispatcher("/WEB-INF/jsp/login.jsp").forward(request, response);
		}
	
	}

}
