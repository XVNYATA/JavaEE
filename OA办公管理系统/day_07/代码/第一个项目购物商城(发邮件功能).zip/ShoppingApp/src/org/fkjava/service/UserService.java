package org.fkjava.service;

import org.fkjava.bean.User;

public interface UserService {

	//根据登录名以及密码获取用户信息
	User findUserByNameAndPass(String loginName, String password);

	//根据登录名获取用户信息
	User findUserByLoginName(String name);

	//保存用户信息
	void save(User user);

	//根据激活码获取用户信息
	User findUserByActiveCode(String activeCode);

	//根据激活码激活用户
	void activeUser(String activeCode);
	
   
}
