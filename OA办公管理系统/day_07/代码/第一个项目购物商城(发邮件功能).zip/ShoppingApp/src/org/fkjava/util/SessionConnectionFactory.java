package org.fkjava.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class SessionConnectionFactory {
	private static SqlSessionFactory sqlSessionFactory = null;
	private static ThreadLocal<SqlSession> threadLocal = new ThreadLocal<>();

	static{
		InputStream inputStream = null;
		try {
			 inputStream = Resources.getResourceAsStream("mybatis-config.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(inputStream!=null){
				try {
					inputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}
	
	//获取连接
	public static SqlSession getSqlSession(){
		SqlSession sqlsession = threadLocal.get();
		if(sqlsession==null){
			sqlsession = sqlSessionFactory.openSession();
			//将sqlsession存放的threadLocal中
			threadLocal.set(sqlsession);
		}
		return sqlsession;
	}
	
	
	//关闭连接
	public static void closeSqlSession(){
		SqlSession sqlsession = threadLocal.get();
		if(sqlsession!=null){
			sqlsession.close();
			threadLocal.remove();
		}
		
	}
}
