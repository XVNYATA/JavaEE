package org.fkjava.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.Article;
import org.fkjava.bean.ArticleType;
import org.fkjava.service.ArticleService;
import org.fkjava.service.ArticleServiceImpl;
import org.fkjava.service.ArticleTypeService;
import org.fkjava.service.ArticleTypeServiceImpl;
import org.fkjava.util.ServiceProxy;
import org.fkjava.util.webTag.Page;

/**
 * Servlet implementation class IndexServlet
 * 商品首页
 */
@WebServlet("/index.action")
public class IndexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public IndexServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		//创建物品服务层对象
		ArticleService articleService = serviceProxy.bind(new ArticleServiceImpl());
		//创建物品类型服务层对象
		ArticleTypeService articleTypeService = serviceProxy.bind(new ArticleTypeServiceImpl());
		//获取一级物品类型
		List<ArticleType> articleTypes = articleTypeService.findAllFirstArticleType();
		//将物品类型保存至request对象中
	    request.setAttribute("articleTypes", articleTypes);
	   
	   
		//获取用户输入的查询条件
		//用户输入的关键字
		String keyword = request.getParameter("keyword");
		//将用户输入的关键字保存
		request.setAttribute("keyword", keyword);
		//获取用户选择的物品类型
		String typecode = request.getParameter("typecode");//00010007    
		 //如果物品类型为空，则从物品类型中截取第一个作为查询条件
	    if(typecode==null&&articleTypes.size()>0){
	    	typecode = articleTypes.get(0).getCode();
	    }
	    //保存用户选择的typecode
	    request.setAttribute("typecode", typecode);
	    //从typecode中截取前四位作为一级物品类型  0001==》0001   00010001==》0001
	    String parentCode = typecode.substring(0, 4);
	    //根据以及物品类型的code获取二级物品类型
	    List<ArticleType> secondArticleTypes = articleTypeService.findSecondArticleTypeByCode(parentCode+"%");
	    request.setAttribute("secondArticleTypes", secondArticleTypes);
	    
	    //获取一级物品类型的名称
	    String firstArticleTypeName = articleTypeService.getArticleNameByCode(parentCode);
	    //将一级物品类型的名字保存
	    request.setAttribute("firstArticleTypeName", firstArticleTypeName);
		System.out.println("keyword:"+keyword+" typecode："+typecode);
		
		 
	    //获取当前页码
	    String pageIndex = request.getParameter("pageIndex");
	    if(pageIndex==null||pageIndex.equals("")){
	    	pageIndex = "1";
	    }
	    
	    //创建分页对象   第一个参数：当前页码   第一个参数：每页显示的记录数  
	    Page page = new Page(Integer.valueOf(pageIndex),8);
	    
	    //获取总记录数 便于分页
	    Integer totalNum = articleService.findArticleCountByCodeAndKeyWord(keyword==null?null:"%"+keyword+"%",typecode+"%");
	    System.out.println("totalNum:"+totalNum);
	    page.setTotalNum(totalNum);
	    request.setAttribute("page", page);
		
		
		//根据用户输入的查询条件获取物品信息
		List<Article> articleList = articleService.findArticleByCodeAndKeyWord(keyword==null?null:"%"+keyword+"%",typecode+"%",page);
		System.out.println("获取到的商品的数量："+articleList.size());
		//保存物品信息
		request.setAttribute("articleList", articleList);
		
		
		//跳转至首页
		request.getRequestDispatcher("/WEB-INF/jsp/list.jsp").forward(request, response);
	}

}
