package org.fkjava.action;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.Article;
import org.fkjava.bean.ArticleType;
import org.fkjava.service.ArticleService;
import org.fkjava.service.ArticleServiceImpl;
import org.fkjava.service.ArticleTypeService;
import org.fkjava.service.ArticleTypeServiceImpl;
import org.fkjava.util.ServiceProxy;

/**
 * 展示购物车中商品信息
 */
@WebServlet("/showCar.action")
public class ShowCarServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowCarServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		//创建物品服务层对象
		ArticleService articleService = serviceProxy.bind(new ArticleServiceImpl());
		
		//获取一级物品类型
		ArticleTypeService articleTypeService = serviceProxy.bind(new ArticleTypeServiceImpl());
		//获取一级物品类型
		List<ArticleType> articleTypes = articleTypeService.findAllFirstArticleType();
		//将物品类型保存至request对象中
	    request.setAttribute("articleTypes", articleTypes);
		
		//获取购物车
		Map<Integer,Integer> shopCar = (Map<Integer,Integer>)request.getSession().getAttribute("shopCar");
	    if(shopCar!=null){
	    	List<Article> articleList = new ArrayList<>();
	    	//商品总数量
	    	Integer totalBuyNum = 0;
	    	//商品总价格：折扣价相加
	    	Double totalPrice = 0.0;
	    	//迭代购物车
	    	for(Map.Entry<Integer, Integer> car : shopCar.entrySet()){
	    		//获取商品id
	    		Integer articleId = car.getKey();
	    		//获取商品数量
	    		Integer buyNum = car.getValue();
	    		//计算购买的总数量
	    		totalBuyNum += buyNum;
	    		
	    		//根据商品id获取商品信息
	    		Article article = articleService.findArticleById(articleId);
	    		//计算总价格
	    		totalPrice += article.getPrice() * buyNum * article.getDiscount();

	    		//将购买的数量存放在article对象中
	    		article.setBuyNum(buyNum);
	    		articleList.add(article);
	    	}
	    	
	    	//将物品信息以及购买的数量以及总金额存放在session中
	    	request.getSession().setAttribute("articleList", articleList);
	    	request.getSession().setAttribute("totalPrice", totalPrice);
	    	request.getSession().setAttribute("totalBuyNum", totalBuyNum);

	    }
	    
	    //跳转至展示购物车上商品信息页面
	    request.getRequestDispatcher("/WEB-INF/jsp/shopcar.jsp").forward(request, response);
	    
	     
	}

}
