package org.fkjava.service;

import java.util.List;

import org.fkjava.bean.Order;

public interface OrderService {

	//保存订单以及订单明细
	void saveOrderAndItem(Order order);

	//根据用户id获取用户订单
	List<Order> findOrderByUserId(int userId);

	
   
}
