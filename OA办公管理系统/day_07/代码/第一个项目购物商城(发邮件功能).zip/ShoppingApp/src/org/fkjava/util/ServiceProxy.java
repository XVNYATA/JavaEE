package org.fkjava.util;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.apache.ibatis.session.SqlSession;
import org.fkjava.annotation.AutoMapper;

public class ServiceProxy {

	@SuppressWarnings("unchecked")
	public <T> T bind(final Object object) {
		// TODO Auto-generated method stub
		return (T)Proxy.newProxyInstance(object.getClass().getClassLoader(), object.getClass().getInterfaces(), new InvocationHandler() {
			
			@Override
			public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				// TODO Auto-generated method stub
				
				//获取连接
				SqlSession sqlSession = SessionConnectionFactory.getSqlSession();
				
				try {
					//获取目标类中所有的属性    包括私有属性
					Field[] fields = object.getClass().getDeclaredFields();
					for(Field field : fields){
						AutoMapper autoMapper = field.getAnnotation(AutoMapper.class);
						if(autoMapper!=null&&autoMapper.required()){
							//如果属性是私有的则设置属性可访问
							if(!field.isAccessible()){
								field.setAccessible(true);
							}
							//给目标属性赋值
							field.set(object, sqlSession.getMapper(field.getType()));
						}
					}
					System.out.println("-------------目标方法执行前--------------------");
					//执行目标方法
					Object result =  method.invoke(object, args);
					System.out.println("-------------目标方法执行后--------------------");
					//提交事务
					sqlSession.commit();
					return result;
					
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					//出现异常时回滚
					sqlSession.rollback();
				}finally {
					//关闭连接
					SessionConnectionFactory.closeSqlSession();
				}
				
				return null;
			}
		});
	}
	

}
