package org.fkjava.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * 删除购物车中商品信息
 */
@WebServlet("/deleteCar.action")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//获取需要删除的物品id
		String id = request.getParameter("id");
		//获取购物车
		Map<Integer,Integer> shopCar = (Map<Integer,Integer>)request.getSession().getAttribute("shopCar");
		if(shopCar!=null&&id!=null){
           shopCar.remove(Integer.valueOf(id));
		}
				
		//跳转至展示购物车信息的Servlet
		response.sendRedirect(request.getContextPath()+"/showCar.action");
		
	}

}
