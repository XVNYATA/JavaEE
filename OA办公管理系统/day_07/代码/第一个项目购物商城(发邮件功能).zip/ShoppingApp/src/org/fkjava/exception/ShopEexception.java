package org.fkjava.exception;

//购物商城自定义异常
public class ShopEexception extends RuntimeException {

	public ShopEexception() {
		// TODO Auto-generated constructor stub
	}

	public ShopEexception(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ShopEexception(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ShopEexception(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ShopEexception(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
