package org.fkjava.util.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

import org.fkjava.bean.User;

/**
 * 登录拦截器
 */
@WebFilter(urlPatterns={"/order.action","/saveOrder.action","/showOrder.action"})
public class LoginFilter implements Filter {

    /**
     * Default constructor. 
     */
    public LoginFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		//从session中获取用户信息
		User user = (User)((HttpServletRequest)request).getSession().getAttribute("sessionUser");

		//判断用户是否登录
		if(user!=null){
			// pass the request along the filter chain
			chain.doFilter(request, response);
		}else{
			
			//跳转至登录页面并给出提示信息
			request.setAttribute("message", "您尚未登录，请登陆后再进行相关操作!");
			request.getRequestDispatcher("/login.action").forward(request, response);
		}
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
