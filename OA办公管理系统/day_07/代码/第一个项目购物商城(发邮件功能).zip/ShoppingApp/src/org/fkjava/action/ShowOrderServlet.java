package org.fkjava.action;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.ArticleType;
import org.fkjava.bean.Order;
import org.fkjava.bean.User;
import org.fkjava.service.ArticleTypeService;
import org.fkjava.service.ArticleTypeServiceImpl;
import org.fkjava.service.OrderService;
import org.fkjava.service.OrderServiceImpl;
import org.fkjava.service.UserService;
import org.fkjava.service.UserServiceImpl;
import org.fkjava.util.ServiceProxy;


/**
 * 展示当前用户订单信息
 */
@WebServlet("/showOrder.action")
public class ShowOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		
		OrderService orderService = serviceProxy.bind(new OrderServiceImpl());
		
		//创建物品类型服务层对象
		ArticleTypeService articleTypeService = serviceProxy.bind(new ArticleTypeServiceImpl());
		//获取一级物品类型
		List<ArticleType> articleTypes = articleTypeService.findAllFirstArticleType();
		//将物品类型保存至request对象中
	    request.setAttribute("articleTypes", articleTypes);
	    //获取当前用户
	    User user = (User)request.getSession().getAttribute("sessionUser");
	    int userId = user.getId();
	    //根据用户id获取用户订单
	    List<Order> orderList = orderService.findOrderByUserId(userId);
	    request.setAttribute("orderList", orderList);
	    System.out.println("orderList:"+orderList.toString());
	    
	    //跳转至订单列表页面
	    request.getRequestDispatcher("/WEB-INF/jsp/orderList.jsp").forward(request, response);
	}

}
