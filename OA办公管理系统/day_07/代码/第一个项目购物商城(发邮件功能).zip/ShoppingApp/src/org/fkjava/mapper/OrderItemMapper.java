package org.fkjava.mapper;

/**
 * OrderItemMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-04-02 10:31:13
 * @version 1.0
 */
public interface OrderItemMapper {



}