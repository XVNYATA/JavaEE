package org.fkjava.action;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.Article;
import org.fkjava.bean.ArticleType;
import org.fkjava.service.ArticleService;
import org.fkjava.service.ArticleServiceImpl;
import org.fkjava.service.ArticleTypeService;
import org.fkjava.service.ArticleTypeServiceImpl;
import org.fkjava.util.ServiceProxy;

/**
 * 展示商品明细信息
 */
@WebServlet("/item.action")
public class ItemServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ItemServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		//创建物品服务层对象
		ArticleService articleService = serviceProxy.bind(new ArticleServiceImpl());
		
		//创建物品类型服务层对象
		ArticleTypeService articleTypeService = serviceProxy.bind(new ArticleTypeServiceImpl());
		//获取一级物品类型
		List<ArticleType> articleTypes = articleTypeService.findAllFirstArticleType();
		//将物品类型保存至request对象中
		request.setAttribute("articleTypes", articleTypes);
		
		
	    //获取商品的id
		String id = request.getParameter("id");
		if(id!=null&&!id.equals("")){
			//根据商品id获取商品信息
			Article article = articleService.findArticleById(Integer.valueOf(id));
			request.setAttribute("article", article);
			//跳转至展示商品明细信息页面
			request.getRequestDispatcher("/WEB-INF/jsp/item.jsp").forward(request, response);
		}else{
			request.getRequestDispatcher("/index.action").forward(request, response);
		}
		
		
		
		
	}

}
