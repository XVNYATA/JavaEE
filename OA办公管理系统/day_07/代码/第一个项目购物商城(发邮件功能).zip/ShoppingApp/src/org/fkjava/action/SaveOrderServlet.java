package org.fkjava.action;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.Article;
import org.fkjava.bean.Order;
import org.fkjava.bean.OrderItem;
import org.fkjava.bean.User;
import org.fkjava.service.OrderService;
import org.fkjava.service.OrderServiceImpl;
import org.fkjava.service.UserService;
import org.fkjava.service.UserServiceImpl;
import org.fkjava.util.ServiceProxy;


/**
 * 保存订单
 */
@WebServlet("/saveOrder.action")
public class SaveOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SaveOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		OrderService  orderService = serviceProxy.bind(new OrderServiceImpl());
		//创建订单对象
		Order order= new Order();
		//获取当前用户
		User user = (User)request.getSession().getAttribute("sessionUser");
		
		//拼装订单编号
		StringBuffer orderCode = new StringBuffer();
		orderCode.append("PO-");
		//创建时间格式化工具
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		Date date = new Date();
		orderCode.append(sdf.format(date));
		orderCode.append("-"+user.getId());
		//设置订单编号
		order.setOrderCode(orderCode.toString());
		//设置下单时间
		order.setCreateDate(date);
		Double amount = (Double)request.getSession().getAttribute("totalPrice");
		//设置订单总金额
		order.setAmount(amount);
		//设置订单所属用户
		order.setUserId(user.getId());
		
		//创建订单明细集合
		List<OrderItem> items = new ArrayList<>();
		//填充订单明细信息
        List<Article> articleList = (List<Article>)request.getSession().getAttribute("articleList");
        
        for(int i=0;i<articleList.size();i++){
        	OrderItem item = new OrderItem();
        	//将物品id存放在item对象中
        	item.setArticleId(articleList.get(i).getId());
        	item.setOrderNum(articleList.get(i).getBuyNum());
        	items.add(item);
        }
        //将订单明细存放在订单对象中
        order.setItems(items);
        
        //保存订单以及明细信息
        orderService.saveOrderAndItem(order);
        
        //清空购物车中商品信息
        //request.getSession().removeAttribute("shopCar");
        request.getSession().removeAttribute("articleList");
        
        //展示当前用户订单
        response.sendRedirect(request.getContextPath()+"/showOrder.action");

	}
	

	
	
	

}
