package org.fkjava.util.webTag;


//分页实体
public class Page {
	
	private Integer pageIndex;//当前页码
	private Integer pageSize = 8;//每页显示的记录数
	
	private Integer totalNum;//总记录数
	
	public Page() {
		super();
	}

	public Page(Integer pageIndex, Integer pageSize) {
		super();
		this.pageIndex = pageIndex;
		this.pageSize = pageSize;
	}
	
	public Integer getPageIndex() {
		return pageIndex;
	}
	public void setPageIndex(Integer pageIndex) {
		this.pageIndex = pageIndex;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	
	
	
	public Integer getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(Integer totalNum) {
		this.totalNum = totalNum;
	}

	//计算开始分页开始索引值
	public int getStartNumber(){
		return (this.getPageIndex()-1)*this.getPageSize();
	}
	
	//获取尾页
	public int getTotalPageNum(){
		System.out.println("this.totalNum:"+this.totalNum+" ----this.pageSize"+this.pageSize);
		return this.getTotalNum() % this.pageSize ==0? this.getTotalNum() / this.pageSize : (this.getTotalNum() / this.pageSize )+1;
	}
	
	
	

}
