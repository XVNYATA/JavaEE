package org.fkjava.service;

import java.util.List;

import org.fkjava.bean.Article;
import org.fkjava.bean.ArticleType;

public interface ArticleTypeService {

	 //获取一级物类型
	List<ArticleType> findAllFirstArticleType();

	 //根据物品类型的code获取物品类型名称
	String getArticleNameByCode(String typecode);

	//根据以及物品类型的code获取二级物品类型
	List<ArticleType> findSecondArticleTypeByCode(String typecode);
	
   

}
