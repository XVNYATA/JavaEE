package org.fkjava.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.fkjava.bean.ArticleType;

/**
 * ArticleTypeMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-04-02 10:31:13
 * @version 1.0
 */
public interface ArticleTypeMapper {

	@Select("SELECT * FROM ec_article_type WHERE LENGTH(CODE)=4")
	List<ArticleType> findAllFirstArticleType();

	@Select("SELECT name FROM ec_article_type WHERE code = #{typecode}")
	String getArticleNameByCode(String typecode);
     
	@Select("SELECT * FROM ec_article_type WHERE CODE LIKE #{typecode}")
	List<ArticleType> findSecondArticleTypeByCode(String typecode);



}