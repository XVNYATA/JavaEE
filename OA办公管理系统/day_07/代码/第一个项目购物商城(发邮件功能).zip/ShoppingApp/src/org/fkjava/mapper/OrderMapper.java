package org.fkjava.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.fkjava.bean.Order;
import org.fkjava.bean.OrderItem;

/**
 * OrderMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-04-02 10:31:13
 * @version 1.0
 */
public interface OrderMapper {

	//保存订单
	void save(Order order);

	@Insert("insert into ec_order_item(order_id,article_id,order_num) values(#{orderId},#{articleId},#{orderNum})")
	void saveOrderItem(OrderItem orderItem);

	//根据用户id获取用户订单
	List<Order> findOrderByUserId(int userId);



}