package org.fkjava.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;
import org.apache.tomcat.dbcp.dbcp2.ConnectionFactory;
import org.fkjava.annotation.AutoMapper;
import org.fkjava.bean.Article;
import org.fkjava.exception.ShopEexception;
import org.fkjava.mapper.ArticleMapper;
import org.fkjava.util.SessionConnectionFactory;
import org.fkjava.util.webTag.Page;

public class ArticleServiceImpl implements ArticleService {
	
	@AutoMapper
	private ArticleMapper articleMapper;
	
	//通过log4j记录项目异常信息
	Logger logger  =Logger.getLogger(ArticleServiceImpl.class);

	@Override
	public List<Article> findArticleByCodeAndKeyWord(String keyword, String typecode,Page page) {
		// TODO Auto-generated method stub
		try {
			List<Article> articleList = articleMapper.findArticleByCodeAndKeyWord(keyword,typecode,page);
			return articleList;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new ShopEexception("根据物品类型获取物品出现异常",e);
			
		}
		
	}

	//根据商品id获取商品信息
	@Override
	public Article findArticleById(Integer id) {
		// TODO Auto-generated method stub
		try {
			Article article = articleMapper.findArticleById(id);
			return article;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new ShopEexception("根据物品id获取物品信息失败",e);
		}
		
	}

	//获取物品总记录数
	@Override
	public Integer findArticleCountByCodeAndKeyWord(String keyword, String typecode) {
		// TODO Auto-generated method stub
		try {
			int totalNum = articleMapper.findArticleCountByCodeAndKeyWord(keyword,typecode);
			return totalNum;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new ShopEexception("根据物品类型获取物品总数量出现异常",e);
		}
		
	}

}
