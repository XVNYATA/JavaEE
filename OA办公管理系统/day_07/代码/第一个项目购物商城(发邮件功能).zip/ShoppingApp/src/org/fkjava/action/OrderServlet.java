package org.fkjava.action;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.fkjava.bean.ArticleType;
import org.fkjava.service.ArticleTypeService;
import org.fkjava.service.ArticleTypeServiceImpl;
import org.fkjava.util.ServiceProxy;


/**
 * 审核订单信息页面
 */
@WebServlet("/order.action")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		//创建物品类型服务层对象
		ArticleTypeService articleTypeService = serviceProxy.bind(new ArticleTypeServiceImpl());
		//获取一级物品类型
		List<ArticleType> articleTypes = articleTypeService.findAllFirstArticleType();
		//将物品类型保存至request对象中
	    request.setAttribute("articleTypes", articleTypes);
	    
		//跳转至审核订单页面
		request.getRequestDispatcher("/WEB-INF/jsp/order.jsp").forward(request, response);
		
	}

}
