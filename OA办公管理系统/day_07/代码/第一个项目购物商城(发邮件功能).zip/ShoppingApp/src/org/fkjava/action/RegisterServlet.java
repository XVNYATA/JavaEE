package org.fkjava.action;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import javax.mail.Authenticator;
import javax.mail.Message.RecipientType;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.ArticleType;
import org.fkjava.bean.User;
import org.fkjava.service.ArticleTypeService;
import org.fkjava.service.ArticleTypeServiceImpl;
import org.fkjava.service.UserService;
import org.fkjava.service.UserServiceImpl;
import org.fkjava.util.ServiceProxy;

import com.sun.mail.smtp.SMTPMessage;


/**
 * 用户注册
 */
@WebServlet("/register.action")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//创建动态代理类
		ServiceProxy  serviceProxy = new ServiceProxy();
		//判断当前请求时注册用户还是用户跳转至注册页面
		String method = request.getParameter("method");
		if("add".equals(method)){
			UserService userService = serviceProxy.bind(new UserServiceImpl());

			//提示信息
			String tip = "";
			//获取请求的参数
			User user = new User();
			//登录名
			String loginName = request.getParameter("loginName");
			user.setLoginName(loginName);
			//获取密码
			String passWord = request.getParameter("passWord");
			user.setPassword(passWord);
			//获取确认密码
			String okPassWord = request.getParameter("okPassWord");
		    if(passWord!=null&&!passWord.equals(okPassWord)){
		    	tip = "您输入的密码与确认密码不相符，请核实！";
		    }
		    //获取用户输入的验证码
		    String authcode = request.getParameter("authcode");
		    //从session中取出验证码
		    String authcodeOk = (String)request.getSession().getAttribute("randomCode");
		    if(authcode!=null&&!authcode.equals(authcodeOk)){
		    	tip = "您输入的验证码不正确，请核实！";
		    }
		    //获取真实姓名
		    String name = request.getParameter("name");
		    user.setName(name);
		    //获取性别
		    String sex = request.getParameter("sex");
		    user.setSex(Integer.valueOf(sex));
		    //获取地址
		    String address = request.getParameter("address");
		    user.setAddress(address);
		    //获取电话号码
		    String phone = request.getParameter("phone");
		    user.setPhone(phone);
		    //创建时间
		    user.setCreateDate(new Date());
		    //邮箱
		    user.setEmail(loginName);
		    //激活码
		    String activeCode = UUID.randomUUID().toString();
		    user.setActive(activeCode);
		    //判断用户输入的信息是否合法
		    if(!tip.equals("")){
		    	request.setAttribute("message", tip);
		    }else{
		    	try {
			    	//保存用户信息
			    	userService.save(user);
			    	request.setAttribute("message", "恭喜您，注册成功，请登录邮箱["+user.getEmail()+"]进行激活！");
                    
			    	//发送邮件
			    	sendMail(user,request);
			    	
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
			    	request.setAttribute("message", "不好意思，您已注册失败，请重新注册！");
				}
		    }
		    //跳转至注册页面
		    request.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(request, response);
			
		}else{
			//创建物品类型服务层对象
			ArticleTypeService articleTypeService = serviceProxy.bind(new ArticleTypeServiceImpl());
			//获取一级物品类型
			List<ArticleType> articleTypes = articleTypeService.findAllFirstArticleType();
			//将物品类型保存至request对象中
			request.setAttribute("articleTypes", articleTypes);
			//跳转至注册页面
			request.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(request, response);
		}
		
	
	}

	//发送邮件给用户
	private void sendMail(User user,HttpServletRequest request) {
		// TODO Auto-generated method stub
		//创建Properties对象  用于存放邮件服务器地址
		Properties props = new Properties();
		//设置邮件服务器地址   我们使用的是126邮件服务器
		props.setProperty("mail.smtp.host", "smtp.126.com");
		//需要对邮件服务器鉴权    执行访问邮件服务器的时候必须要登录邮件服务器
		props.setProperty("mail.smtp.auth", "true");
		
		Authenticator  authenticator = new Authenticator(){
			protected PasswordAuthentication getPasswordAuthentication(){
				return new PasswordAuthentication("fkmailtest@126.com","fkmailtest1234");
			}

		};
		
		
		//创建session实例   用于与邮件服务器进行通信
		Session session = Session.getInstance(props, authenticator);
		
		//通过SMTPMessage来指定邮件相关信息
		SMTPMessage message = new SMTPMessage(session);
		
		try {
			//设置邮件主题
			message.setSubject("用户激活邮件，请按照指引进行激活，无需回复，谢谢！");
			//设置邮件内容
			message.setContent("<a href='http://192.168.10.122:8080"+request.getContextPath()+"/active.action?activeCode="+user.getActive()+"'>恭喜您注册成功，请点击该地址进行激活!</a>", "text/html;charset=utf-8");
			//设置发件人
			message.setFrom(new InternetAddress("fkmailtest@126.com"));
			//设置收件人   接收者类型由：TO(收件人)、CC(抄送)、BCC(密送)
			message.setRecipient(RecipientType.TO, new InternetAddress(user.getEmail()));
			
			//发送邮件
			Transport.send(message);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
}
