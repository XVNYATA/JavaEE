package org.fkjava.oa.identity.dao.impl;

import java.util.List;
import java.util.Map;

import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.dao.PopedomDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;
import org.fkjava.oa.util.OAContant;

public class PopedomDao extends HibernateDaoImpl implements PopedomDaoI{

	@Override
	public List<Map<String, String>> ajaxLoadFirstAndSecondModule() {
		// TODO Auto-generated method stub
		String hql = "select new Map(m.code as code,m.name as name) from Module m where length(m.code) <= "+OAContant.CODE_LENGTH*2;
		return this.find(hql);
	}

	//根据父级code获取子模块信息
	@Override
	public List<Module> selectModuleByParentCode(String parentCode) {
		// TODO Auto-generated method stub
		String hql = "select m from Module m where m.code like ? and length(m.code) = ?";
		return (List<Module>)this.find(hql, new Object[]{parentCode+"%",parentCode.length()+OAContant.CODE_LENGTH});
	}

	//获取指定角色在指定模块下的操作权限
	@Override
	public List<String> getAllOperasByRoleIdAndModuleCode(Long id, String parentCode) {
		// TODO Auto-generated method stub
		String hql = "select p.opera.code from Popedom p where p.role.id = ? and p.module.code = ?";
		return (List<String>)this.find(hql, new Object[]{id,parentCode});
	}

	//根据角色id以及模块code删除所有的权限
	@Override
	public void deletePopedomByRoleIdAndCode(Long id, String parentCode) {
		// TODO Auto-generated method stub
		String hql = "delete  from Popedom p where p.role.id = ? and p.module.code = ?";
		this.bulkUpdate(hql, new Object[]{id,parentCode});
	}

	//根据用户的id获取用户所拥有的权限
	@Override
	public List<String> ajaxLoadUserPopedoms(String userId) {
		// TODO Auto-generated method stub
		StringBuffer hql = new  StringBuffer();
		hql.append(" select  distinct(p.module.code) from Popedom p where p.role.id in (");
		hql.append( "select r.id from Role r inner join r.users u where u.userId = ?)");
		return (List<String>)this.find(hql.toString(), new Object[]{userId});
	}

	//根据用户id获取用户所拥有的权限
	@Override
	public List<String> getUserAllOperasByUserId(String userId) {
		// TODO Auto-generated method stub
		StringBuffer hql = new  StringBuffer();
		hql.append(" select  distinct(p.opera.code) from Popedom p where p.role.id in (");
		hql.append( "select r.id from Role r inner join r.users u where u.userId = ?)");
		return (List<String>)this.find(hql.toString(), new Object[]{userId});
	}

	

}
