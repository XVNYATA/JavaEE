package org.fkjava.oa.identity.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.fkjava.oa.identity.dao.GeneralDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;
import org.fkjava.oa.util.OAContant;

public class GenaralDao extends HibernateDaoImpl implements GeneralDaoI{


    //获取最大编号
	@Override
	public String getMaxCode(String parentCode, Class<?> clazz, String field) {
		// TODO Auto-generated method stub
		StringBuffer hql = new StringBuffer();
		hql.append("select  max(").append(" tb.").append(field).append(")");
		hql.append(" from ").append(clazz.getSimpleName()).append(" tb");
		hql.append(" where  length(tb.").append(field).append(") = ?");
		hql.append(" and tb.").append(field).append(" like ?");
		
		List<Object> params = new ArrayList<>();
		params.add(StringUtils.isEmpty(parentCode)?OAContant.CODE_LENGTH : parentCode.length()+OAContant.CODE_LENGTH);
		params.add(StringUtils.isEmpty(parentCode)?"%":parentCode+"%");
		
		//获取最大子模块编号          
		String maxSonCode = this.findUniqueEntity(hql.toString(), params.toArray());
		System.out.println("maxSonCode:"+maxSonCode);
		
		//判断父级code是否为空，防止报空指针
		parentCode = parentCode == null?"":parentCode;
	   //如果子模块的编号不存在    parentCode+0001
		if(StringUtils.isEmpty(maxSonCode)){
			String suffix = "";
			for(int i=1;i<OAContant.CODE_LENGTH;i++){
				suffix += "0";
			}
			return parentCode+suffix+"1";
		}else{
			//00010001     000100010007   000100010008    
			//获取最大子模块编号的最后四位
			String maxcode = maxSonCode.substring(parentCode.length());
			//将String转成Integer类型数据，便于计算
			String newMaxCode = String.valueOf(Integer.valueOf(maxcode)+1);
			int length = newMaxCode.length();
			//给重新生成的最大code补零    0   3
			for(int i=0;i<OAContant.CODE_LENGTH-length;i++){

				newMaxCode = "0" + newMaxCode;
			}
			return parentCode + newMaxCode;
		}
		
	}

	

}
