package org.fkjava.oa.identity.dao;

import java.util.List;
import java.util.Map;

import org.fkjava.oa.identity.bean.Module;
import org.fkjava.oa.identity.dao.base.HibernateDao;
import org.fkjava.oa.util.webTag.PageModel;

public interface ModuleDaoI extends HibernateDao{

	//加载模块信息
	List<Map<String,String>>  ajaxLoadModule();

	//根据父级模块的code模块分页查询
	List<Module> selectModuleByParentCode(PageModel pageModel, String parentCode);

	//删除模块
	void deleteModuleByCode(String id);

}
