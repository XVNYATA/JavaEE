package org.fkjava.oa.identity.action;

import org.apache.struts2.ServletActionContext;
import org.fkjava.oa.identity.base.BaseAction;
import org.fkjava.oa.identity.bean.Role;


public class PopedomAction extends BaseAction {

    private Role role;
    
    //加载一级以及二级模块
    public String ajaxLoadFirstAndSecondModule(){
    	
    	try {
			String result = identityService.ajaxLoadFirstAndSecondModule();
			ServletActionContext.getResponse().getWriter().print(result);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	return NONE;
    }

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}
       
       
       
       

	
}
