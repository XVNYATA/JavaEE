package org.fkjava.oa.identity.dao.impl;

import java.util.List;
import java.util.Map;

import org.fkjava.oa.identity.dao.PopedomDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;
import org.fkjava.oa.util.OAContant;

public class PopedomDao extends HibernateDaoImpl implements PopedomDaoI{

	@Override
	public List<Map<String, String>> ajaxLoadFirstAndSecondModule() {
		// TODO Auto-generated method stub
		String hql = "select new Map(m.code as code,m.name as name) from Module m where length(m.code) <= "+OAContant.CODE_LENGTH*2;
		return this.find(hql);
	}

	

}
