package org.fkjava.oa.identity.service;

import java.util.List;

import org.fkjava.oa.identity.bean.Dept;

public interface IdentityServiceI {

	//获取部门信息
	List<Dept> getAllDept();

}
