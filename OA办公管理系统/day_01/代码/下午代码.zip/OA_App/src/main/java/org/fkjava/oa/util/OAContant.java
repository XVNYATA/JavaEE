package org.fkjava.oa.util;

public class OAContant {

	//指定session中用户的key值
	public final static String SESSION_USER = "session_user";
	//指定验证码对应的key值
	public static final String VCODE = "vcode";

}
