package org.fkjava.oa.identity.dao.impl;

import org.fkjava.oa.identity.dao.RoleDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;

public class RoleDao extends HibernateDaoImpl implements RoleDaoI{

	public RoleDao() {
		// TODO Auto-generated constructor stub
	}

}
