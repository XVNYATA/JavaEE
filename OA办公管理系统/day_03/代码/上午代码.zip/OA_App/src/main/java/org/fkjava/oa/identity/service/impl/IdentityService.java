package org.fkjava.oa.identity.service.impl;

import java.util.List;
import java.util.Map;

import org.fkjava.oa.identity.bean.Dept;
import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.identity.dao.DeptDaoI;
import org.fkjava.oa.identity.dao.UserDaoI;
import org.fkjava.oa.identity.service.IdentityServiceI;
import org.fkjava.oa.util.webTag.PageModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.sf.json.JSONArray;

@Service
public class IdentityService implements IdentityServiceI{

    @Autowired
    private DeptDaoI deptDao;
    
    @Autowired
    private UserDaoI userDao;
    
	@Override
	public List<Dept> getAllDept() {
		// TODO Auto-generated method stub
		return deptDao.find(Dept.class);
	}
	//根据用户账号获取用户信息
	@Override
	public User getUserById(String userId) {
		// TODO Auto-generated method stub
		try {
			return userDao.get(User.class, userId);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	//用户分页查询
	@Override
	public List<User> selectUserByPage(User user, PageModel pageModel) {
		// TODO Auto-generated method stub
		try {
			List<User> users = userDao.selectUserByPage(user,pageModel);
			//由于创建者以及审核者都是懒加载，通过获取创建者以及审核者再次发送sql语句获取相关信息
			for(User u : users){
				if(u!=null&&u.getChecker()!=null) u.getChecker().getName();
				if(u!=null&&u.getCreater()!=null) u.getCreater().getName();
			}
			return users;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	//获取部门信息
	@Override
	public String findAllDepts() {
		// TODO Auto-generated method stub
		try {
			
		
			List<Map<Integer,String>> depts = deptDao.findAllDepts();
			System.out.println(depts.toString()+"=="+JSONArray.fromObject(depts).toString());
			//将集合转成json格式字符窜
			return JSONArray.fromObject(depts).toString();
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}
	
	 //删除用户信息
	@Override
	public void deleteUserByIds(String[] ids) {
		// TODO Auto-generated method stub
		try {
			userDao.deleteUserByIds(ids);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
