package org.fkjava.oa.identity.service;

import java.util.List;

import org.fkjava.oa.identity.bean.Dept;
import org.fkjava.oa.identity.bean.User;
import org.fkjava.oa.util.webTag.PageModel;

public interface IdentityServiceI {

	//获取部门信息
	List<Dept> getAllDept();

	//根据用户账号获取用户信息
	User getUserById(String userId);

	//用户分页查询
	List<User> selectUserByPage(User user, PageModel pageModel);

	//获取部门信息
	String findAllDepts();

	 //删除用户信息
	void deleteUserByIds(String[] split);

}
