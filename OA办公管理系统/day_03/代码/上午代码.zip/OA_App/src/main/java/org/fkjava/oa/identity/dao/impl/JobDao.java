package org.fkjava.oa.identity.dao.impl;

import org.fkjava.oa.identity.dao.JobDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;

public class JobDao extends HibernateDaoImpl implements JobDaoI{

	public JobDao() {
		// TODO Auto-generated constructor stub
	}

}
