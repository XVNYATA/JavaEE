package org.fkjava.oa.identity.dao.impl;

import org.fkjava.oa.identity.dao.ModuleDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;

public class ModuleDao extends HibernateDaoImpl implements ModuleDaoI{

	public ModuleDao() {
		// TODO Auto-generated constructor stub
	}

}
