package org.fkjava.oa.identity.dao.impl;

import org.fkjava.oa.identity.dao.DeptDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;

public class DeptDao extends HibernateDaoImpl implements DeptDaoI{

	public DeptDao() {
		// TODO Auto-generated constructor stub
	}

}
