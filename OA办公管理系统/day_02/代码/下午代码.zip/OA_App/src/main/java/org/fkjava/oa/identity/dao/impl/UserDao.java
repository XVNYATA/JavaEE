package org.fkjava.oa.identity.dao.impl;

import org.fkjava.oa.identity.dao.UserDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;

public class UserDao extends HibernateDaoImpl implements UserDaoI{

	public UserDao() {
		// TODO Auto-generated constructor stub
	}

}
