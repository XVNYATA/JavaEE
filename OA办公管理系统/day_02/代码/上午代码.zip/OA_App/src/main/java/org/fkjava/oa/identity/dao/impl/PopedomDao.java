package org.fkjava.oa.identity.dao.impl;

import org.fkjava.oa.identity.dao.PopedomDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;

public class PopedomDao extends HibernateDaoImpl implements PopedomDaoI{

	public PopedomDao() {
		// TODO Auto-generated constructor stub
	}

}
