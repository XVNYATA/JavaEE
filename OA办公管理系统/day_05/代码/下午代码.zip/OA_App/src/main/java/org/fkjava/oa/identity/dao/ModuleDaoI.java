package org.fkjava.oa.identity.dao;

import org.fkjava.oa.identity.dao.base.HibernateDao;

public interface ModuleDaoI extends HibernateDao{

}
