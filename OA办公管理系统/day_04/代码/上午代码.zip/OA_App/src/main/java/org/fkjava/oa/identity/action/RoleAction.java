package org.fkjava.oa.identity.action;


import java.util.List;
import org.fkjava.oa.identity.base.BaseAction;
import org.fkjava.oa.identity.bean.Role;
import com.opensymphony.xwork2.ActionSupport;

public class RoleAction extends BaseAction {

	
    private List<Role> roles;
	

	
	//用户分页查询
	public String selectRoleByPage(){
		
	try {
		   pageModel.setPageSize(2);
		   roles = identityService.selectRoleByPage(pageModel);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return SUCCESS;
	}




	public List<Role> getRoles() {
		return roles;
	}



	public void setRoles(List<Role> roles) {
		this.roles = roles;
	}
	
	 

	
	
}
