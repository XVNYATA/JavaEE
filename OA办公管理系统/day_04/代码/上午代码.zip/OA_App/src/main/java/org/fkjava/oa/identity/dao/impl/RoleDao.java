package org.fkjava.oa.identity.dao.impl;

import java.util.List;

import org.fkjava.oa.identity.bean.Role;
import org.fkjava.oa.identity.dao.RoleDaoI;
import org.fkjava.oa.identity.dao.base.impl.HibernateDaoImpl;
import org.fkjava.oa.util.webTag.PageModel;

public class RoleDao extends HibernateDaoImpl implements RoleDaoI{

	//角色分页查询
	@Override
	public List<Role> selectRoleByPage(PageModel pageModel) {
		// TODO Auto-generated method stub
		String hql = "select r from Role r";
		return this.findByPage(hql, pageModel, null);
	}

	

}
