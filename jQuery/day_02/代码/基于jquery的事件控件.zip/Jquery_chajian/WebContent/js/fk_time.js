(function($){
	
	////给jquery增加方法以及属性
	$.extend({
		week:["星期天","星期一","星期二","星期三","星期四","星期五","星期六"],
		calcTime:function(time){
			
			return time < 10?"0"+time:time;
		}

	})
	
	
	
	//给jquery增加对象的方法以及属性
	$.fn.extend({
		timeRun:function(){
			
			
			var date = new Date();

			 //获取年份
			 var year = date.getFullYear();
			 //获取月份
			 var month = date.getMonth()+1;
			 //获取天
			 var day = date.getDate();

			
			 var week = date.getDay();
			 
	         //获取小时
			 var hour = date.getHours();
			 //获取分钟
			 var minute = date.getMinutes();
			 //获取秒
			 var second = date.getSeconds();

			 //将时间拼成字符窜
			 var timeStr = year+"年"+month+"月"+day+"日&nbsp;"+$.week[week]+"&nbsp;"+$.calcTime(hour)+":"+$.calcTime(minute)+":"+$.calcTime(second);
	         this.html(timeStr);
	         //将jqeury对象存放在变量t中
	         var t = this;
	         //启动定时器
	         window.setTimeout(function(){
	        	
	        	 t.timeRun();
	         },1000);
	          
		}
		
		
		
	})
	
	
})(jQuery)