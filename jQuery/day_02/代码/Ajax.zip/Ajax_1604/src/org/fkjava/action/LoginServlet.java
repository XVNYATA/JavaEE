package org.fkjava.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 用户异步登录
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("--------------doGet------------------");
		String  loginName = request.getParameter("loginName");
		String  password = request.getParameter("passWord");
		if(loginName!=null&&loginName.equals("admin")&&password!=null&&password.equals("123456")){
			//假设用户名为  admin   密码 123456则认为登录成功
			//将用户信息存放在session中
			request.getSession().setAttribute("user", loginName);
		}else{
			//用户登录失败，给用户提示信息
			response.setCharacterEncoding("utf-8");
			
			
			
			response.getWriter().print("{\"message\":\"您输入的用户名或密码输入不正确，请核实！\"}");
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("--------------doPost------------------");
		String  loginName = request.getParameter("loginName");
		String  password = request.getParameter("passWord");
		if(loginName!=null&&loginName.equals("admin")&&password!=null&&password.equals("123456")){
			//假设用户名为  admin   密码 123456则认为登录成功
			//将用户信息存放在session中
			request.getSession().setAttribute("user", loginName);
		}else{
			//用户登录失败，给用户提示信息
			response.setCharacterEncoding("utf-8");
			
			
			
			response.getWriter().print("{\"message\":\"您输入的用户名或密码输入不正确，请核实！\"}");
			
		}
		
		
		
	
	}

}
