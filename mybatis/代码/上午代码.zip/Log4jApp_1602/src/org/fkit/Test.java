package org.fkit;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         Calc calc = new Calc();
         System.out.println(calc.chu(9,0));
	}

}
