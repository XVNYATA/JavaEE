package org.fjkava;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * 文件上传
 */
@WebServlet("/fileUpload")
@MultipartConfig  //如果servlet中需要上传文件  必须加上该注解
public class Fileupload extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Fileupload() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
         
		//获取part对象
		Part part = request.getPart("pic");
		
		//获取项目部署路径
		String projectPath  =request.getServletContext().getRealPath("/image");
		File file = new File(projectPath);
		
		//如果文件不存在则创建
		if(!file.exists()){
			file.mkdirs();
		}
		
		//获取文件名
		String fileName = part.getSubmittedFileName();
		 
		//给文件重命名      
		String newName = UUID.randomUUID().toString() +fileName.substring(fileName.lastIndexOf("."), fileName.length());

		//将图片路径存放在request中
		request.setAttribute("imageUrl", "image/"+newName);
		//拷贝文件
		part.write(projectPath+File.separator+newName);
		
		//跳转至页面展示图片信息
		request.getRequestDispatcher("/iframe.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	    this.doGet(request, response);
		
		
	}

}
