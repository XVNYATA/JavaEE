package org.fjkava;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 用户登录
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("-------doGet------");
		 //获取登录名以及密码
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");
		
		//根据用户名以及密码 获取用户信息  xml
		if(name!=null&&name.equals("admin")&&pass!=null&&pass.equals("123456")){
			//将用户信息存放session中
		    request.getSession().setAttribute("name", name);
		}else{
			//将提示信息响应给用户
			response.setCharacterEncoding("utf-8");
			response.getWriter().print("用户名或密码不正确，请核实！");
		
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doGet(request, response);
	}
}
