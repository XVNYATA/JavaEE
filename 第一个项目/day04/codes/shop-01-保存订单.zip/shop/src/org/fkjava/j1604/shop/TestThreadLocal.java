package org.fkjava.j1604.shop;

public class TestThreadLocal {

	// ThreadLocal用于在多个线程里面，隔离成员变量
	static ThreadLocal<String> t = new ThreadLocal<String>();
	static String XX;

	public static void main(String[] args) throws InterruptedException {
		// 创建两个线程，一个线程负责设置值到ThreadLocal里面
		// 另外一个线程尝试取出来
		// ThreadLocal里面的数据是线程隔离的，另外一个取的线程，应该取不到任何数据
		Thread t1 = new Thread(() -> {
			t.set("t1里面设置的值");
			XX = "t1里面给XX变量赋予的值";

			System.out.println("t1里面自己get: " + t.get());
		});

		Thread t2 = new Thread(() -> {
			System.out.println(t.get());
			System.out.println(XX);
		});

		t1.start();
		t1.join();

		t2.start();
		t2.join();
	}
}
