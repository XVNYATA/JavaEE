package org.fkjava.j1604.shop.entity.mapper;

public interface UserMapper {

}
