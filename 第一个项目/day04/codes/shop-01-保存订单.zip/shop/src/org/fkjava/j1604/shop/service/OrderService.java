package org.fkjava.j1604.shop.service;

import java.util.Collection;
import java.util.Date;

import org.fkjava.j1604.shop.MapperFactory;
import org.fkjava.j1604.shop.entity.db.Order;
import org.fkjava.j1604.shop.entity.db.OrderItem;
import org.fkjava.j1604.shop.entity.db.User;
import org.fkjava.j1604.shop.entity.mapper.OrderItemMapper;
import org.fkjava.j1604.shop.entity.mapper.OrderMapper;

public class OrderService {

	private static final OrderService ORDER_SERVICE = new OrderService();

	private OrderService() {
	}

	public static OrderService get() {
		return ORDER_SERVICE;
	}

	public void saveOrder(User user, Collection<OrderItem> items) {

		// 1.创建Order对象
		Order order = new Order();
		// 2.生成订单号
		// 时间+user.id
		String orderCode = "" + System.currentTimeMillis() + user.getId();
		// 3.填充订单里面的一些其他数据
		// 总价应该是从购物车里面获取的
		order.setAmount(50.0);
		order.setOrderCode(orderCode);
		order.setCreateDate(new Date());
		order.setStatus("新订单");
		order.setUser(user);
		// 4.保存订单，并获得订单的id
		OrderMapper orderMapper = MapperFactory.getMapper(OrderMapper.class);

		// System.out.println(order.getId());// null
		orderMapper.save(order);
		// System.out.println(order.getId());// 主键的值

		OrderItemMapper orderItemMapper = MapperFactory
				.getMapper(OrderItemMapper.class);
		// 5.循环保存订单明细
		items.forEach(item -> {
			// item里面原本是没有order的，但是保存的时候又需要，所以先set进来
			item.setOrder(order);

			orderItemMapper.save(item);
		});
	}
}
