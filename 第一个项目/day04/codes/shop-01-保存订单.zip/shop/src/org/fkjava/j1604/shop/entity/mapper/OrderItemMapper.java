package org.fkjava.j1604.shop.entity.mapper;

import org.fkjava.j1604.shop.entity.db.OrderItem;

public interface OrderItemMapper {

	public void save(OrderItem item);
}
