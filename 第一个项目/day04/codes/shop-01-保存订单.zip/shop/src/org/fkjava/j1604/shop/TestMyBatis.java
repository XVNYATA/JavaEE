package org.fkjava.j1604.shop;

import java.util.List;

import org.fkjava.j1604.shop.entity.db.Article;
import org.fkjava.j1604.shop.entity.db.Order;
import org.fkjava.j1604.shop.entity.mapper.ArticleMapper;
import org.fkjava.j1604.shop.entity.mapper.OrderMapper;

public class TestMyBatis {

	public static void main(String[] args) {
		OrderMapper mapper = MapperFactory.getMapper(OrderMapper.class);

		List<Order> list = mapper.test();
		list.forEach(o -> {
			System.out.println(o.getId());
		});

		ArticleMapper articleMapper = MapperFactory
				.getMapper(ArticleMapper.class);
		Article article = articleMapper.getById(5L);
		System.out.println(article.getTitle());// 标题
		System.out.println(article.getType().getName());// 类型名字
	}
}
