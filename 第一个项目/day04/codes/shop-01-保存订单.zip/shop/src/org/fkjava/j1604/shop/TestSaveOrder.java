package org.fkjava.j1604.shop;

import java.util.ArrayList;
import java.util.Collection;

import org.fkjava.j1604.shop.entity.db.Article;
import org.fkjava.j1604.shop.entity.db.OrderItem;
import org.fkjava.j1604.shop.entity.db.User;
import org.fkjava.j1604.shop.service.OrderService;

/**
 * 演示如何保存订单。在保存订单的过程中，主要是需要获取自动生成的主键值。
 * 
 * @author lwq
 *
 */
public class TestSaveOrder {

	public static void main(String[] args) {
		// 登陆以后，在session里面，会保存当前用户的User对象
		User user = new User();
		user.setId(1L);

		// 需要保存到订单里面的订单明细
		// 购物车里面，有一个Map来存储所有的OrderItem，这些OrderItem就是订单的明细，需要保存到数据库去的！
		Collection<OrderItem> items = new ArrayList<>();
		OrderItem item1 = new OrderItem();
		Article article1 = new Article();
		article1.setId(1L);
		article1.setPrice(80.0);
		item1.setArticle(article1);
		item1.setNumber(5);

		OrderItem item2 = new OrderItem();
		Article article2 = new Article();
		article2.setId(2L);
		article2.setPrice(90.0);
		item2.setArticle(article2);
		item2.setNumber(10);

		items.add(item2);
		items.add(item1);

		// 调用服务层方法保存订单
		OrderService service = OrderService.get();
		service.saveOrder(user, items);

		// 提交事务并关闭session
		MapperFactory.closeSession();
	}
}
