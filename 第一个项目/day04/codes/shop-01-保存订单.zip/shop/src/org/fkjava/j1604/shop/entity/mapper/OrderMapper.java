package org.fkjava.j1604.shop.entity.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.fkjava.j1604.shop.entity.db.Order;

public interface OrderMapper {

	/**
	 * 用户测试的时候的抽象方法
	 * 
	 * @return
	 */
	List<Order> test();

	void save(@Param("order") Order order);
}
