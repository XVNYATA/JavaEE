package org.fkjava.j1604.shop.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import org.fkjava.j1604.shop.MapperFactory;

/**
 * Servlet Filter implementation class CloseSqlSessionFilter
 */
@WebFilter("/*")
public class CloseSqlSessionFilter implements Filter {

	/**
	 * Default constructor.
	 */
	public CloseSqlSessionFilter() {
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		// 预处理

		try {
			// pass the request along the filter chain
			chain.doFilter(request, response);
		} finally {
			// 后处理
			MapperFactory.closeSession();
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	}

}
