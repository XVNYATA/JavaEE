package org.fkjava.j1604.shop;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MapperFactory {

	/**
	 * SLF4J是一个基于门面模式设计的日志记录器。它本身没有任何的日志记录功能。<br>
	 * 实际上在这个项目里面，它依赖slf4j-log4j12-1.7.12.jar文件连接到log4j里面实现日志记录。<br>
	 * 如果哪天不想用log4j，只需要把slf4j-log4j12-1.7.12.jar文件替换成需要的，用来连接到其他的日志记录器即可，
	 * 不需要修改任何代码。
	 */
	private static final Logger LOGGER = LoggerFactory
			.getLogger(MapperFactory.class);

	// 关闭连接1.用来在多个线程里面，隔离SqlSession的工具
	private static final ThreadLocal<SqlSession> THREAD_LOCAL = new ThreadLocal<SqlSession>();
	private static final SqlSessionFactory SQL_SESSION_FACTORY;
	static {
		String resource = "mybatis-config.xml";
		try (InputStream inputStream = Resources.getResourceAsStream(resource);) {
			// 初始化SqlSessionFactory
			SqlSessionFactoryBuilder builder = new SqlSessionFactoryBuilder();
			SQL_SESSION_FACTORY = builder.build(inputStream);
		} catch (Exception e) {
			// 把所有的异常都catch出来，然后出现异常，意味着我们的程序初始化失败！
			LOGGER.error("严重错误，MyBatis无法完成初始化，因为:" + e.getLocalizedMessage(), e);
			throw new Error("严重错误，MyBatis无法完成初始化，请检查配置", e);
		}
	}

	/**
	 * SqlSessionFactory，在一个应用里面，应该只有一个！<br>
	 * 一般程序里面不会直接使用SqlSessionFactory，而是通过此工具获得一个SqlSession的实例。<br>
	 * 甚至在后面的时候，为了优化性能，直接在这个工具里面，应该要返回一个 Mapper 接口的实例。<br>
	 * 
	 * @return
	 */
	public static SqlSessionFactory getSessionFactory() {
		return SQL_SESSION_FACTORY;
	}

	/**
	 * &lt;T&gt;表示定义个泛型的参数，这个参数是直接在方法上面定义的。<br>
	 * 此时方法的参数，必须也使用带T的Class，否则将无法得到正确的实例。<br>
	 * 具体T由调用方法的时候，等号左边的变量的类型自动推断。<br>
	 * 比如:<br>
	 * &nbsp;&nbsp;&nbsp;&nbsp;
	 * <code>OrderMapper mapper = MyBatisSessionFactory.getMapper( OrderMapper.class );</code>
	 * 
	 * @param cla
	 * @return
	 */
	public static <T> T getMapper(Class<T> cla) {
		// 打开session以后，一定要关闭的！
		// 但是这里绝对不能关闭，如果关闭了，Mapper将无法使用！
		// 在优化的时候，应该在过滤器里面去关闭。

		// SqlSession session = SQL_SESSION_FACTORY.openSession();

		// 关闭连接1.先从ThreadLocal里面取
		SqlSession session = THREAD_LOCAL.get();

		// 第一次进来的时候，get当然得到null
		if (session == null) {
			session = SQL_SESSION_FACTORY.openSession();
			// 打开的session放入到THREAD_LOCAL里面去
			THREAD_LOCAL.set(session);
		}

		T mapper = session.getMapper(cla);

		return mapper;
	}

	// 关闭连接3.提供关闭Session的方法。
	// 关闭连接4.增加一个过滤器
	public static void closeSession() {
		SqlSession session = THREAD_LOCAL.get();
		if (session != null) {
			// 提交事务、关闭连接
			session.commit();
			session.close();

			// session关闭以后，不能再使用，必须从ThreadLocal里面删除
			THREAD_LOCAL.remove();
		}
	}
}
