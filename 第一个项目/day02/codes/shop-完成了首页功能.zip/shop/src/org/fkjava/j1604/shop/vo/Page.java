package org.fkjava.j1604.shop.vo;

import javax.servlet.http.HttpServletRequest;

public class Page {
	/**
	 * 当前页码
	 */
	private int pageNumber;
	/**
	 * 查询的总记录数
	 */
	private int count;
	/**
	 * 每页显示的记录数
	 */
	private int pageSize;

	private Page() {
	}

	/**
	 * 在获取Page对象的时候，需要从请求参数里面，获得当前页码。并且要传递一个每页的大小。
	 * 
	 * @param request
	 * @param pageSize
	 * @return
	 */
	public static Page getPage(HttpServletRequest request, int pageSize) {
		Page page = new Page();
		// 同时page对象要放到request里面，因为jsp需要使用
		request.setAttribute("page", page);
		page.pageSize = pageSize;

		// 从请求里面获取pageNumber
		String pn = request.getParameter("pageNumber");
		int pageNumber = 1;
		try {
			// 如果请求里面没有pageNumber，那么parseInt会出现异常
			// 出了异常也不处理，直接默认第一页。
			// 如果每次总是第一页，意味着请求参数里面没有pageNumber，或者pageNumber写错。
			pageNumber = Integer.parseInt(pn);
		} catch (Exception ex) {
		}

		page.pageNumber = pageNumber;

		return page;
	}

	/**
	 * 计算开始的行号
	 * 
	 * @return
	 */
	public int getStartRowNumber() {
		return (pageNumber - 1) * pageSize;
	}

	/**
	 * 计算总页数
	 * 
	 * @return
	 */
	public int getTotalPages() {
		int totalPages = count % 8 == 0 ? count / 8 : count / 8 + 1;
		return totalPages;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
