package org.fkjava.j1303.ec.exception;

/**
 * method参数未指定异常
 * 
 * @author lwq
 * 
 */
public class NotMethodParameterException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8916810746243869968L;

	public NotMethodParameterException() {
	}
}
