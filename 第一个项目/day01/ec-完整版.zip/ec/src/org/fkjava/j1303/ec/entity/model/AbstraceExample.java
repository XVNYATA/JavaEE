package org.fkjava.j1303.ec.entity.model;

import org.fkjava.j1303.ec.common.Page;

public class AbstraceExample {

	private Page page;

	/**
	 * @return the page
	 */
	public Page getPage() {
		return page;
	}

	/**
	 * @param page the page to set
	 */
	public void setPage(Page page) {
		this.page = page;
	}
}
