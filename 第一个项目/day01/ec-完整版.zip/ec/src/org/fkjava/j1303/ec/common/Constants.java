package org.fkjava.j1303.ec.common;

public class Constants {

	public static final String KEY_LOGIN_USER = "loginUser";
	public static final String KEY_VALIDATION_CODE = "validationCode.radomString";
}
