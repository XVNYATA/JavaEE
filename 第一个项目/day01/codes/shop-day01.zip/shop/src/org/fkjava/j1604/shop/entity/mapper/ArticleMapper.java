package org.fkjava.j1604.shop.entity.mapper;

import org.fkjava.j1604.shop.entity.db.Article;

public interface ArticleMapper {

	/**
	 * 根据id来查询一个商品
	 * 
	 * @param id
	 * @return
	 */
	Article getById(Long id);

	/**
	 * 根据id删除记录。但是商品的记录是不允许删除，只是禁用。其实是一个update。
	 * 
	 * @param id
	 */
	void delete(Long id);

	/**
	 * 插入新的商品
	 * 
	 * @param article
	 */
	void insert(Article article);

	/**
	 * 更新商品
	 * 
	 * @param article
	 */
	void update(Article article);
}
