package org.fkjava.j1604.shop.service;

import java.util.List;

import org.fkjava.j1604.shop.MapperFactory;
import org.fkjava.j1604.shop.entity.db.ArticleType;
import org.fkjava.j1604.shop.entity.mapper.ArticleTypeMapper;

/**
 * 所有商店相关的代码，都放到此服务进行业务的实现
 * 
 * @author lwq
 *
 */
public class ShopService {

	// 单例2.使用一个静态的成员变量保存唯一的实例
	private static final ShopService SHOP_SERVICE = new ShopService();

	// 单例1.私有构造器
	private ShopService() {
	}

	// 单例3.提供一个公共的、静态方法获得实例
	public static ShopService get() {
		return SHOP_SERVICE;
	}

	/**
	 * 获得所有的顶级类型
	 * 
	 * @return
	 */
	public List<ArticleType> getTopLevelTypes() {
		ArticleTypeMapper articleMapper = MapperFactory
				.getMapper(ArticleTypeMapper.class);
		List<ArticleType> list = articleMapper.getTopLevelTypes();
		return list;
	}

	public List<ArticleType> getAllTypes(String typeCode) {
		// 1.判断typeCode是否不为null，如果不为null，则需要在typeCode后面加上 % 用于like查询
		// 不要在xml里面加%，因为不同的数据库，字符串连接的方式不同
		if (typeCode != null) {
			typeCode = typeCode + "%";
		}
		ArticleTypeMapper articleMapper = MapperFactory
				.getMapper(ArticleTypeMapper.class);
		// 调用方法查询数据
		List<ArticleType> list = articleMapper.getAllTypes(typeCode);
		return list;
	}
}
