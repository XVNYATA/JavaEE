package org.fkjava.j1604.shop.entity.db;

/**
 * 商品类型
 * 
 * @author lwq
 *
 */
public class ArticleType {

	/**
	 * 商品类型的编号。每四位为一级，二级就是八位。不考虑三级类型。
	 */
	private String code;
	/**
	 * 名字
	 */
	private String name;
	/**
	 * 类型的描述
	 */
	private String remark;

	/**
	 * 商品类型的编号。每四位为一级，二级就是八位。不考虑三级类型。
	 * 
	 * @return
	 */
	public String getCode() {
		return code;
	}

	/**
	 * 商品类型的编号。每四位为一级，二级就是八位。不考虑三级类型。
	 * 
	 * @param code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
