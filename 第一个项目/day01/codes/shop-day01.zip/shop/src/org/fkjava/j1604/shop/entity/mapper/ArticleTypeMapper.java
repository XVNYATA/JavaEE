package org.fkjava.j1604.shop.entity.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.fkjava.j1604.shop.entity.db.ArticleType;

public interface ArticleTypeMapper {

	List<ArticleType> getTopLevelTypes();

	// typeCode表示在xml里面使用的变量名。
	// xxx则是接口的参数名。在Java里面，方法的参数名没有意义的，参数名给程序员看的！
	List<ArticleType> getAllTypes(@Param("typeCode") String xxx);

}
