package org.fkjava.j1604.shop;

import java.util.List;

import org.fkjava.j1604.shop.entity.db.Order;
import org.fkjava.j1604.shop.entity.mapper.OrderMapper;

public class TestMyBatis {

	public static void main(String[] args) {
		OrderMapper mapper = MapperFactory.getMapper(OrderMapper.class);

		List<Order> list = mapper.test();
		list.forEach( o -> {
			System.out.println(o.getId());
		});
	}
}
