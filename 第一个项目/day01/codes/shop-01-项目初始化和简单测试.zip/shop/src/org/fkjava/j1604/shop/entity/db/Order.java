package org.fkjava.j1604.shop.entity.db;

public class Order {

	private Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
