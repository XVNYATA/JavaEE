package org.fkjava.j1604.shop.entity.db;

import java.util.Date;

public class Article {

	private Long id;
	private String title;
	private String supplier;
	private Double price;
	/**
	 * 折扣，通常9折、7折这种的。<br>
	 * 折扣价 = price * discount / 10;
	 */
	private Double discount;
	private String locality;
	/**
	 * 上架时间
	 */
	private Date putawayDate;
	/**
	 * 库存
	 */
	private Integer storage;
	private String image;
	private String description;
	private Date createDate;
	private Boolean disabled;
	/*
	 * 外键，用来关联到ArticleType对象的！基于面向对象的角度来看问题，那么不应该有外键存在的！
	 */
	// private String typeCode;
	/**
	 * 关联的外键对应的对象
	 */
	private ArticleType type;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getDiscount() {
		return discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public Date getPutawayDate() {
		return putawayDate;
	}

	public void setPutawayDate(Date putawayDate) {
		this.putawayDate = putawayDate;
	}

	public Integer getStorage() {
		return storage;
	}

	public void setStorage(Integer storage) {
		this.storage = storage;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Boolean getDisabled() {
		return disabled;
	}

	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}

	public ArticleType getType() {
		return type;
	}

	public void setType(ArticleType type) {
		this.type = type;
	}

}
