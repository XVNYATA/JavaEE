package org.fkjava.j1604.shop.entity.db;

public class OrderItem {

	/**
	 * 属于哪个订单
	 */
	private Order order;
	/**
	 * 关联的商品
	 */
	private Article article;
	/**
	 * 购买数量
	 */
	private Integer number;

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Article getArticle() {
		return article;
	}

	public void setArticle(Article article) {
		this.article = article;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}
}
