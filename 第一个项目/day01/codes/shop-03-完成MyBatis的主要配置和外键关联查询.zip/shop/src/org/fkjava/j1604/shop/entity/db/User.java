package org.fkjava.j1604.shop.entity.db;

import java.util.Date;

public class User {
	private Long id;
	private String loginName;
	private String password;
	private String name;
	/**
	 * 1表示男，2表示女
	 */
	private Integer sex;
	private String email;
	private String phone;
	private String address;
	/**
	 * 1是普通用户，2是管理员
	 */
	private Integer role;
	private Date createDate;
	private Boolean disabled;
	/**
	 * 在使用邮件激活的时候，就需要使用此激活码。激活码是一个UUID的字符串，随机生成。<br>
	 * 在激活的时候，URL里面包含此UUID，根据UUID来查询一个User对象。查询到把激活码清空，表示完成激活。<br>
	 * 完成激活的时候，同时把disabled改为false。新注册的应该是disabled为true，不能登陆。
	 */
	private String active;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getSex() {
		return sex;
	}

	public void setSex(Integer sex) {
		this.sex = sex;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Boolean getDisabled() {
		return disabled;
	}

	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

}
