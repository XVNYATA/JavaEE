@javax.xml.bind.annotation.XmlSchema(namespace = "http://a.ws.j1604.fkjava.org/")
package org.fkjava.j1604.ws.a;
