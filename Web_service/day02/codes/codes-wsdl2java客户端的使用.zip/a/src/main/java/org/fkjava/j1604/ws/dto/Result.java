package org.fkjava.j1604.ws.dto;

import javax.xml.bind.annotation.XmlType;

/**
 * WebService操作的结果对象
 * 
 * @author lwq
 *
 */
@XmlType(namespace = "http://ws.j1604.fkjava.org/a/dto")
public class Result {

	public static final int CODE_REGISTER_SUCCEED = 0;
	public static final int CODE_REGISTER_FAILED = 1;
	public static final int CODE_LOGIN_SUCCEED = 2;
	public static final int CODE_LOGIN_FAILED = 3;
	public static final int CODE_CHANGE_PASSWORD_SUCCEED = 4;
	public static final int CODE_CHANGE_PASSWORD_FAILED = 5;
	/**
	 * 不同的操作，返回不同的code，-1表示未知错误
	 */
	private int code = -1;
	private String message;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
