package org.fkjava.j1604.ws.a.impl;

import java.util.HashMap;
import java.util.Map;

import javax.jws.WebService;

import org.fkjava.j1604.ws.a.UserService;
import org.fkjava.j1604.ws.dto.Result;
import org.fkjava.j1604.ws.dto.User;

@WebService(endpointInterface = "org.fkjava.j1604.ws.a.UserService")
public class UserServiceImpl implements UserService {

	// 使用Map模拟数据库
	private Map<Long, User> map = new HashMap<>();

	@Override
	public Result register(User user) {
		// 判断登陆名是否已经存在，如果存在表示注册失败
		boolean exist = false;
		for (Map.Entry<Long, User> entry : map.entrySet()) {
			User old = entry.getValue();
			if (old.getLoginName().equals(user.getLoginName())) {
				exist = true;
				break;
			}
		}
		Result result = new Result();
		if (exist) {
			result.setCode(Result.CODE_REGISTER_FAILED);
			result.setMessage("注册失败，登录名已经被占用");
		} else {
			// 把新的User放到Map，并且产生一个新的ID
			// 取出最大的id
			Long maxId = 0L;
			for (Map.Entry<Long, User> entry : map.entrySet()) {
				Long id = entry.getKey();
				if (id > maxId) {
					maxId = id;
				}
			}
			// 新的id就是最大的id加一
			Long newId = maxId + 1;
			user.setId(newId);
			map.put(newId, user);

			result.setCode(Result.CODE_REGISTER_SUCCEED);
			// 把新的ID返回给客户端
			result.setMessage(String.valueOf(newId));
		}
		return result;
	}

	@Override
	public Result login(User user) {
		// 根据登录名查找User对象，如果没有找到，提示登录名错误；找到但是密码错误，提示密码错误。
		Result result = new Result();
		for (Map.Entry<Long, User> entry : map.entrySet()) {
			User old = entry.getValue();
			if (old.getLoginName().equals(user.getLoginName())) {
				if (old.getPassword().equals(user.getPassword())) {
					// 密码相等
					result.setCode(Result.CODE_LOGIN_SUCCEED);
					result.setMessage(String.valueOf(old.getId()));
					return result;
				} else {
					// 密码不相等
					result.setCode(Result.CODE_LOGIN_FAILED);
					result.setMessage("密码错误");
					return result;
				}
			}
		}
		// 没有找到用户
		result.setCode(Result.CODE_LOGIN_FAILED);
		result.setMessage("登陆名没有找到对应的用户");
		return result;
	}

	@Override
	public User getById(Long id) {
		return map.get(id);
	}

	@Override
	public Result changePassword(Long id, String oldPassword, String newPassword) {
		Result result = new Result();

		User user = map.get(id);
		if (user.getPassword().equals(oldPassword)) {
			// 旧的密码验证通过，可以修改密码
			user.setPassword(newPassword);

			result.setCode(Result.CODE_CHANGE_PASSWORD_SUCCEED);
			result.setMessage("修改密码成功");
		} else {

			result.setCode(Result.CODE_CHANGE_PASSWORD_FAILED);
			result.setMessage("旧的密码验证失败，无法修改密码");
		}
		return result;
	}

}
