package org.fkjava.j1604.ws.a;

import javax.jws.WebParam;
import javax.jws.WebService;

import org.fkjava.j1604.ws.dto.Result;
import org.fkjava.j1604.ws.dto.User;

@WebService
public interface UserService {

	/**
	 * 注册
	 * 
	 * @param user
	 * @return
	 */
	Result register(@WebParam(name = "user") User user);

	/**
	 * 登陆成功以后，code为2，返回的message就是登陆成功以后User的id。
	 * 
	 * @param user
	 * @return
	 */
	Result login(@WebParam(name = "user") User user);

	/**
	 * 根据用户的ID来获取一个User对象，返回的User对象应该不包含密码
	 * 
	 * @param id
	 * @return
	 */
	User getById(@WebParam(name = "id") Long id);

	/**
	 * 根据用户的ID直接修改密码
	 * 
	 * @param id
	 * @param oldPassword
	 * @param newPassword
	 * @return
	 */
	Result changePassword(@WebParam(name = "id") Long id, @WebParam(name = "oldPassword") String oldPassword,
			@WebParam(name = "newPassword") String newPassword);
}
