package org.fkjava.j1604.user.dto;

import javax.xml.bind.annotation.XmlType;

@XmlType(name = "User", namespace = "http://dto.user.j1604.fkjava.org/")
public class User {

	private String loginName;
	private String password;

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
