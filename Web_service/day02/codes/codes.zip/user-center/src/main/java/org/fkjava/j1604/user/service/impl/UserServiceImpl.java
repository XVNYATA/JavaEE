package org.fkjava.j1604.user.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.jws.WebParam;
import javax.jws.WebService;

import org.fkjava.j1604.user.dto.User;
import org.fkjava.j1604.user.exception.PassowrdNotMatchException;
import org.fkjava.j1604.user.exception.UserAlreadyExistsException;
import org.fkjava.j1604.user.exception.UserNotFoundException;
import org.fkjava.j1604.user.service.UserService;

@WebService(endpointInterface = "org.fkjava.j1604.user.service.UserService", serviceName = "UserService", portName = "UserService")
public class UserServiceImpl implements UserService {

	/**
	 * 使用一个Map模拟用户的数据库，key是登录名，value是User对象
	 */
	private Map<String, User> map = new HashMap<>();

	@Override
	public User login(@WebParam(name = "loginName") String loginName, 
			@WebParam(name = "password") String password)
			throws UserNotFoundException, PassowrdNotMatchException {
		User user = map.get(loginName);
		if (user == null) {
			// 用户不存在，抛出异常
			throw new UserNotFoundException();
		} else if (user.getPassword().equals(password)) {
			// 密码相等，表示登陆成功，返回User对象
			return user;
		} else {
			// 其他情况，表示登陆密码不匹配
			throw new PassowrdNotMatchException();
		}
	}

	@Override
	public User getByLoginName(String loginName) {
		User user = map.get(loginName);
		if (user == null) {
			// 用户不存在，抛出异常
			throw new UserNotFoundException();
		}
		return user;
	}

	@Override
	public void register(String loginName, String password) throws UserAlreadyExistsException {
		User old = map.get(loginName);
		if (old != null) {
			throw new UserAlreadyExistsException();
		}
		User user = new User();
		user.setLoginName(loginName);
		user.setPassword(password);

		map.put(loginName, user);
	}
}
