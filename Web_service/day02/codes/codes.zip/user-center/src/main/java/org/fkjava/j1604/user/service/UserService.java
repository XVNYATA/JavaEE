package org.fkjava.j1604.user.service;

import javax.jws.WebParam;
import javax.jws.WebService;

import org.fkjava.j1604.user.dto.User;
import org.fkjava.j1604.user.exception.PassowrdNotMatchException;
import org.fkjava.j1604.user.exception.UserAlreadyExistsException;
import org.fkjava.j1604.user.exception.UserNotFoundException;

@WebService
public interface UserService {

	/**
	 * 登陆，里面会比较密码是否匹配
	 * 
	 * @param loginName
	 * @param password
	 * @return
	 * @throws UserNotFoundException
	 * @throws PassowrdNotMatchException
	 */
	User login(@WebParam(name = "loginName") String loginName, 
			@WebParam(name = "password") String password) 
					throws UserNotFoundException, PassowrdNotMatchException;

	/**
	 * 根据登录名获取User对象，返回的信息不包含密码
	 * 
	 * @param loginName
	 * @return
	 * @throws UserNotFoundException
	 */
	User getByLoginName(String loginName) throws UserNotFoundException;

	/**
	 * 注册成功后，不出现异常，也不返回值。
	 * 
	 * @param loginName
	 *            注册的登录名
	 * @param password
	 *            注册的密码，不需要两次输入。两次输入的判断应该在客户端执行的。
	 * @throws UserAlreadyExistsException
	 *             如果登录名已经存在，抛出此异常。
	 */
	void register(String loginName, String password) throws UserAlreadyExistsException;
}
