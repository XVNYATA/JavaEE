package org.fkjava.j1604.user.exception;

import javax.xml.ws.WebFault;

@WebFault(name = "UserNotFound", targetNamespace = "http://exception.user.j1604.fkjava.org/")
public class UserNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
