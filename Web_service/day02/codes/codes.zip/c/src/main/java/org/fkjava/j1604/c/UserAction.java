package org.fkjava.j1604.c;

import org.fkjava.j1604.ws.a.UserService;
import org.fkjava.j1604.ws.a.dto.Result;
import org.fkjava.j1604.ws.a.dto.User;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private User user;

	// UserService一定要有set方法
	private UserService userService;

	public String getLogin() {
		// System.out.println("显示登陆页面");
		return SUCCESS;
	}

	public String login() {
		// UserService userService =
		// this.applicationContext.getBean(UserService.class);
		// System.out.println("执行登陆操作");

		// 在实际工作中，调用远程的服务的代码，其实是放到本地的Service层里面的。
		// 这里为了简化代码，才直接在Action里面调用
		Result result = userService.login(user);
		if (result.getCode() == 2) {
			// 查询用户信息
			Long id = Long.parseLong(result.getMessage());
			user = userService.getById(id);

			// 把User放到session
			ActionContext.getContext().getSession().put("user", user);

			return SUCCESS;
		} else {
			ActionContext.getContext().put("message", result.getMessage());
			return INPUT;
		}

	}

	public String info() {
		// System.out.println("显示用户信息");
		return SUCCESS;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}
}
