package org.fkjava.j1604.c;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.fkjava.j1604.ws.a.UserService;
import org.fkjava.j1604.ws.a.dto.Result;
import org.fkjava.j1604.ws.a.dto.User;

public class Test {

	public static void main(String[] args) {
		JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
		factoryBean.setServiceClass(UserService.class);
		factoryBean.setAddress("http://192.168.10.222:8080/services/user");

		UserService userService = (UserService) factoryBean.create();

		User user = new User();
		user.setLoginName("test1");
		user.setPassword("1234");

		Result result = userService.login(user);
		System.out.println(result.getCode());
	}
}
