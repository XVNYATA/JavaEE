package org.fkjava.j1604.ws.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

@XmlType(namespace = "http://ws.j1604.fkjava.org/a/dto")
@XmlAccessorType(value = XmlAccessType.FIELD)
public class User {

	private Long id;
	private String loginName;
	/**
	 * 密码不能通过WebService返回给客户端。如果使用 <code> @XmlTransient </code>
	 * 注解会导致整个passowrd属性都不出现在服务种。<br>
	 * 为了让注册的时候还是有password，那么就不能使用此主键，只能在查询到User对象以后，克隆一份，把新的对象里面的密码去掉。
	 */
	// @XmlTransient
	private String password;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
