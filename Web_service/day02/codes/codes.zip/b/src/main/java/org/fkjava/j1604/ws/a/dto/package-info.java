@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.j1604.fkjava.org/a/dto")
package org.fkjava.j1604.ws.a.dto;
