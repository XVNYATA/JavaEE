package org.fkjava.j1604.ws.b.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.j1604.ws.a.UserService;
import org.fkjava.j1604.ws.a.dto.Result;
import org.fkjava.j1604.ws.a.dto.User;
import org.fkjava.j1604.ws.a.impl.UserServiceImplService;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 显示注册页面
		request.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 执行注册操作
		String loginName = request.getParameter("loginName");
		String password = request.getParameter("password");
		String confirmPassword = request.getParameter("confirmPassword");

		if (password.equals(confirmPassword)) {
			// 获得一个服务端的Service，实际上调用的方法都是通过这个Service来发送到服务器的
			// 但是这个Service并没有注册的方法
			UserServiceImplService implService = new UserServiceImplService();

			// 获得服务器暴露出来的接口的代理，执行接口的代理方法，其实就是通过implService对象发送请求到服务。
			UserService service = implService.getUserServiceImplPort();

			// 密码正确的，可以执行注册。注册成功以后，返回到登陆页面；注册失败回到注册页面。

			User user = new User();
			user.setLoginName(loginName);
			user.setPassword(password);

			Result result = service.register(user);
			if (result.getCode() == 0) {
				// 注册成功，重定向到登陆页面
				response.sendRedirect("login");
			} else {
				// 注册失败
				request.setAttribute("message", result.getMessage());
				this.doGet(request, response);
			}
		} else {
			// 回到注册页面
			request.setAttribute("message", "两次输入的密码不同");
			this.doGet(request, response);
		}
	}

}
