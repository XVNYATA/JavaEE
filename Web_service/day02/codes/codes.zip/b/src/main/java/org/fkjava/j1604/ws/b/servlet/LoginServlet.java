package org.fkjava.j1604.ws.b.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.fkjava.j1604.ws.a.UserService;
import org.fkjava.j1604.ws.a.dto.Result;
import org.fkjava.j1604.ws.a.dto.User;
import org.fkjava.j1604.ws.a.impl.UserServiceImplService;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginServlet() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 显示界面
		request.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 执行登陆
		UserServiceImplService implService = new UserServiceImplService();
		UserService service = implService.getUserServiceImplPort();

		User user = new User();
		String loginName = request.getParameter("loginName");
		String password = request.getParameter("password");
		user.setLoginName(loginName);
		user.setPassword(password);
		Result result = service.login(user);

		if (result.getCode() == 2) {
			// 登陆成功，重定向到info显示用户信息
			// 登陆成功以后，message里面的是用户的id，放到sessin去
			HttpSession session = request.getSession();
			session.setAttribute("userId", result.getMessage());

			// 直接查询用户信息
			user = service.getById(Long.parseLong(result.getMessage()));
			session.setAttribute("user", user);

			response.sendRedirect("info.jsp");
		} else {
			request.setAttribute("message", result.getMessage());
			this.doGet(request, response);
		}
	}
}
