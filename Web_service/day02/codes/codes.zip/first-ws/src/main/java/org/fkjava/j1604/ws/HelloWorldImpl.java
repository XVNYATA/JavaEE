package org.fkjava.j1604.ws;

import javax.jws.WebService;

@WebService(endpointInterface = "org.fkjava.j1604.ws.HelloWorld", serviceName = "world")
public class HelloWorldImpl implements HelloWorld {

	public String say(String text) {
		System.out.println("服务器输出: " + text);
		return "Hi, " + text;
	}

}
