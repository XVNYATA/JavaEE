package org.fkjava.j1604.ws;

import javax.xml.ws.Endpoint;

public class Server {

	public static void main(String[] args) {
		HelloWorld hw = new HelloWorldImpl();

		String address = "http://localhost:9001/hello";

		Endpoint.publish(address, hw);
	}
}
