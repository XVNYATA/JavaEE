package org.fkjava.j1604.ws;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

public class Client {

	public static void main(String[] args) {
		JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
		factory.setServiceClass(HelloWorld.class);
		factory.setAddress("http://127.0.0.1:9001/hello");

		// 创建一个客户端代理
		HelloWorld hw = (HelloWorld) factory.create();
		System.out.println(hw);

		String x = hw.say("拉登");
		System.out.println("服务器返回: " + x);
	}
}
