package org.fkjava.j1604.ws;

import javax.jws.WebService;

@WebService(endpointInterface = "org.fkjava.j1604.ws.HelloWorld",
    serviceName = "helloWorld")
public class HelloWorldImpl implements HelloWorld
{
    public String sayHi( String text )
    {
        System.out.println("服务器的实现类里面输出的: " + text);
        try
        {
            Thread.sleep(10 * 1000);
        }catch(Exception ex)
        {
            ex.printStackTrace();
        }

        return "Hi, " + text;
    }
}
