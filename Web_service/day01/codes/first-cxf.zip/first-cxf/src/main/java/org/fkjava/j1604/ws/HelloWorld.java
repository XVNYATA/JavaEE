package org.fkjava.j1604.ws;

import javax.jws.WebService;


@WebService
public interface HelloWorld
{
    String sayHi( String text );
}
