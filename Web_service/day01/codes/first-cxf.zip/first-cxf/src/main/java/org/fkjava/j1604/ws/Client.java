package org.fkjava.j1604.ws;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

public class Client
{
    public static void main(String[] args)
    {
        // 创建一个JAX-WS的工厂Bean
        JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();

        // 配置拦截器
        //factory.getInInterceptors().add(new LoggingInInterceptor());
        //factory.getOutInterceptors().add(new LoggingOutInterceptor());

        // 设置服务器接口的类型
        factory.setServiceClass(HelloWorld.class);

        // 设置工厂Bean连接到指定的URL（WEB服务的地址）
        factory.setAddress("http://localhost:9000/helloWorld");

        // 直接使用工厂Bean创建一个WEB服务的实例
        // 这里其实是自动通过动态代理的方式实现的
        HelloWorld client = (HelloWorld) factory.create();

        // 执行下面的方法的时候，其实会连接到服务器去调用服务器的方法！
        String reply = client.sayHi("奥巴马");
        System.out.println("Server said: " + reply);
    }
}
