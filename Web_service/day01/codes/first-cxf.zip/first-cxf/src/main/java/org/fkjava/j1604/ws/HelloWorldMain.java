package org.fkjava.j1604.ws;

import javax.xml.ws.Endpoint;
import org.apache.cxf.jaxws.JaxWsServerFactoryBean;

public class HelloWorldMain
{
    public static void main(String[] args)
    {
        
        // 创建一个服务的实现类
        HelloWorld implementor = new HelloWorldImpl();

        // 这个就是WEB服务的地址，到时候给客户端使用的！
        String address = "http://localhost:9000/helloWorld";
        // 发布WEB服务
        Endpoint.publish(address, implementor);
        

/*
        HelloWorldImpl implementor = new HelloWorldImpl();
        JaxWsServerFactoryBean svrFactory = new JaxWsServerFactoryBean();
        svrFactory.setServiceClass(HelloWorld.class);
        svrFactory.setAddress("http://localhost:9000/helloWorld");
        svrFactory.setServiceBean(implementor);
        svrFactory.create();
*/
    }
}
