package org.fkjava.hibernate.test;

import java.util.Arrays;
import java.util.List;

import org.fkjava.hibernate.domain.Student;
import org.fkjava.hibernate.domain.Teacher;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.service.ServiceRegistry;

/**
 * Query_1
 * @author LEE.SIU.WAH
 * @email lixiaohua7@163.com
 * @date 2015年4月13日 上午9:31:04
 * @version 1.0
 */
public class Query_1 {

	public static void main(String[] args) {
		// 第一步：创建Configuration
		Configuration configuration = new Configuration() // 加载hibernate.properties
		       .configure(); // 加载hibernate.cfg.xml
		// 第二步：创建服务注册对象
		ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
						.applySettings(configuration.getProperties()).build();
		// 第三步：创建SessionFactory
		SessionFactory sf = configuration.buildSessionFactory(serviceRegistry);
		// 第四步：创建Session
		Session session = sf.openSession();
		// 第五步：开启事务
		Transaction transaction = session.beginTransaction();
		// 第六步：利用 Session完成所有的持久化操作
		
		// 查询所有的学生
		// addEntity(Class entityType) : 实体查询
//		SQLQuery sqlQuery = session.createSQLQuery("select * from stu_info");
//		sqlQuery.addEntity(Student.class); // 实体查询  我是查询学生对象
//		List<Student> students = sqlQuery.list();
//				
//		students.forEach(s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		
//		List<Student> students = session.createSQLQuery("select * from stu_info")
//				.addEntity("org.fkjava.hibernate.domain.Student") // 实体查询
//				.list();
//		students.forEach(s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		// addScalar(String columnAlias) : 标量查询
//		List<Object[]> lists = session.createSQLQuery("select s.stu_name, s.stu_age from stu_info as s").list();
//		lists.forEach(arr ->{
//			System.out.println(Arrays.toString(arr));
//		});
		
//		List<Object[]> lists = session.createSQLQuery("select * from stu_info as s")
//				.addScalar("s.stu_name") // 标量查询
//				.addScalar("s.stu_age") // 标量查询
//				.list();
//		lists.forEach(arr ->{
//			System.out.println(Arrays.toString(arr));
//		});
		
		// addJoin(String tableAlias, String path) : 关联查询
//		List<Object[]> lists = session.createSQLQuery("SELECT s.*,t.* FROM stu_info AS s, tea_info AS t WHERE s.t_id = t.tea_id")
//		        .addEntity("s",  Student.class) // 实体查询
//		        .addEntity("t", Teacher.class)// 实体查询
////		        .addJoin("t", "s.teacher") // 关联查询 (s.学生持久类中的关联属性) join 
//		        .addScalar("s.stu_name") // 标量查询
//		        .list();
//			    lists.forEach(arr ->{
//			    	System.out.println(Arrays.toString(arr));
//			    });
//		
		// sql命名查询 上面的查询封装成命名查询 
//		List<Object[]> lists = session.getNamedQuery("sql_2").list();
//		lists.forEach(arr ->{
//			System.out.println(Arrays.toString(arr));
//		});
		
		// 调用存储过程
//		List<Student> lists = session.getNamedQuery("call_proc").setParameter(0, 20).list();
//		lists.forEach(s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		
//		List<Student> lists = session.createSQLQuery("{call query_stu(?)}")
//					.addEntity(Student.class)
//					.setParameter(0, 20)
//					.list();
//		lists.forEach(s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
//		
		
		
		// 第七步：事务提交或回滚
		transaction.commit();
		// 第八步：关闭Session与SessionFactory
		session.close();
		sf.close();

	}

}
