package org.fkjava.hibernate.firstLeaveCache;

import java.util.List;

import org.fkjava.hibernate.bean.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.stat.Statistics;

	
/**
 * @Author xlei
 * @Email dlei0009@163.com
 * @Tel 18665616520
 * @QQ  251425887
 * @From http://www.fkjava.org
 * @Date 2016年8月20日上午10:57:09
 * 
 */
public class Hibernate_线程安全的会话 {
	public static void main(String[] args) {
		try {
			/** 1.加载核心配置文件  */ 
			Configuration configuration = new Configuration()  // 只会加载hibernate.properties文件
			.configure(); // 可以加载hibernate.cfg.xml文件
			
			/** 2.得到一个服务注册对象  */
			ServiceRegistry serviceRegistry =
              new StandardServiceRegistryBuilder().applySettings(configuration.getProperties())
              .build();
			
			/** 3.得到一个连接工厂 : 连接工厂一初始化表就开始自动创建 */
			SessionFactory sf = configuration.buildSessionFactory(serviceRegistry);
			
			System.out.println(sf);

			
//			Session session1 = sf.openSession();
			
//			Session session = sf.openSession();
			
//			System.out.println(session1 == session);  // false
			
			// 线程安全的会话 
			// 根据线程得到对应线程安全的会话
			Session session = sf.getCurrentSession();
			Session session1 = sf.getCurrentSession();
			System.out.println(session == session1); // true
			
			Transaction tx = session.beginTransaction() ;  // 线程安全的会话 必须使用事物
			
			Book book = (Book) session.get(Book.class, 2);
			System.out.println(book);
			
			tx.commit();  // 事物提交 线程安全的会话会自动关闭  
//			session.close();
			sf.close();
		
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}



	
}









