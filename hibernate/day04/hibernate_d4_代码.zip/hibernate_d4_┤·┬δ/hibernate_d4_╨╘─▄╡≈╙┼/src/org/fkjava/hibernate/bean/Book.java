package org.fkjava.hibernate.bean;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;

@Entity
@Table(name="Book")
// 二级缓存此对象 使用myCache缓存策略
@Cache(usage=CacheConcurrencyStrategy.READ_WRITE, region="myCache")
// 定义了一个最低价格参数 minPrice  -- 过滤参数
@FilterDef(name="priceFilter", parameters={@ParamDef(name="minPrice", type="double")})
// 使用priceFilter这个数据过滤 当前持久化对象中的价格必须 >  minPrice   过滤条件
@Filter(name="priceFilter", condition="price > :minPrice")
public class Book {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id ;
	private String name ;
	private BigDecimal price ;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", price=" + price + "]";
	}
	
	
}
