package org.fkjava.hibernate.firstLeaveCache;

import org.fkjava.hibernate.bean.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

	
/**
 * @Author xlei
 * @Email dlei0009@163.com
 * @Tel 18665616520
 * @QQ  251425887
 * @From http://www.fkjava.org
 * @Date 2016年8月20日上午10:57:09
 * 
 */
public class Hibernate_一级缓存 {
	public static void main(String[] args) {
		try {
			/** 1.加载核心配置文件  */ 
			Configuration configuration = new Configuration()  // 只会加载hibernate.properties文件
			.configure(); // 可以加载hibernate.cfg.xml文件
			
			/** 2.得到一个服务注册对象  */
			ServiceRegistry serviceRegistry =
              new StandardServiceRegistryBuilder().applySettings(configuration.getProperties())
              .build();
			
			/** 3.得到一个连接工厂 : 连接工厂一初始化表就开始自动创建 */
			SessionFactory sf = configuration.buildSessionFactory(serviceRegistry);
			
			System.out.println(sf);
			
			/** 4.得到一个会话   */
			Session session = sf.openSession();
			/** 5.得到事物对象  */
			Transaction tx = session.beginTransaction();
			
			User u = new User();
			u.setId(1);
			
			// user 持久化对象 -- 一定在session中 --- 在一级缓存中 ---在内存
			User user = (User) session.get(User.class, 1);
			
			// 在一级缓存中就是持久化对象 
			System.out.println(session.contains(user));
			System.out.println(session.contains(u)); 
			
			// 查询对象的时候 先去一级缓存中查询是否存在这个对象
			// 有就直接返回这个对象 没有就去二级缓存中找 二级缓存中找也没有
			// 就会去数据库中查询。
			User user1 = (User) session.get(User.class, 1);
			System.out.println("ssss:"+(user == user1));
			user1.setName("==========="); // 这里是可以修改的 但是是提交的时候才生效
			session.evict(user1); // 把对象逐出一级缓存  变成脱管状态 所以所有修改都无效了
			System.out.println(session.contains(user1));
			user1.setName("-------------");
			
			tx.commit(); // 事物提交  只会提交在一级缓存中的对象 
			session.close();
			sf.close();
		    
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}









