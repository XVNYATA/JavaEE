package org.fkjava.hibernate.firstLeaveCache;

import java.util.List;

import org.fkjava.hibernate.bean.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.stat.Statistics;

	
/**
 * @Author xlei
 * @Email dlei0009@163.com
 * @Tel 18665616520
 * @QQ  251425887
 * @From http://www.fkjava.org
 * @Date 2016年8月20日上午10:57:09
 * 
 */
public class Hibernate_二级缓存 {
	public static void main(String[] args) {
		try {
			/** 1.加载核心配置文件  */ 
			Configuration configuration = new Configuration()  // 只会加载hibernate.properties文件
			.configure(); // 可以加载hibernate.cfg.xml文件
			
			/** 2.得到一个服务注册对象  */
			ServiceRegistry serviceRegistry =
              new StandardServiceRegistryBuilder().applySettings(configuration.getProperties())
              .build();
			
			/** 3.得到一个连接工厂 : 连接工厂一初始化表就开始自动创建 */
			SessionFactory sf = configuration.buildSessionFactory(serviceRegistry);
			
			System.out.println(sf);
		
			
		    // 9 
//			List<User> users = session.createQuery("select u from User u where u.id <= 9 ").list();
//			System.out.println(users);
			
			// 第一次查询书
//			query(sf);
//			query(sf);
//			query(sf);
//			query(sf);
			
//			Session session1 = sf.openSession();
			
//			Session session = sf.openSession();
			
//			System.out.println(session1 == session);
			
			// 
			
//			Session session = sf.openSession();
//			Transaction tx = session.beginTransaction() ;
//			System.out.println("----------------------");
//			// 二级缓存已经存在这本书对象 所以不会去数据库查询。
//			Book book = (Book) session.get(Book.class, 2);
//			System.out.println(book);
			
		
//			Session session1 = sf.openSession();
//			Transaction tx1 = session1.beginTransaction() ;
//			System.out.println("----------------------");
//			// 二级缓存已经存在这本书对象 所以不会去数据库查询。
//			Book book1 = (Book) session.get(Book.class, 111);
//			System.out.println(book);
//
//			
//			Statistics statistics = sf.getStatistics();
//			System.out.println("命中："+statistics.getSecondLevelCacheHitCount());
//			System.out.println("错失："+statistics.getSecondLevelCacheMissCount());
			
	/*		
		//   a. 获取缓存对象：
			// 二级缓存对象 
		    Cache cache =  sf.getCache();
		    // 二级缓存中是否包含了id为20的book对象
		    System.out.println(cache.containsEntity(Book.class, 101));
		    System.out.println(cache.containsEntity("org.fkjava.hibernate.bean.Book", 1));

		    // 二级缓存中踢出某个缓存的对象
//		    cache.evictEntity(Book.class,100);
		    
		    //从二级缓存中踢出指定类型所有的对象： 
//		    cache.evictEntityRegion(User.class);
//		    cache.evictEntityRegion(Book.class);
		    
		    Session session = sf.openSession();
			Transaction tx = session.beginTransaction() ;
			System.out.println("----------------------");
			// 二级缓存已经存在这本书对象 所以不会去数据库查询。
		    Book book = (Book) session.get(Book.class, 2);
		    System.out.println(book);
		    

		    
		   //c. 清空二级缓存中所有对象:
//		    cache.evictAllRegions();
		    
//		    System.out.println(cache.containsEntity("org.fkjava.hibernate.bean.Book", 1));
//			
		    */
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void query1(SessionFactory sf) {
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction() ;
		
		List<Book> books = session.createQuery("select b from Book b").list();
		
//		System.out.println(books.toString());
		
	}

	private static void query(SessionFactory sf) {
		Session session = sf.openSession();
		
		Transaction tx = session.beginTransaction() ;
		
		List<Book> books = session.createQuery("select b from Book b").setCacheable(true).list();
		
//		System.out.println(books.toString());
		
	}
}









