﻿package org.fkjava.hibernate.test;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Root;

import org.fkjava.hibernate.domain.Student;

public class Query_3 {

	public static void main(String[] args) {
		// 第一步：创建EntityManagerFactory (SessionFactory)
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("fkjava");
		// 第二步：创建EntityManager(Session)
		EntityManager em = emf.createEntityManager();
		// 第三步：获取事务
		EntityTransaction transaction = em.getTransaction();
		// 第四步：开启事务
		transaction.begin();
		// 第五步：利用EntityManager完成所有的操作
		
		// 查询所有的学生
//		/** 获取CriteriaBuilder对象 */
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		/** 构建查询对象，传进去的参数，是本次查询的返回值 */
//		CriteriaQuery<Student> cq = builder.createQuery(Student.class);
//		/** 查询哪个持久化类, 返回一个root对象，该对象对持久化类中的属性做了封装  */
//		Root<Student> root = cq.from(Student.class);
//		List<Student> lists = em.createQuery(cq).getResultList();
//		lists.forEach(s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		
//		// 查询一列
//		/** 获取CriteriaBuilder对象 */
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		/** 构建查询对象，传进去的参数，是本次查询的返回值 */
//		CriteriaQuery<String> cq = builder.createQuery(String.class);
//		/** 查询哪个持久化类, 返回一个root对象，该对象对持久化类中的属性做了封装  */
//		Root<Student> root = cq.from(Student.class);
//		/** 获取name */
//		Path<String> name = root.get("name");
//		/** 查询一列 */
//		cq.select(name);
//		
//		List<String> lists = em.createQuery(cq).getResultList();
//		System.out.println(lists);
		
		
		// 查询多列
//		/** 获取CriteriaBuilder对象 */
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		/** 构建查询对象，传进去的参数，是本次查询的返回值 */
//		CriteriaQuery<Object[]> cq = builder.createQuery(Object[].class);
//		/** 查询哪个持久化类, 返回一个root对象，该对象对持久化类中的属性做了封装  */
//		Root<Student> root = cq.from(Student.class);
//		/** 获取name */
//		Path<String> name = root.get("name");
//		/** 获取name */
//		Path<Integer> age = root.get("age");
//		/** 查询一列 */
//		cq.multiselect(name, age);
//		List<Object[]> lists = em.createQuery(cq).getResultList();
//		System.out.println(lists);
		
		
		// 添加查询条件
//		/** 获取CriteriaBuilder对象 */
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		/** 构建查询对象，传进去的参数，是本次查询的返回值 */
//		CriteriaQuery<Student> cq = builder.createQuery(Student.class);
//		/** 查询哪个持久化类, 返回一个root对象，该对象对持久化类中的属性做了封装  */
//		Root<Student> root = cq.from(Student.class);
//		
//		/** 获取name */
//		Path<String> name = root.get("name");
//		/** 获取age */
//		Path<Integer> age = root.get("age");
//		/** 添加查询条件 */
//		cq.where(builder.like(name, "%小%"), builder.between(age, 19, 200));
//		
//		List<Student> lists = em.createQuery(cq).getResultList();
//		lists.forEach(s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		
//		// 排序
//		/** 获取CriteriaBuilder对象 */
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		/** 构建查询对象，传进去的参数，是本次查询的返回值 */
//		CriteriaQuery<Student> cq = builder.createQuery(Student.class);
//		/** 查询哪个持久化类, 返回一个root对象，该对象对持久化类中的属性做了封装  */
//		Root<Student> root = cq.from(Student.class);
//		
//		Path<String> age = root.get("age");
//		/** 添加排序 */
//		cq.orderBy(builder.desc(age));
//		List<Student> lists = em.createQuery(cq).getResultList();
//		lists.forEach(s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		
		// 统计函数
//		/** 获取CriteriaBuilder对象 */
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		/** 构建查询对象，传进去的参数，是本次查询的返回值 */
//		CriteriaQuery<Integer> cq = builder.createQuery(Integer.class);
//		/** 查询哪个持久化类, 返回一个root对象，该对象对持久化类中的属性做了封装  */
//		Root<Student> root = cq.from(Student.class);
//		
//		Path<Integer> age = root.get("age");
//		cq.select(builder.sum(age));
//
//		Integer res = em.createQuery(cq).getSingleResult();
//		System.out.println(res);
		
		
//		// 关联查询
//		/** 获取CriteriaBuilder对象 */
//		CriteriaBuilder builder = em.getCriteriaBuilder();
//		/** 构建查询对象，传进去的参数，是本次查询的返回值 */
//		CriteriaQuery<Student> cq = builder.createQuery(Student.class);
//		/** 查询哪个持久化类, 返回一个root对象，该对象对持久化类中的属性做了封装  */
//		Root<Student> root = cq.from(Student.class);
//		/** 关联查询 */
//		root.join("teacher", JoinType.INNER);
//		/** 获取老师属性id */
//		Path<Integer> t_id = root.get("teacher").get("id");
//		cq.where(builder.equal(t_id, 1));
//		List<Student> lists = em.createQuery(cq).getResultList();
//		lists.forEach(s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		// 抓取连接
		/** 获取CriteriaBuilder对象 */
		CriteriaBuilder builder = em.getCriteriaBuilder();
		/** 构建查询对象，传进去的参数，是本次查询的返回值 */
		CriteriaQuery<Student> cq = builder.createQuery(Student.class);
		/** 查询哪个持久化类, 返回一个root对象，该对象对持久化类中的属性做了封装  */
		Root<Student> root = cq.from(Student.class);
		/** 抓取延迟的属性 */
		root.fetch("teacher", JoinType.INNER);
		
		List<Student> lists = em.createQuery(cq).getResultList();
		lists.forEach(s ->{
			System.out.println(s.getName() + "==" + s.getAge());
		});
		
		// 第六步：事务提交或回滚commit|rollback
		transaction.commit();
		// 第七步：关闭
		em.close();
		emf.close();
		
	}

}
