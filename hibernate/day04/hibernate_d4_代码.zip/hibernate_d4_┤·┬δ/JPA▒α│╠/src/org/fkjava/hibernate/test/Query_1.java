﻿package org.fkjava.hibernate.test;

import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.fkjava.hibernate.domain.Student;
import org.fkjava.hibernate.domain.Teacher;


public class Query_1 {

	public static void main(String[] args) {
		// 第一步：创建EntityManagerFactory (SessionFactory)
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("fkjava");
		// 第二步：创建EntityManager(Session)
		EntityManager em = emf.createEntityManager();
		// 第三步：获取事务
		EntityTransaction transaction = em.getTransaction();
		// 第四步：开启事务
		transaction.begin();
		// 第五步：利用EntityManager完成所有的操作
		// jpql == hql
//		List<Student> lists = em.createQuery("select s from Student as s", Student.class).getResultList();
//		lists.forEach( s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
//		List<Student> lists = em.createQuery("from Student", Student.class).getResultList();
//		lists.forEach( s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
//		List<Map<String, Object>> lists = em.createQuery("select new map(name as name, age as age) from Student").getResultList();
//		lists.forEach( m ->{
//			System.out.println(m);
//		});
		
//		int pageIndex = 2;
//		int pageSize =2;
//		List<Student> lists = em.createQuery("from Student", Student.class)
//				.setFirstResult((pageIndex - 1) * pageSize)
//				.setMaxResults(pageSize)
//				.getResultList();
//		lists.forEach( s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		
//		List<Student> lists = em.createQuery("select s from Student s join fetch s.teacher", Student.class).getResultList();
//		lists.forEach( s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		// 命名查询
		List<Student> lists = em.createNamedQuery("query_1").getResultList();
		lists.forEach( s ->{
			System.out.println(s.getName() + "==" + s.getAge());
		});
		
		
		// 第六步：事务提交或回滚commit|rollback
		transaction.commit();
		// 第七步：关闭
		em.close();
		emf.close();
		
	}

}
