﻿package org.fkjava.hibernate.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.fkjava.hibernate.domain.Student;
import org.fkjava.hibernate.domain.Teacher;


public class InsertDataTest {

	public static void main(String[] args) {
		// 第一步：创建EntityManagerFactory   SessionFactory 
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("fkjava");
		// 第二步：创建EntityManager    Session
		EntityManager em = emf.createEntityManager();
		// 第三步：获取事务    Transaction
		EntityTransaction transaction = em.getTransaction();
		// 第四步：开启事务
		transaction.begin();
		// 第五步：利用 EntityManager完成所有的持久化操作
		
		Teacher t1 = new Teacher();
		t1.setName("唐僧");
		t1.setDept("取经部");
		t1.setJob("长老");
		t1.setAge(30);
		em.persist(t1);
		
		Student s1 = new Student();
		s1.setName("孙悟空");
		s1.setAge(500);
		s1.setPhone("13888888888");
		s1.setScore(10.5f);
		s1.setTeacher(t1);
		em.persist(s1);
		
		Student s2 = new Student();
		s2.setName("猪八戒");
		s2.setAge(300);
		s2.setPhone("13888888887");
		s2.setScore(50.8f);
		s2.setTeacher(t1);
		em.persist(s2);
		
		Student s3 = new Student();
		s3.setName("沙僧");
		s3.setAge(200);
		s3.setPhone("13888888886");
		s3.setScore(59.6f);
		s3.setTeacher(t1);
		em.persist(s3);
		
		
		
		Teacher t2 = new Teacher();
		t2.setName("李小一");
		t2.setDept("技术部");
		t2.setJob("架构师");
		t2.setAge(32);
		em.persist(t2);
		
		Student s4 = new Student();
		s4.setName("李小二");
		s4.setAge(20);
		s4.setPhone("13788888888");
		s4.setScore(89.4f);
		s4.setTeacher(t2);
		em.persist(s4);
		
		Student s5 = new Student();
		s5.setName("李小三");
		s5.setAge(19);
		s5.setPhone("13788888887");
		s5.setScore(55.5f);
		s5.setTeacher(t2);
		em.persist(s5);
		
		
		Student s6 = new Student();
		s6.setName("李小四");
		s6.setAge(18);
		s6.setPhone("13788888886");
		s6.setScore(62.8f);
		s6.setTeacher(t2);
		em.persist(s6);
		
		
		// 第七步：事务提交或回滚
		transaction.commit();
		// 第八步：关闭EntityManager与EntityManagerFactory
		em.close();
		emf.close();

	}

}
