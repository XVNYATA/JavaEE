﻿package org.fkjava.hibernate.test;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.fkjava.hibernate.domain.Teacher;


public class CRUD操作 {

	public static void main(String[] args) {
		// 第一步：创建EntityManagerFactory (SessionFactory)
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("fkjava");
		// 第二步：创建EntityManager(Session)
		EntityManager em = emf.createEntityManager();
		// 第三步：获取事务
		EntityTransaction transaction = em.getTransaction();
		// 第四步：开启事务
		transaction.begin();
		// 第五步：利用EntityManager完成所有的操作
		
		/**####### 添加  ######### */
//		Teacher t = new Teacher(); // 瞬态
//		t.setAge(20);
//		t.setName("李小明");
//		t.setDept("开发部");
//		t.setJob("项目经理");
//		em.persist(t); // 持久化状态
//		System.out.println(em.contains(t)); // 判断一个对象是不是持久化状态
		
//		Teacher t = new Teacher(); // 瞬态
//		t.setAge(20);
//		t.setName("李小明");
//		t.setDept("开发部");
//		t.setJob("项目经理");
//		Teacher t1 = em.merge(t); // t1 持久化状态
//		System.out.println(em.contains(t1)); 
		

		/**####### 根据主键id做查询  ######### */
//		Teacher t = em.find(Teacher.class, 1); // t 持久化状态
//		System.out.println(em.contains(t)); // 判断一个对象是不是持久化状态
		
		

		/**####### 修改  ######### */
		//  a. 持久化状态下：
	    Teacher t = em.find(Teacher.class, 1); // t 持久化状态
	    // 从EntityManager的一级缓存中逐出一个对象.(该对象就不是持久化状态的对象).
	    // em.detach(t);
	    t.setAge(300);

	    // b. 脱管状态下：
//	    Teacher t = new Teacher();
//        t.setId(1);
//        t.setAge(100);
//        t.setName("admin");
//        em.merge(t);

	    /**####### 删除  ######### */
//		Teacher t = em.find(Teacher.class, 4); // t 持久化状态
//	    em.remove(t);
		
		// 第六步：事务提交或回滚commit|rollback
		transaction.commit();
		// 第七步：关闭
		em.close();
		emf.close();
		
	}

}
