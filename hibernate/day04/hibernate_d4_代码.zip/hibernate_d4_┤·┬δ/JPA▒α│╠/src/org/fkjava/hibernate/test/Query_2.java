﻿package org.fkjava.hibernate.test;

import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.fkjava.hibernate.domain.Student;


public class Query_2 {

	public static void main(String[] args) {
		// 第一步：创建EntityManagerFactory (SessionFactory)
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("fkjava");
		// 第二步：创建EntityManager(Session)
		EntityManager em = emf.createEntityManager();
		// 第三步：获取事务
		EntityTransaction transaction = em.getTransaction();
		// 第四步：开启事务
		transaction.begin();
		// 第五步：利用EntityManager完成所有的操作
		
		// sql : 实体查询
//		List<Student> lists = em.createNativeQuery("select * from stu_info", Student.class).getResultList();
//		lists.forEach( s ->{
//			System.out.println(s.getName() + "==" + s.getAge());
//		});
		
		// 查询所有的列
//		List<Object[]> lists = em.createNativeQuery("select * from stu_info").getResultList();
//		lists.forEach( s ->{
//			System.out.println(Arrays.toString(s));
//		});
		
		// 查询多张表
		List<Object[]> lists = em.createNativeQuery("select s.*, t.* from stu_info as s, tea_info as t where s.t_id = t.tea_id", "rs").getResultList();
		lists.forEach( s ->{
			System.out.println(Arrays.toString(s));
		});

		// 第六步：事务提交或回滚commit|rollback
		transaction.commit();
		// 第七步：关闭
		em.close();
		emf.close();
		
	}

}
