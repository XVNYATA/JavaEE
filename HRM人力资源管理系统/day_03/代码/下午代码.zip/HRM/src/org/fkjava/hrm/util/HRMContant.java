package org.fkjava.hrm.util;

public class HRMContant {

	//用户信息对应的key值
	public static final String SESSION_USER = "session_user";
	
	//验证码对应的key值
	public static final String VCODE = "vcode";
}
