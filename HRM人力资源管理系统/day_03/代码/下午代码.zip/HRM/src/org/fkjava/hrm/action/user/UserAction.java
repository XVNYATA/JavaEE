package org.fkjava.hrm.action.user;


import java.io.IOException;

import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.service.impl.HrmService;
import org.fkjava.hrm.service.proxy.ServiceProxy;
import org.fkjava.hrm.util.HRMContant;

import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {

	private String loginName;
	private String password;
	private String vcode;
	
	//创建动态代理对象
	ServiceProxy serviceProxy = new ServiceProxy();
	//必须用被代理者的接口来接收
	HrmServiceI hrmService = serviceProxy.bind(new HrmService());
	
	//用户异步登录
	public String userLogin(){
		// TODO Auto-generated method stub
		String tip = "";
		try {
			
			//获取验证码
			String code = (String)ServletActionContext.getRequest().getSession().getAttribute(HRMContant.VCODE);
			if(!code.equals(vcode)){
				tip = "您输入的验证码不正确，请重新新输入！";
			}else{
				//根据用户名以及密码获取用户信息
				User user = hrmService.findUserByNameAndPass(loginName,password);
				if(user!=null){
					//用户不为空  说明用户名密码正确
					ServletActionContext.getRequest().getSession().setAttribute(HRMContant.SESSION_USER, user);
				}else{
					tip = "您输入的用户名或密码不正确，请重新新输入！";
				}
			}
			
			ServletActionContext.getResponse().setCharacterEncoding("utf-8");
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		
		//将信息响应至客户端
		try {
			ServletActionContext.getResponse().getWriter().print(tip);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return NONE;
	}
	
	
	//用户退出
	public String logout() {
		// TODO Auto-generated method stub
         try {
			//将用户信息从session中清除
        	 ServletActionContext.getRequest().getSession().removeAttribute(HRMContant.SESSION_USER);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		
		return LOGIN;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getVcode() {
		return vcode;
	}

	public void setVcode(String vcode) {
		this.vcode = vcode;
	}

	

}
