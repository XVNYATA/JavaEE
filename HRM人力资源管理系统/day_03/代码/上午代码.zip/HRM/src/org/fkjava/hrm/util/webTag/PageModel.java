package org.fkjava.hrm.util.webTag;


/**
 * @Author lin 
 * @Date 2015年12月17日 -- 上午10:04:37
 * @email 1018625267@qq.com
 * @Tel 18677904065
 * 分页实体模型
 */
public class PageModel {
	
	/** 当前页面*/
	private int pageIndex;
	/** 每页的数据数目*/
	private int pageSize = 4;
	/** 总的记录数*/
	private int recordCount;
	
	
	public int getPageIndex() {
		int totalPage = recordCount % pageSize==0?recordCount/pageSize:(recordCount/pageSize)+1;
		//假设当前页码值大于总页码值时，将总页码值赋给当前页码
		pageIndex = pageIndex>totalPage?totalPage:pageIndex;
		System.out.println("recordCount-----"+recordCount+"pageIndex"+pageIndex);
		return pageIndex <= 0? 1:pageIndex;
	}
	public void setPageIndex(int pageIndex) {
		this.pageIndex = pageIndex;
	}


	public int getPageSize() {
		return pageSize;
//		return pageSize < WebConstants.PAGESIZE ? WebConstants.PAGESIZE :pageSize;
	}


	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}


	public int getRecordCount() {
		return recordCount;
	}


	public void setRecordCount(int recordCount) {
		this.recordCount = recordCount;
	}


	/** 获取起始页码*/
	public int getStartNum(){
		return (this.getPageIndex()-1)*this.pageSize;
	}
	/** 获取总页码数*/
	
	
}
