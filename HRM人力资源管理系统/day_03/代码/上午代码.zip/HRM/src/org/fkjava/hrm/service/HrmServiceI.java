package org.fkjava.hrm.service;

import java.util.List;

import org.fkjava.hrm.bean.Dept;
import org.fkjava.hrm.bean.Notice;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.util.webTag.PageModel;

public interface HrmServiceI{

	 //根据用户名以及密码获取用户信息
	User findUserByNameAndPass(String loginName, String password);

    //公告分页查询
	List<Notice> selectNoticeByPage(Notice notice, PageModel pageModel);

}
