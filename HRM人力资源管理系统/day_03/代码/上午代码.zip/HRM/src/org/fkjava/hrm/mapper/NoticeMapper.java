package org.fkjava.hrm.mapper;

import java.util.List;
import java.util.Map;

import org.fkjava.hrm.bean.Notice;

/**
 * NoticeMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-08-13 16:35:27
 * @version 1.0
 */
public interface NoticeMapper {

	//公告分页查询
	List<Notice> selectNoticeByPage(Map<String, Object> params);

	//便于页面实现分页，需要获取总记录数
	int findTotalNum(Map<String, Object> params);



}