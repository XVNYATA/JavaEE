package org.fkjava.hrm.action.notice;



import java.util.List;

import org.fkjava.hrm.bean.Notice;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.service.impl.HrmService;
import org.fkjava.hrm.service.proxy.ServiceProxy;
import org.fkjava.hrm.util.webTag.PageModel;

import com.opensymphony.xwork2.ActionSupport;

public class NoticeAction extends ActionSupport {
	
	private Notice notice;
	private List<Notice> notices;
	
	//创建分页实体   封装查询的参数：比如  页码   每页显示多少条
	PageModel pageModel = new PageModel();
	

	//创建动态代理对象
	ServiceProxy serviceProxy = new ServiceProxy();
	//必须用被代理者的接口来接收
	HrmServiceI hrmService = serviceProxy.bind(new HrmService());
	
     //公告分页查询
	 public String selectNoticeByPage(){
		 try {
			 notices = hrmService.selectNoticeByPage(notice,pageModel);  
			 
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		 return SUCCESS;
	 }


	public Notice getNotice() {
		return notice;
	}


	public void setNotice(Notice notice) {
		this.notice = notice;
	}


	public List<Notice> getNotices() {
		return notices;
	}


	public void setNotices(List<Notice> notices) {
		this.notices = notices;
	}


	public PageModel getPageModel() {
		return pageModel;
	}


	public void setPageModel(PageModel pageModel) {
		this.pageModel = pageModel;
	}
	 
	 
	
	
}
