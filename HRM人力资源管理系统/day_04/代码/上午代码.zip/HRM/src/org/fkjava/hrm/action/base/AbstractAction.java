package org.fkjava.hrm.action.base;

import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.service.impl.HrmService;
import org.fkjava.hrm.service.proxy.ServiceProxy;
import org.fkjava.hrm.util.webTag.PageModel;

import com.opensymphony.xwork2.ActionSupport;

public abstract class AbstractAction extends ActionSupport{

	public String tip;

	//创建动态代理对象
	ServiceProxy serviceProxy = new ServiceProxy();
	//必须用被代理者的接口来接收
	public HrmServiceI hrmService = serviceProxy.bind(new HrmService());
	
	//创建分页实体   封装查询的参数：比如  页码   每页显示多少条
	public PageModel pageModel = new PageModel();

	
	public PageModel getPageModel() {
		return pageModel;
	}

	public void setPageModel(PageModel pageModel) {
		this.pageModel = pageModel;
	}


	public String getTip() {
		return tip;
	}


	public void setTip(String tip) {
		this.tip = tip;
	}
}
