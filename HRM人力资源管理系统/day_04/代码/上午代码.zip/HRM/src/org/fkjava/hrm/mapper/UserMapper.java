package org.fkjava.hrm.mapper;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.fkjava.hrm.bean.User;

/**
 * UserMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-08-13 16:35:27
 * @version 1.0
 */
public interface UserMapper {

	//根据用户名以及密码获取用户信息   
	@Select("SELECT * FROM hrm_user WHERE NAME = #{name} AND pass_word = #{pass}")
	User findUserByNameAndPass(@Param("name")String loginName, @Param("pass")String password);



}