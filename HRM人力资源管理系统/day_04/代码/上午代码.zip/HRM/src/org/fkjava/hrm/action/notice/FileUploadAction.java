package org.fkjava.hrm.action.notice;




import java.io.File;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class FileUploadAction extends ActionSupport {
	
	private File pic;//指定文件信息
	private String picFileName;//文件名
	private String picFileContent;//文件类型
	
	
	public String fileUpload(){
		try {
			//获取项目部署路径
			String projectPath = ServletActionContext.getServletContext().getRealPath("/images/notice");
			System.out.println("projectPath:"+projectPath);
			//如果指定幕布不存在 在创建
			File file = new File(projectPath);
			if(!file.exists()){
				file.mkdirs();
			}
			
			//给文件重命名  防止文件被覆盖
			String newName = UUID.randomUUID().toString() + "." +FilenameUtils.getExtension(picFileName);
			//将文件拷贝至指定目录下
			FileUtils.copyFile(pic, new File(projectPath+File.separator+newName));
			
			//将文件的路径响应给前台页面
			ServletActionContext.getResponse().getWriter().print("/images/notice/"+newName);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return NONE;
	}


	public File getPic() {
		return pic;
	}


	public void setPic(File pic) {
		this.pic = pic;
	}


	public String getPicFileName() {
		return picFileName;
	}


	public void setPicFileName(String picFileName) {
		this.picFileName = picFileName;
	}


	public String getPicFileContent() {
		return picFileContent;
	}


	public void setPicFileContent(String picFileContent) {
		this.picFileContent = picFileContent;
	}
	
	
	
}
