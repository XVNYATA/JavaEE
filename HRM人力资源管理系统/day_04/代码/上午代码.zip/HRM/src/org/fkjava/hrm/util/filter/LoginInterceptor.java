package org.fkjava.hrm.util.filter;

import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.util.HRMContant;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

//登录拦截器
public class LoginInterceptor extends AbstractInterceptor {


	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		// TODO Auto-generated method stub
		//从session中获取用户信息
		User user = (User)ServletActionContext.getRequest().getSession().getAttribute(HRMContant.SESSION_USER);
		//设置字符编码
		ServletActionContext.getRequest().setCharacterEncoding("utf-8");
		ServletActionContext.getResponse().setCharacterEncoding("utf-8");
		
		//用户为空说明没有登录过
		return user ==null ? Action.LOGIN : invocation.invoke();
	}

}
