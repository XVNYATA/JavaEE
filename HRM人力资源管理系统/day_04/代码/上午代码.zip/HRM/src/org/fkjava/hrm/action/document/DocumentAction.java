package org.fkjava.hrm.action.document;



import java.util.List;
import org.fkjava.hrm.action.base.AbstractAction;
import org.fkjava.hrm.bean.Document;

public class DocumentAction extends AbstractAction {
	
	private Document document;
	private List<Document> documents;
	
		
	//文档分页查询
	public String selectDocumentByPage(){
		try {
			documents = hrmService.selectDocumentByPage(document,pageModel);  
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return SUCCESS;
	}
	
	
     //文档删除
	public String deleteDocument(){
		try {
			hrmService.deleteDocument(document.getId(),document.getUrl());
			tip = "删除成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}




	
	
	
}
