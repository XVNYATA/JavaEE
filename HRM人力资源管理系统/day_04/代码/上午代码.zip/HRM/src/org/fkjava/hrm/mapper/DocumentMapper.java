package org.fkjava.hrm.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.fkjava.hrm.bean.Document;

/**
 * DocumentMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-08-13 16:35:27
 * @version 1.0
 */
public interface DocumentMapper {     

	//获取文档总数量
	int findTotalNum(Map<String, Object> params);

	//文档分页查询
	List<Document> selectDocumentByPage(Map<String, Object> params);

	@Delete("delete from hrm_document where id = #{id}")
	void deleteDocument(int id);
	


}