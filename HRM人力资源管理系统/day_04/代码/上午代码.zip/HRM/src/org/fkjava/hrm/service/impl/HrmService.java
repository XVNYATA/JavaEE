package org.fkjava.hrm.service.impl;


import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.annotation.AutoMapper;
import org.fkjava.hrm.bean.Document;
import org.fkjava.hrm.bean.Notice;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.exception.HRMException;
import org.fkjava.hrm.mapper.DocumentMapper;
import org.fkjava.hrm.mapper.NoticeMapper;
import org.fkjava.hrm.mapper.UserMapper;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.util.HRMContant;
import org.fkjava.hrm.util.webTag.PageModel;

public class HrmService  implements HrmServiceI{
	
	@AutoMapper
	private UserMapper userMapper;
	
	@AutoMapper
	private NoticeMapper noticeMapper;
	
	@AutoMapper
	private DocumentMapper documentMapper;
	
	private Logger logger = Logger.getLogger(HrmService.class);



	 //根据用户名以及密码获取用户信息   
	@Override
	public User findUserByNameAndPass(String loginName, String password) {
		// TODO Auto-generated method stub
		try {
            User user = userMapper.findUserByNameAndPass(loginName,password);
			return user;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("根据用户名以及密码获取用户信息失败！",e);
		}
	}


    //公告分页查询
	@Override
	public List<Notice> selectNoticeByPage(Notice notice, PageModel pageModel) {
		// TODO Auto-generated method stub
		try {
            
			//创建Map集合用户封装查询条件
			Map<String,Object> params = new HashMap<>();
			params.put("notice", notice);
			//便于页面实现分页，需要获取总记录数
			int totalNum = noticeMapper.findTotalNum(params);
			if(totalNum==0){
				return null;
			}
			
			//将公告总数量存放在pageModel中
			pageModel.setRecordCount(totalNum);
			params.put("pageModel", pageModel);
			List<Notice> notices = noticeMapper.selectNoticeByPage(params);
			return notices;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("公告分页查询异常！",e);
		}
	}


	//删除公告
	@Override
	public void deleteNoticeByIds(String[] ids) {
		// TODO Auto-generated method stub
		try {
			noticeMapper.deleteNoticeByIds(ids);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("公告删除失败！",e);
		}
	}

	 //添加公告
	@Override
	public void addNotice(Notice notice) {
		// TODO Auto-generated method stub
		try {
			notice.setCreateDate(new Date());
			User user = (User)ServletActionContext.getRequest().getSession().getAttribute(HRMContant.SESSION_USER);
			notice.setUser(user);
			noticeMapper.save(notice);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("公告添加失败！",e);
		}
	}

	//根据公告的id获取公告信息
	@Override
	public Notice getNoticeById(int id) {
		// TODO Auto-generated method stub
		try {
			return noticeMapper.getNoticeById(id);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("根据公告id获取公告信息失败！",e);
		}
	}


	@Override
	public void updateNotice(Notice notice) {
		// TODO Auto-generated method stub
		try {
			 noticeMapper.update(notice);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("修改失败！",e);
		}
	}

	//###############################文档模块##################################//
	@Override
	public List<Document> selectDocumentByPage(Document document, PageModel pageModel) {
		// TODO Auto-generated method stub
         try {
            
			//创建Map集合用户封装查询条件
			Map<String,Object> params = new HashMap<>();
			params.put("document", document);
			//便于页面实现分页，需要获取总记录数
			int totalNum = documentMapper.findTotalNum(params);
			if(totalNum==0){
				return null;
			}
			
			//将公告总数量存放在pageModel中
			pageModel.setRecordCount(totalNum);
			params.put("pageModel", pageModel);
			List<Document> documents = documentMapper.selectDocumentByPage(params);
			return documents;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("文档分页查询异常！",e);
		}
	}

	//文档删除
	@Override
	public void deleteDocument(int id, String url) {
		// TODO Auto-generated method stub
      try {
    	    //删除数据库中记录
            documentMapper.deleteDocument(id);
            
            //删除本地文件
            //获取项目部署路径   projectpath:   D:/apache-tomcat-8.0.9/webapps/HRM/       url:  /file/document
            String projectpath= ServletActionContext.getServletContext().getRealPath("/");
            
            File file = new File(projectpath+File.separator+url);
            if(file.exists()){
            	//删除文件
            	file.delete();
            }
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("文档删除异常！",e);
		}
	}

}
