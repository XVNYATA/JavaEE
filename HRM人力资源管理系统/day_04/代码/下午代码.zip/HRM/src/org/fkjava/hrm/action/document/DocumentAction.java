package org.fkjava.hrm.action.document;



import java.io.File;
import java.util.List;
import org.fkjava.hrm.action.base.AbstractAction;
import org.fkjava.hrm.bean.Document;
import org.fkjava.hrm.util.HRMContant;

public class DocumentAction extends AbstractAction {
	
	private Document document;
	private List<Document> documents;
	private File file;
	private String fileFileName;//文件名
	private String fileContentType;//文件类型
	
	//文档分页查询
	public String selectDocumentByPage(){
		try {
			documents = hrmService.selectDocumentByPage(document,pageModel);  
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return SUCCESS;
	}
	
	
	//文档删除
	public String deleteDocument(){
		try {
			hrmService.deleteDocument(document.getId(),document.getUrl());
			tip = "删除成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}
	
	//文档添加
	public String addDocument(){
		try {
			hrmService.addDocument(document,file,fileFileName);
			
			tip = "添加成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}
	
	
     //根据文档id获取文档信息
	public String showUpdateDocument(){
		try {
			document = hrmService.getDocumentById(document.getId());

			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}
		return SUCCESS;
	}
	
	//文档修改
	public String updateDocument(){
		try {
			System.out.println("--------更新文档---------");
			//定义新上传的文件路径
			String newFilePath = "";
			//判断用户是否有选择新的文档
			if(file!=null){
				//用户重新上传的新的文件
				newFilePath = HRMContant.uploadFile(file, fileFileName, "/file/document");
			}
			hrmService.updateDocument(document,newFilePath);  
			tip = "修改成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}


	public File getFile() {
		return file;
	}


	public void setFile(File file) {
		this.file = file;
	}


	public String getFileFileName() {
		return fileFileName;
	}


	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}


	public String getFileContentType() {
		return fileContentType;
	}


	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}


	




	
	
	
}
