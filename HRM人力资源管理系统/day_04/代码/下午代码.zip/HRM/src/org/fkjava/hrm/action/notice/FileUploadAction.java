package org.fkjava.hrm.action.notice;




import java.io.File;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.util.HRMContant;

import com.opensymphony.xwork2.ActionSupport;

public class FileUploadAction extends ActionSupport {
	
	private File pic;//指定文件信息
	private String picFileName;//文件名
	private String picContentType;//文件类型
	
	
	public String fileUpload(){
		try {
			
			String picUrl = HRMContant.uploadFile(pic, picFileName, "/images/notice/");
			
			//将文件的路径响应给前台页面
			ServletActionContext.getResponse().getWriter().print(picUrl);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return NONE;
	}


	public File getPic() {
		return pic;
	}


	public void setPic(File pic) {
		this.pic = pic;
	}


	public String getPicFileName() {
		return picFileName;
	}


	public void setPicFileName(String picFileName) {
		this.picFileName = picFileName;
	}


	public String getPicContentType() {
		return picContentType;
	}


	public void setPicContentType(String picContentType) {
		this.picContentType = picContentType;
	}


	
	
	
	
}
