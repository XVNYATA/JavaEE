package org.fkjava.hrm.util;

import java.io.File;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.exception.HRMException;

public class HRMContant {

	//用户信息对应的key值
	public static final String SESSION_USER = "session_user";
	
	//验证码对应的key值
	public static final String VCODE = "vcode";
	
	//获取当前用户
	public static User getCurrentUser(){
		return (User)ServletActionContext.getRequest().getSession().getAttribute(HRMContant.SESSION_USER);
	}
	
	//文件上传   
	public static String uploadFile(File file,String fileName,String url){
		try {
			//获取项目部署路径
			String projectPath = ServletActionContext.getServletContext().getRealPath(url);
			System.out.println("projectPath:"+projectPath);
			//如果指定幕布不存在 在创建
			File f = new File(projectPath);
			if(!f.exists()){
				f.mkdirs();
			}
			
			//给文件重命名  防止文件被覆盖
			String newName = UUID.randomUUID().toString() + "." +FilenameUtils.getExtension(fileName);
			//将文件拷贝至指定目录下
			FileUtils.copyFile(file, new File(projectPath+File.separator+newName));
			System.out.println("文件路径："+url+"/"+newName);
			//将文件的路径响应给前台页面
			return url+"/"+newName;
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			throw new HRMException("文件上传失败！",e);
		}
	}
}
