package org.fkjava.hrm.action.document;



import java.io.File;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.action.base.AbstractAction;
import org.fkjava.hrm.bean.Document;
import org.fkjava.hrm.util.HRMContant;

public class DocumentAction extends AbstractAction {
	
	private Document document;
	private List<Document> documents;
	private File file;
	private String fileFileName;//文件名
	private String fileContentType;//文件类型
	
	//文档分页查询
	public String selectDocumentByPage(){
		try {
			documents = hrmService.selectDocumentByPage(document,pageModel);  
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return SUCCESS;
	}
	
	
	//文档删除
	public String deleteDocument(){
		try {
			hrmService.deleteDocument(document.getId(),document.getUrl());
			tip = "删除成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}
	
	//文档添加
	public String addDocument(){
		try {
			hrmService.addDocument(document,file,fileFileName);
			
			tip = "添加成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}
	
	
     //根据文档id获取文档信息
	public String showUpdateDocument(){
		try {
			document = hrmService.getDocumentById(document.getId());

			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}
		return SUCCESS;
	}
	
	//文档修改
	public String updateDocument(){
		try {
			System.out.println("--------更新文档---------");
			//定义新上传的文件路径
			String newFilePath = "";
			//判断用户是否有选择新的文档
			if(file!=null){
				//用户重新上传的新的文件
				newFilePath = HRMContant.uploadFile(file, fileFileName, "/file/document");
			}
			hrmService.updateDocument(document,newFilePath);  
			tip = "修改成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}
	
	//判断文件是否存在
	public String fileExist(){
		try {
			System.out.println("==========xiazai================");
			//判断下载的文件是否存在
			String projectPath = ServletActionContext.getServletContext().getRealPath("/");
			File file = new File(projectPath+document.getUrl());
			System.out.println("=="+projectPath+document.getUrl());
			if(!file.exists()){
				System.out.println("=========文件不存在======");
				return INPUT;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return INPUT;
		}
		return SUCCESS;
	}
	
	//文件下载
	public InputStream getFileStream(){
		try {
			
			// 对浏览器进行判断(msie)
			String userAgent =  ServletActionContext.getRequest().getHeader("user-agent");
			fileFileName = document.getTitle() +"."+FilenameUtils.getExtension(document.getUrl());
			//表示IE
			if (userAgent.toLowerCase().indexOf("msie") != -1){
				fileFileName = URLEncoder.encode(fileFileName, "utf-8"); // msie
			}else{
				fileFileName = new String(fileFileName.getBytes("utf-8"), "iso8859-1");
			}
			return ServletActionContext.getServletContext().getResourceAsStream(document.getUrl());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return null;
	}

	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}


	public File getFile() {
		return file;
	}


	public void setFile(File file) {
		this.file = file;
	}


	public String getFileFileName() {
		return fileFileName;
	}


	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}


	public String getFileContentType() {
		return fileContentType;
	}


	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}


	




	
	
	
}
