package org.fkjava.hrm.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.fkjava.hrm.bean.Notice;

/**
 * NoticeMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-08-13 16:35:27
 * @version 1.0
 */
public interface NoticeMapper {

	//公告分页查询
	List<Notice> selectNoticeByPage(Map<String, Object> params);

	//便于页面实现分页，需要获取总记录数
	int findTotalNum(Map<String, Object> params);

	//删除公告
	void deleteNoticeByIds(@Param("ids")String[] ids);

	//添加公告
	void save(Notice notice);

	//根据公告的id获取公告信息
	@Select("select * from hrm_notice where id = #{id}")
	Notice getNoticeById(int id);

	void update(Notice notice);



}