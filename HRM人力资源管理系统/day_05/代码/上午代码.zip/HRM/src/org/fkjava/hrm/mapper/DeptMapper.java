package org.fkjava.hrm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.fkjava.hrm.bean.Dept;

/**
 * DeptMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-08-13 16:35:27
 * @version 1.0
 */
public interface DeptMapper {

	
	@Select("select * from hrm_dept")
	List<Dept> getAllDepts();



}