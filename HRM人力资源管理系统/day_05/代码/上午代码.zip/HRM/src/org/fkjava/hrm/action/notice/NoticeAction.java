package org.fkjava.hrm.action.notice;


import java.util.List;
import org.fkjava.hrm.action.base.AbstractAction;
import org.fkjava.hrm.bean.Notice;

public class NoticeAction extends AbstractAction {
	
	private Notice notice;
	private List<Notice> notices;
	private String ids;


	
     //公告分页查询
	public String selectNoticeByPage(){
		try {
			notices = hrmService.selectNoticeByPage(notice,pageModel);  
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return SUCCESS;
	}
	
	//删除公告
	public String deleteNoticeByIds(){
		try {
			
			hrmService.deleteNoticeByIds(ids.split(","));
			tip = "删除成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}
	
	//添加公告
	public String addNotice(){
		try {
			
			hrmService.addNotice(notice);
			tip = "添加成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}
	
	
	 //跳转至修改公告页面
	 public String showUpdateNotice(){
		 try {
			
			 //根据公告的id获取公告信息
			 notice = hrmService.getNoticeById(notice.getId());
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		 return SUCCESS;
	 }

	//修改公告
	public String updateNotice(){
		try {
			
			hrmService.updateNotice(notice);
			tip = "修改成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}

	public Notice getNotice() {
		return notice;
	}


	public void setNotice(Notice notice) {
		this.notice = notice;
	}


	public List<Notice> getNotices() {
		return notices;
	}


	public void setNotices(List<Notice> notices) {
		this.notices = notices;
	}


	public String getIds() {
		return ids;
	}


	public void setIds(String ids) {
		this.ids = ids;
	}


}
