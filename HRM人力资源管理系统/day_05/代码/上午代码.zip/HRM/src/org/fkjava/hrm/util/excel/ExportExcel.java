package org.fkjava.hrm.util.excel;

import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts2.ServletActionContext;

//导出Excel文件
public class ExportExcel {

	
	public static void exportFileToExcel(String[] titles, String fileName, String sheetName, List<?> datas) {
		// TODO Auto-generated method stub
		//创建excel文件
		HSSFWorkbook book = new HSSFWorkbook();
		//创建工作薄
		HSSFSheet sheet = book.createSheet(sheetName);
		//创建行
		HSSFRow headrow = sheet.createRow(0);
		try {
			//填充工作簿头部信息
			for(int i=0;i<titles.length;i++){
				//通过行创建列
				HSSFCell cell = headrow.createCell(i);
				//为列设置值
				cell.setCellValue(titles[i]);
			}
			
			//填充查询的数据
			for(int i=0;i<datas.size();i++){
				//创建行
				HSSFRow valuerow = sheet.createRow(i+1);
				
				//获取需要填充的对象的类型
				Class clazz = datas.get(i).getClass();
				//获取clazz中所有的属性 私有的以及非私有的属性
				Field[] fields = clazz.getDeclaredFields();
				for(int j= 0;j<fields.length;j++){
					//通过行创建列，并给列赋值
					HSSFCell cell = valuerow.createCell(j);
					Field field = fields[j];
					if(!field.isAccessible()){
						//如果属性是私有的则设置可访问
						field.setAccessible(true);
					}
					//获取目标对象中的值
					Object value = field.get(datas.get(i));
					cell.setCellValue(value == null?"":value.toString());
				}
				
			}
			
			//将信息响应给客户，同时防止中文乱码
			String userAgent =  ServletActionContext.getRequest().getHeader("user-agent");
			if (userAgent.toLowerCase().indexOf("msie") != -1){
				fileName = URLEncoder.encode(fileName, "utf-8"); // msie
			}else{
				fileName = new String(fileName.getBytes("utf-8"), "iso8859-1");
			}
			
			// 设置响应头 <param name="contentDisposition">attachment;filename=${downFileName}</param>
			ServletActionContext.getResponse().setHeader("Content-Disposition", "attachment;filename="+ fileName);
			
			//将文件响应给客户
			book.write(ServletActionContext.getResponse().getOutputStream());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	
	}

	

}
