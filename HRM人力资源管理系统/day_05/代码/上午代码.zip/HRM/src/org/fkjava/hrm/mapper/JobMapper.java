package org.fkjava.hrm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.fkjava.hrm.bean.Job;

/**
 * JobMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-08-13 16:35:27
 * @version 1.0
 */
public interface JobMapper {

	@Select("select * from hrm_job")
	List<Job> getAllJobs();



}