package org.fkjava.hrm.action.employee;



import java.util.List;

import org.fkjava.hrm.action.base.AbstractAction;
import org.fkjava.hrm.bean.Dept;
import org.fkjava.hrm.bean.Employee;
import org.fkjava.hrm.bean.Employee_demo;
import org.fkjava.hrm.bean.Job;
import org.fkjava.hrm.util.excel.ExportExcel;


public class EmployeeAction extends AbstractAction {
	
	private Employee employee;
	private List<Employee> employees;
	private List<Job> jobs;
	private List<Dept> depts;
	
	//员工分页查询
	public String selectEmpByPage(){
		try {
			
			employees = hrmService.selectEmployeeByPage(employee,pageModel);  
			//获取部门以及职位
			jobs = hrmService.getAllJobs();
			depts = hrmService.getAllDepts();
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return SUCCESS;
	}
	
	//员工删除
	public String deleteEmployee(){
		try {
			
			hrmService.deleteEmployee(employee.getId());
			tip = "删除成功！";
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			tip = e.getMessage();
		}
		return SUCCESS;
	}
	
	//导出Excel
	public String downExcel(){
		try {
			//获取需要导出的数据
			//编号	姓名	性别	手机号码	邮箱	职位	学历	身份证号码	部门	联系地址	建档日期
			List<Employee_demo> employees = hrmService.findEmployeeByParams(employee);
			String title[] = {"编号","姓名","性别","手机号码","邮箱","职位","学历","身份证号码","部门","联系地址","建档日期"};
			//将数据导出至Excel表格
			ExportExcel.exportFileToExcel(title,"员工信息表.xls","员工信息",employees);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			
		}
		return NONE;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public List<Job> getJobs() {
		return jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

	public List<Dept> getDepts() {
		return depts;
	}

	public void setDepts(List<Dept> depts) {
		this.depts = depts;
	}
	
	
	
}
