package org.fkjava.hrm.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.fkjava.hrm.bean.Employee;
import org.fkjava.hrm.bean.Employee_demo;

/**
 * EmployeeMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-08-13 16:35:27
 * @version 1.0
 */   
public interface EmployeeMapper {

	//获取员工总数量
	int findTotalNum(Map<String, Object> params);

	//员工分页查询
	List<Employee> selectEmployeeByPage(Map<String, Object> params);

	@Delete("delete from hrm_employee where id = #{id}")
	void deleteEmployee(int id);

	//根据用户输入的查询条件获取员工信息
	List<Employee_demo> findEmployeeByParams(Employee employee);
	
	//添加员工
	void addEmp(Employee employee);



}