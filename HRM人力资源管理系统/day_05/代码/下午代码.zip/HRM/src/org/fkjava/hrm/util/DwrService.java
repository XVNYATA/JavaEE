package org.fkjava.hrm.util;

import java.io.File;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;
import org.directwebremoting.WebContextFactory;
import org.directwebremoting.io.FileTransfer;

public class DwrService {


	//实现文件上传
	public String upload(FileTransfer file){
		//由于该请求不会经过Struts2所以   ServletActionContext会为空
		//获取项目部署路径
		try {
			String projectPath = WebContextFactory.get().getHttpServletRequest().getRealPath("/images/employee");
			File f = new File(projectPath);
			if(!f.exists()){
				f.mkdirs();
			}
			
			//给文件重命名
			String newName = UUID.randomUUID().toString()+"."+FilenameUtils.getExtension(file.getFilename());
			FileUtils.copyInputStreamToFile(file.getInputStream(), new File(projectPath+File.separator+newName));
			return "/images/employee/"+newName;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		return null;
		
	}
	
}
