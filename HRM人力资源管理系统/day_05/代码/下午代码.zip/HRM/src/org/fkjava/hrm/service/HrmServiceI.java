package org.fkjava.hrm.service;

import java.io.File;
import java.util.List;

import org.fkjava.hrm.bean.Dept;
import org.fkjava.hrm.bean.Document;
import org.fkjava.hrm.bean.Employee;
import org.fkjava.hrm.bean.Employee_demo;
import org.fkjava.hrm.bean.Job;
import org.fkjava.hrm.bean.Notice;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.util.webTag.PageModel;

public interface HrmServiceI{

	 //根据用户名以及密码获取用户信息
	User findUserByNameAndPass(String loginName, String password);

    //公告分页查询
	List<Notice> selectNoticeByPage(Notice notice, PageModel pageModel);

	//删除公告
	void deleteNoticeByIds(String[] split);

	 //添加公告
	void addNotice(Notice notice);

	//根据公告的id获取公告信息
	Notice getNoticeById(int id);
	//修改公告
	void updateNotice(Notice notice);

	//###############################文档模块##################################//
	List<Document> selectDocumentByPage(Document document, PageModel pageModel);
	
	//文档删除
	void deleteDocument(int id, String url);

	//添加文档
	void addDocument(Document document,File file,String fileName);

	//根据文档id获取文档信息
	Document getDocumentById(int id);

	//更新文档
	void updateDocument(Document document, String newFilePath);

	
	//###############################员工模块##################################//
	//员工分页查询
	List<Employee> selectEmployeeByPage(Employee employee, PageModel pageModel);

	//获取职位
	List<Job> getAllJobs();
     //获取部门
	List<Dept> getAllDepts();

	//员工删除
	void deleteEmployee(int id);

	//根据用户输入的查询条件获取员工信息
	List<Employee_demo> findEmployeeByParams(Employee employee);

	//添加员工
	void addEmp(Employee employee);

}
