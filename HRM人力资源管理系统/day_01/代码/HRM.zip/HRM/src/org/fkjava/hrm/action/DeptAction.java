package org.fkjava.hrm.action;

import java.util.List;

import org.fkjava.hrm.bean.Dept;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.service.impl.HrmService;

import com.opensymphony.xwork2.ActionSupport;

public class DeptAction extends ActionSupport {

	
	@Override
	public String execute() throws Exception {
		// TODO Auto-generated method stub
		HrmServiceI service = new HrmService();
		List<Dept> depts = service.getAllLDepts();
		System.out.println("depts:"+depts.size());
		
		return NONE;
	}

	

}
