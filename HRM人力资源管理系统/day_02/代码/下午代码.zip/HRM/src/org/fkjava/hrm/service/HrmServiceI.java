package org.fkjava.hrm.service;

import java.util.List;

import org.fkjava.hrm.bean.Dept;
import org.fkjava.hrm.bean.User;

public interface HrmServiceI{

	 //根据用户名以及密码获取用户信息
	User findUserByNameAndPass(String loginName, String password);

}
