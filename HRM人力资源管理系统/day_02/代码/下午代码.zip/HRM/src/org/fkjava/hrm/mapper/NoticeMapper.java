package org.fkjava.hrm.mapper;

/**
 * NoticeMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-08-13 16:35:27
 * @version 1.0
 */
public interface NoticeMapper {



}