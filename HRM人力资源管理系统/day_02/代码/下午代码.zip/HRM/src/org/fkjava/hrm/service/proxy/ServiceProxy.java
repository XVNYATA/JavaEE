package org.fkjava.hrm.service.proxy;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.apache.ibatis.session.SqlSession;
import org.fkjava.hrm.annotation.AutoMapper;
import org.fkjava.hrm.exception.HRMException;
import org.fkjava.hrm.mapper.UserMapper;
import org.fkjava.hrm.util.ConnectionFactory;

//动态代理者 ==>中介
public class ServiceProxy   {

	@SuppressWarnings("unchecked")
	public <T> T bind(T obj) {
		// TODO Auto-generated method stub
		return (T)Proxy.newProxyInstance(obj.getClass().getClassLoader(), obj.getClass().getInterfaces(), new InvocationHandler() {
			
			@Override
			public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				// TODO Auto-generated method stub
				//获取连接
				SqlSession sqlSession = ConnectionFactory.getSqlSession();
				
				try {
					//获取被代理对象对应的Class
					Class clazz = obj.getClass();
					//获取私有以及非私有的属性
					Field[] fields = clazz.getDeclaredFields();
					for(Field field : fields){
						//判断属性上是否有注解
						AutoMapper autoMapper = field.getAnnotation(AutoMapper.class);
						//注解不为空  并且为true  则表示需要给该属性注入值
						if(autoMapper!=null&&autoMapper.required()){
							//假设属性是私有 则需要设置属性可访问
							if(!field.isAccessible()){
								field.setAccessible(true);
							}
							
							//UserMapper userMapper = session.getMapper(UserMapper.class);
							//给被代理对象注入值
							field.set(obj, sqlSession.getMapper(field.getType()));
							
						}
					}
					
					
					
					//执行目标方法
					Object result = method.invoke(obj, args);
					
	
					return result;
				} catch (Exception e) {
					// TODO: handle exception
					e.printStackTrace();
					throw new HRMException(e.getMessage(), e);
				}finally {
					//关闭连接
					ConnectionFactory.closeSqlSession();
				}
				
				
			}
		});
	}

	

}
