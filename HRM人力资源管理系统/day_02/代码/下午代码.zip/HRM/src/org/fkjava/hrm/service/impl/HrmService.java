package org.fkjava.hrm.service.impl;


import org.apache.log4j.Logger;
import org.fkjava.hrm.annotation.AutoMapper;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.exception.HRMException;
import org.fkjava.hrm.mapper.UserMapper;
import org.fkjava.hrm.service.HrmServiceI;

public class HrmService  implements HrmServiceI{
	
	@AutoMapper
	private UserMapper userMapper;
	
	private Logger logger = Logger.getLogger(HrmService.class);



	 //根据用户名以及密码获取用户信息   
	@Override
	public User findUserByNameAndPass(String loginName, String password) {
		// TODO Auto-generated method stub
		try {
            User user = userMapper.findUserByNameAndPass(loginName,password);
			return user;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("根据用户名以及密码获取用户信息失败！",e);
		}
	}

}
