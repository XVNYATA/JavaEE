package org.fkjava.hrm.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class ConnectionFactory {
  
	private static SqlSessionFactory sqlSessionFactory;
    //SqlSession是非线程安全     通过ThreadLocal可以保证线程安全
	private static ThreadLocal<SqlSession> threadLocal = new ThreadLocal<>();
	
	
	//初始化连接池    
	static{
		InputStream inputStream = null;
		try {
			inputStream = Resources.getResourceAsStream("mybatis-config.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(inputStream!=null){
				try {
					inputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	

	//获取连接
	public static SqlSession getSqlSession(){
		
		//从threadLocal中获取sqlSession
		SqlSession sqlSession = threadLocal.get();
		if(sqlSession==null){
			sqlSession = sqlSessionFactory.openSession();
			threadLocal.set(sqlSession);
		}
		
		
		return sqlSession;
	}
	
	
	
	//关闭连接
    public static void closeSqlSession(){
    	
    	//从threadLocal中获取sqlSession
		SqlSession sqlSession = threadLocal.get();
		if(sqlSession!=null){
			sqlSession.close();
			threadLocal.remove();
		}
	}
}
