package org.fkjava.hrm.service;

import java.util.List;

import org.fkjava.hrm.bean.Dept;

public interface HrmServiceI{

	//获取部门信息
	List<Dept> getAllLDepts();

}
