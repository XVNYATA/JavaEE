package org.fkjava.hrm.service.impl;

import java.util.List;

import org.fkjava.hrm.bean.Dept;
import org.fkjava.hrm.mapper.DeptMapper;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.util.ConnectionFactory;

public class HrmService  implements HrmServiceI{

	DeptMapper deptMapper = ConnectionFactory.getSqlSession().getMapper(DeptMapper.class);
	
	@Override
	public List<Dept> getAllLDepts() {
		// TODO Auto-generated method stub
		
		return deptMapper.getAllLDepts();
	}

}
