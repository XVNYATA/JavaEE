package org.fkjava.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.dao.ArticleDao;

/**
 * 添加文章
 */
@WebServlet("/addArticle.action")
public class AddArticleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddArticleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		//该方式设置编码只对post请求有效
		request.setCharacterEncoding("utf-8");
		//获取文章标题
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		
		try {
			//调用dao层将数据存放在lucene索引库
			ArticleDao articleDao  = new ArticleDao();
			
			articleDao.saveArticle(title,content);
			
			//跳转至首页进行检索
			request.setAttribute("message", "添加成功！");
		} catch (Exception e) {
			// TODO: handle exception
			request.setAttribute("message", "添加失败！");
		}
		
		request.getRequestDispatcher("/list.jsp").forward(request, response);
	}

}
