package org.fkjava;

import java.util.Arrays;
import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.TokenStream;
import org.apache.lucene.analysis.cjk.CJKAnalyzer;
import org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.analysis.tokenattributes.TermToBytesRefAttribute;
import org.apache.lucene.util.BytesRef;

public class AnalyzerTest
{
	public static void main(String[] args) throws Exception
	{
		String str = "广州疯狂java";
		
		// 单字分词
		//Analyzer analyzer = new StandardAnalyzer();// 使用默认的停用词
		
		// 二分法分词
		//Analyzer analyzer = new CJKAnalyzer();// 使用默认的停用词
	
		// 词库分词
		Analyzer analyzer = new SmartChineseAnalyzer();// 使用默认的停用词		

		// 词库分词
		//Analyzer analyzer = new SmartChineseAnalyzer(new CharArraySet(Arrays.asList("疯狂", "软件"), true));// 使用自定义的停用词集合
		
		// 对指定的字符串进行分词
		TokenStream ts = analyzer.tokenStream(null, str);
		
		ts.reset(); // 先要对tokenStream执行reset
		// 采用循环，不断地获取下一个token
		while(ts.incrementToken()) {
//			// 获取其中token信息
			TermToBytesRefAttribute attr = ts.getAttribute(TermToBytesRefAttribute.class);
			final BytesRef bytes = attr.getBytesRef();
			System.out.println(bytes.utf8ToString());
		}
		ts.close();			
	}
}
