package org.fkjava;

import java.nio.file.Paths;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class DeleteIndex {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//指定索引的存放位置
			Directory directory = FSDirectory.open(Paths.get("G:/Lucene/tb_article"));
			
			
			//指定分词器     StandardAnalyzer:单字分词     文章管理     文   章   管   理  
			Analyzer  analyzer = new StandardAnalyzer();  
			
			//指定索引的分词方式以及索引的创建模块
			IndexWriterConfig config = new IndexWriterConfig(analyzer);
			//设置索引的创建模式
			config.setOpenMode(OpenMode.CREATE_OR_APPEND);
			
			//通过IndexWriter索引库中简历索引   第一个参数：指定索引库的目录  
			IndexWriter write = new IndexWriter(directory, config);
			
		
			
			//指定需要更新的记录  id==4,Lucene没有直接更新文档的方法，updateDocument是先删除历史记录，再添加新的文档
			Term term = new Term("id","5");
			//删除索引   删除指定的文档
			//write.deleteDocuments(term);
			//删除所有的索引
			write.deleteAll();
			//提交数据
			write.commit();
			//关闭流操作
			write.close();
			
			
			System.out.println("======删除成功！====");
			
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		

	}

}
