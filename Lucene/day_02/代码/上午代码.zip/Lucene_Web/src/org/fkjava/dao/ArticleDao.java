package org.fkjava.dao;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field.Store;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.IndexWriterConfig.OpenMode;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Formatter;
import org.apache.lucene.search.highlight.Fragmenter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.Scorer;
import org.apache.lucene.search.highlight.SimpleFragmenter;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.fkjava.bean.Article;

public class ArticleDao {

	
	public void saveArticle(String title, String content) {
		// TODO Auto-generated method stub
		try {
			//指定索引库的位置
			Directory  directory = FSDirectory.open(Paths.get("G:/Lucene/tb_article"));
			
			//指定分词器     StandardAnalyzer:单字分词     文章管理     文   章   管   理  
			Analyzer  analyzer = new SmartChineseAnalyzer();  
			
			//指定索引的分词方式以及索引的创建模块
			IndexWriterConfig config = new IndexWriterConfig(analyzer);
			//设置索引的创建模式
			config.setOpenMode(OpenMode.CREATE_OR_APPEND);
			
			//通过IndexWriter索引库中简历索引   第一个参数：指定索引库的目录  
			IndexWriter write = new IndexWriter(directory, config);
			
		   System.out.println("title:"+title+" content："+content);
			//将文档信息存储在索引库
             //创建Document对象用于封装文章相关信息
			Document document = new Document();
			//document.add(new TextField(articleTitle));
			//第一个参数name:字段名称 第二个参数：字段值   StringField：不会对关键字做分词    Store.YES：存储数据。并可以用于检索，Store.NO：数据不会被存储，但是可以用于实现检索功能
			document.add(new StringField("id","4", Store.YES));
			document.add(new TextField("title",title, Store.YES));
			document.add(new TextField("content",content, Store.YES));
			
			//将数据写入索引库
			write.addDocument(document);
			//提交数据
			write.commit();
			//关闭流操作
			write.close();
			System.out.println("======创建成功！====");
	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	
	}

	
	
	public List<Article> findAllBookByTitle(String title) {
		// TODO Auto-generated method stub
		try {
		
			//指定索引的存放位置
			Directory directory = FSDirectory.open(Paths.get("G:/Lucene/tb_article"));
			
			//指定查询对象，需要指定索引库目录信息
			IndexReader reader = DirectoryReader.open(directory);
			
			//创建检索对象，用于实现全文检索
			IndexSearcher search = new IndexSearcher(reader);	
			
			//创建分词器
			Analyzer  analyzer = new SmartChineseAnalyzer();  
			//创建query对象，根据关键字进行检索    new Term：不会对关键子进行分词
			String[] fields = {"title","content"};     
			QueryParser parse = new MultiFieldQueryParser(fields, analyzer);
			
			//获取Query对象
			Query query = parse.parse(title);
			System.out.println("title:"+title);
			//Query query = new TermQuery(new Term("title",title));
			
			//开始检索  第一个参数：检索对象    第二个参数：检所出的记录数量
			TopDocs  topDocs  = search.search(query,10);  
			
			
			//指定高亮的格式     高亮格式器
			Formatter formatter = new SimpleHTMLFormatter("<font color='red'>", "</font>");
			
			//创建Scorer对象，通过Scorer 对象封装查询相关信息
			Scorer scorer = new QueryScorer(query);
			
			
			//创建高亮对象
			Highlighter highlighter = new Highlighter(formatter, scorer);
			
			//设置格式化片段   参数：指定需要截取的数据的长度
		    Fragmenter fragmenter = new SimpleFragmenter(20);
		        
		    highlighter.setTextFragmenter(fragmenter);
			
			
			
			
			
			
			
			//获取所有的记录
			ScoreDoc[] scoreDocs =  topDocs.scoreDocs;
			
			List<Article> articles = null;
			if(scoreDocs!=null){
				articles = new ArrayList<>();
				for(ScoreDoc scoreDoc : scoreDocs){
					Article article = new Article();
					System.out.println("文档id:"+scoreDoc.doc);
					System.out.println("文档得分:"+scoreDoc.score);
					
					//根据文档的id获取文档信息
					Document doc = search.doc(scoreDoc.doc);
					//封装数据
					article.setId(doc.get("id"));
					String articleTitle = doc.get("title");
					//获取高亮后的'标题'数据
					String highLightTitle = highlighter.getBestFragment(analyzer, "title", articleTitle);
					article.setTitle((highLightTitle==null||highLightTitle.equals(""))?articleTitle  : highLightTitle);
					String content = doc.get("content");
					//获取高亮后的'内容'数据     highLightContent为空  说明highLightContent中不包括关键字
					String highLightContent = highlighter.getBestFragment(analyzer, "content", content);
					
					//判断内容中是否包括关键字  ，如果不包括，则需要对内容进行截取
					if(highLightContent==null||highLightContent.equals("")){
						highLightContent =content.length()<=20 ? content :  content.substring(0,20)+"...";
					}
										
					//由于文章的内容字数可能非常多，必须截取				
					article.setContent(highLightContent);
					articles.add(article);
				}
			}
			System.out.println("文章数量："+articles.size());
			return articles;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	
		return null;
	}

	

}
