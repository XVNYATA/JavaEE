package org.fkjava.query;

import java.nio.file.Paths;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Formatter;
import org.apache.lucene.search.highlight.Fragmenter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.Scorer;
import org.apache.lucene.search.highlight.SimpleFragmenter;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class HighLightTest {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//指定索引库的位置
			Directory  directory = FSDirectory.open(Paths.get("G:\\Lucene\\tb_article"));
    
			IndexReader reader =   DirectoryReader.open(directory);
			//创建检索对象
			IndexSearcher indexSearcher = new IndexSearcher(reader);
			
			
			//创建分词器
			Analyzer analyzer = new  SmartChineseAnalyzer();
		
			//指定需要查询的列
			String[] fields = {"title","content"};
			QueryParser parse = new MultiFieldQueryParser(fields, analyzer);
			
			Query query = parse.parse("十年广州疯狂");
			
			
			
			
			//指定高亮的格式     高亮格式器
			Formatter formatter = new SimpleHTMLFormatter("<font color='red'>", "</font>");
			
			//创建Scorer对象，通过Scorer 对象封装查询相关信息
			Scorer scorer = new QueryScorer(query);
			
			
			//创建高亮对象
			Highlighter highlighter = new Highlighter(formatter, scorer);
			
			//设置格式化片段   参数：指定需要截取的数据的长度
		    Fragmenter fragmenter = new SimpleFragmenter(9);
		        
		    highlighter.setTextFragmenter(fragmenter);
		    
		    
			
			
			//检索数据
			TopDocs topDoc = indexSearcher.search(query, 10);  
			
			//获取所有的记录
			ScoreDoc[] scoreDocs = topDoc.scoreDocs;
			if(scoreDocs!=null){
				for(ScoreDoc scoreDoc : scoreDocs){
					System.out.println("==迭代数据==");
					System.out.println("文档的id："+scoreDoc.doc);
					System.out.println("文档的得分："+scoreDoc.score);
					int docId = scoreDoc.doc;
					//根据文档的id获取文档
					Document doc = indexSearcher.doc(docId);
					String id = doc.get("id");
					//获取文档的标题
					String title  = doc.get("title");
					String content = doc.get("content");
					System.out.println("id:"+id+" title："+title+" content :"+content);
				    
					//测试高亮后的效果
					System.out.println("title:"+highlighter.getBestFragment(analyzer, "title", title) +" content:"+highlighter.getBestFragment(analyzer, "content", content));
				}
			}

			 
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
