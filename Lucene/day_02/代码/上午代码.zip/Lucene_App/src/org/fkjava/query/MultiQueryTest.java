package org.fkjava.query;

import java.nio.file.Paths;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.index.Term;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TermQuery;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;

public class MultiQueryTest {


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//指定索引库的位置
			Directory  directory = FSDirectory.open(Paths.get("G:\\Lucene\\tb_article"));
    
			IndexReader reader =   DirectoryReader.open(directory);
			//创建检索对象
			IndexSearcher indexSearcher = new IndexSearcher(reader);
			
			
			//创建分词器
			Analyzer analyzer = new  SmartChineseAnalyzer();
			
			//创建QueryParse对象   第一个参数：列名    第二个参数：列对应的值
			QueryParser queryParser = new QueryParser("title", analyzer);
			//获取query对象   参数：查询关键字
			//Query query = parse.parse("十年疯狂");
			
			
			  // 疯 OR 疯狂   默认Field里包含"疯"或 "疯狂"
	        Query query2 = queryParser.parse("十年   疯狂");
	    	//+如果   +疯狂 (如果   AND 疯狂)  默认Field里包含"如果"和"疯狂"
	    	//Query query3 = queryParser.parse("撑伞  AND 疯狂");
	    	// title:file         title Field里包含file
	    	//Query query4 = queryParser.parse("name:1");
//	    		title:1 -content:疯狂|疯 (title:file AND NOT content:疯狂|疯 ) 
//	    		  (title:1，但content里不能包含"疯狂 或者 疯")
	    	//Query query5 = queryParser.parse("title:1 -content:疯狂|疯");
			
			
			//指定需要查询的列
			//String[] fields = {"title","content"};
			//QueryParser parse = new MultiFieldQueryParser(fields, analyzer);
			
			//获取query对象   参数：查询关键字
			//Query query = parse.parse("十年");
			//检索数据
			TopDocs topDoc = indexSearcher.search(query2, 10);  
			
			//获取所有的记录
			ScoreDoc[] scoreDocs = topDoc.scoreDocs;
			if(scoreDocs!=null){
				for(ScoreDoc scoreDoc : scoreDocs){
					System.out.println("==迭代数据==");
					System.out.println("文档的id："+scoreDoc.doc);
					System.out.println("文档的得分："+scoreDoc.score);
					int docId = scoreDoc.doc;
					//根据文档的id获取文档
					Document doc = indexSearcher.doc(docId);
					String id = doc.get("id");
					//获取文档的标题
					String title  = doc.get("title");
					String content = doc.get("content");
					System.out.println("id:"+id+" title："+title+" content :"+content);
				    
				}
			}

			 
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}

}
