package org.fkjava.hrm.service.proxy;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import org.apache.ibatis.session.SqlSession;
import org.fkjava.hrm.exception.HRMException;
import org.fkjava.hrm.util.AutoMapper;
import org.fkjava.hrm.util.ConnectionFactory;


public class ServiceProxy {
	

	//obj：被代理对象
	@SuppressWarnings("unchecked")
	public <T> T bind(T obj) {
		// TODO Auto-generated method stub
		return (T)Proxy.newProxyInstance(obj.getClass().getClassLoader(), obj.getClass().getInterfaces(), new InvocationHandler() {
			
			@Override
			public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
				// TODO Auto-generated method stub
				//获取连接
				SqlSession sqlSession = ConnectionFactory.getSqlSession();
				try {
					//获取目标对象中所有的属性
					Class clazz = obj.getClass();
					Field[] fields = clazz.getDeclaredFields();
					//通过反射给目标对象注入属性值
					for(Field field : fields){
						
						//判断属性上是否有AutoMapper注解
						AutoMapper autoMapper = field.getAnnotation(AutoMapper.class);
						if(autoMapper!=null && autoMapper.required()){
							if(!field.isAccessible()){
								//私有属性设置成可访问状态
								field.setAccessible(true);
							}
							//给属性注入值
							field.set(obj, sqlSession.getMapper(field.getType()));	
	
						}
					}
	 				
					//执行目标方法
					Object value = method.invoke(obj, args);
					
					System.out.println("------------关闭连接----------------");
					return value;
				} catch (Exception e) {
					e.printStackTrace();
					//回滚
					sqlSession.rollback();
					throw new HRMException(e.getMessage(), e);
				}finally {
					//提交事务
					sqlSession.commit();
					//关闭连接
					ConnectionFactory.closeSqlSession();
				}

			}
			
		});
	}
 
	
}
