package org.fkjava.hrm.service.impl;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.bean.Article;
import org.fkjava.hrm.bean.Dept;
import org.fkjava.hrm.bean.Document;
import org.fkjava.hrm.bean.Employee;
import org.fkjava.hrm.bean.Employee_demo;
import org.fkjava.hrm.bean.Job;
import org.fkjava.hrm.bean.Notice;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.exception.HRMException;
import org.fkjava.hrm.mapper.ArticleDao;
import org.fkjava.hrm.mapper.DeptMapper;
import org.fkjava.hrm.mapper.DocumentMapper;
import org.fkjava.hrm.mapper.EmployeeMapper;
import org.fkjava.hrm.mapper.JobMapper;
import org.fkjava.hrm.mapper.NoticeMapper;
import org.fkjava.hrm.mapper.UserMapper;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.util.AutoMapper;
import org.fkjava.hrm.util.HRMConstant;
import org.fkjava.hrm.util.webTag.Page;

public class HrmService implements HrmServiceI{

	@AutoMapper
	private UserMapper userMapper;
	
	@AutoMapper
	private NoticeMapper noticeMapper;
	 
	@AutoMapper
	private DocumentMapper documentMapper;
	
	@AutoMapper
	private EmployeeMapper employeeMapper;
	
	@AutoMapper
	private DeptMapper deptMapper;
	
	@AutoMapper
	private JobMapper jobMapper;
	

	private Logger logger = Logger.getLogger(HrmService.class);

	//根据用户名以及密码获取用户信息
	@Override
	public User findUserByNameAndPass(String loginName, String password) {
		// TODO Auto-generated method stub
		try {
			
			return userMapper.findUserByNameAndPass(loginName,password);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("用户信息获取失败！", e);
		}
	}

	//根据公告标题以及分页实体进行分页查询
	@Override
	public List<Notice> findNoticeByPage(Notice notice, Page page) {
		// TODO Auto-generated method stub
		try {
			
			//封装查询的数据
			Map<String,Object> params = new HashMap<>();
			 
			params.put("notice", notice);
			//查询公告总数量
			int totalNum = noticeMapper.findTotalNotice(params);
			System.out.println("totalNum:"+totalNum);
			if(totalNum==0){
				
				return null; 
				
			}
			//将总数量存放在page对象中
			page.setTotalNum(totalNum);
			
			params.put("page", page);
			
			//分页查询
			return noticeMapper.findNoticeByPage(params);
			

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("公告分页查询失败！", e);
		}
	}

	//删除公告
	@Override
	public void deleteNoticesByIds(String[] ids) {
		// TODO Auto-generated method stub
		try {
			noticeMapper.deleteNoticesByIds(ids);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("公告删除失败!", e);
		}
	}

	//异步加载公告
	@Override
	public Notice ajaxLoadNotice(int id) {
		// TODO Auto-generated method stub
		try {
			
			return noticeMapper.get(id);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("公告加载失败!", e);
		}
	}

	//添加公告
	@Override
	public void saveNotice(Notice notice) {
		// TODO Auto-generated method stub
		try {
			//设置创建时间
			notice.setCreateDate(new Date());
			//获取当前用户
			notice.setUser((User)ServletActionContext.getRequest().getSession().getAttribute(HRMConstant.SESSION_USER));
			noticeMapper.saveNotice(notice);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.error(e);
			throw new HRMException("公告添加失败!", e);
		}
		
	}
	
	    //更新公告
		@Override
		public void updateNotice(Notice notice) {
			// TODO Auto-generated method stub
			try {
				noticeMapper.updateNotice(notice);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("公告更新失败!", e);
			}
			
		}

		//文档分页查询
		@Override
		public List<Document> findDocumentByPage(Document document, Page page) {
			// TODO Auto-generated method stub
			try {
				
				//封装查询的数据
				Map<String,Object> params = new HashMap<>();
				 
				params.put("document", document);
				//查询公告总数量
				int totalNum = documentMapper.findTotalDocument(params);
				System.out.println("totalNum:"+totalNum);
				if(totalNum==0){
					
					return null; 
					
				}
				//将总数量存放在page对象中
				page.setTotalNum(totalNum);
				
				params.put("page", page);
				
				//分页查询
				return documentMapper.findDocumentByPage(params);
				

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("文档分页查询失败！", e);
			}
		}

		//删除文档
		@Override
		public void deleteDocumentById(int id,String url) {
			// TODO Auto-generated method stub
			try {
				//删除数据库记录
				documentMapper.deleteDocumentById(id);
				//获取项目部署路径
				String projectPath = ServletActionContext.getServletContext().getRealPath("/");
				
				//删除磁盘文件
				
				File file = new File(projectPath+url);
				if(file.exists()){
					//文件存在则删除
					file.delete();
				}
				
			
				
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("文档删除失败！", e);
			}
		}

		//添加文档
		@Override
		public void addDocument(Document document) {
			// TODO Auto-generated method stub
			try {
				document.setCreateDate(new Date());
				document.setUser((User)ServletActionContext.getRequest().getSession().getAttribute(HRMConstant.SESSION_USER));
				documentMapper.save(document);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("文档添加失败！", e);
			}
		}

		//根据文档id获取文档信息
		@Override
		public Document getDocumentById(int id) {
			// TODO Auto-generated method stub
			try {
				
				return documentMapper.get(id);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("文档信息获取失败！", e);
			}
		}

		//更新文档
		@Override
		public void updateDocument(Document document, String oldUrl) {
			// TODO Auto-generated method stub
           try {
				
        	   //如果上传了新的文件则将历史文件删除
        	   if(!oldUrl.equals(document.getUrl())){
        		   //删除历史文件
        		  String projectPath = ServletActionContext.getServletContext().getRealPath("/");
       			
       			  File f = new File(projectPath+oldUrl);
       			  if(f.exists()){
       				  //如果历史文件存在则删除
       				  f.delete();
       			  }
        	   }
        	   
        	   //更新文档信息
        	   documentMapper.update(document);
        	   
				
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("文档更新失败！", e);
			}
		}

		//员工分页查询
		@Override
		public List<Employee> selectEmployeeByPage(Employee employee, Page page) {
			// TODO Auto-generated method stub
                try {
				
				//封装查询的数据
				Map<String,Object> params = new HashMap<>();
				 
				params.put("employee", employee);
				//查询公告总数量
				int totalNum = employeeMapper.findTotalEmployee(params);
				System.out.println("totalNum:"+totalNum);
				if(totalNum==0){
					
					return null; 
					
				}
				//将总数量存放在page对象中
				page.setTotalNum(totalNum);
				
				params.put("page", page);
				
				//分页查询
				return employeeMapper.findEmployeeByPage(params);
				

			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("员工分页查询失败！", e);
			}
		}

		//获取所有部门信息
		@Override
		public List<Dept> findAllDepts() {
			// TODO Auto-generated method stub
			try {
				return deptMapper.findAllDepts();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("部门信息查询失败！", e);
			}
		}
		
		//获取所有职位信息
		@Override
		public List<Job> findAllJobs() {
			// TODO Auto-generated method stub
			try {
				return jobMapper.findAllJobs();
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("职位信息查询失败！", e);
			}
		}

		//删除员工
		@Override
		public void deleteEmployee(int id) {
			// TODO Auto-generated method stub
			try {
				 employeeMapper.deleteEmployee(id);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("员工删除失败！", e);
			}
		}

		//根据用户输入的查询条件获取导出员工信息
		@Override
		public List<Employee_demo> findEmployeeByParams(Employee employee) {
			// TODO Auto-generated method stub
		    try {
				
						//封装查询的数据
						Map<String,Object> params = new HashMap<>();
						 
						params.put("employee", employee);
						//查询公告总数量
						int totalNum = employeeMapper.findTotalEmployee(params);
						System.out.println("totalNum:"+totalNum);
						if(totalNum==0){
							
							return null; 
							
						}
						//分页查询
						return employeeMapper.findEmployeeByParams(params);
						

					} catch (Exception e) {
						// TODO: handle exception
						e.printStackTrace();
						logger.error(e);
						throw new HRMException("员工分页查询失败！", e);
					}
		}

		//保存员工信息
		@Override
		public void saveEmployee(Employee employee) {
			// TODO Auto-generated method stub
			try {
				employeeMapper.save(employee);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("员工信息保存失败！", e);
			}
		}

		
		//文章分页查询
		@Override
		public List<Article> selectArticle(String keyword, Page page) {
			// TODO Auto-generated method stub
			try {
                   
				ArticleDao articleDao = new ArticleDao();
                return articleDao.selectArticle(keyword,page);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.error(e);
				throw new HRMException("文章信息查询失败！", e);
			}
		}
	
	

}
