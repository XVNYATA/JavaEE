package org.fkjava.hrm.action.document;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.action.BaseAction;
import org.fkjava.hrm.bean.Document;
import org.fkjava.hrm.bean.Notice;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.service.impl.HrmService;
import org.fkjava.hrm.service.proxy.ServiceProxy;
import org.fkjava.hrm.util.HRMConstant;
import org.fkjava.hrm.util.webTag.Page;

import com.opensymphony.xwork2.ActionSupport;

public class DocumentAction extends BaseAction {
	
	private Document document;

	private List<Document> documents;
	private String url;
	
	private File file;
	private String fileFileName;
	private String fileContentType;
	

	//公告分页查询
	 public String selectDocumentByPage(){
		
		 //根据公告标题以及分页实体进行分页查询
		 documents = hrmService.findDocumentByPage(document,page);
		 
		 return SUCCESS;
		 
	 }

	 //删除文档
	 public String deleteDocumentById(){
		 try {
			 hrmService.deleteDocumentById(id,url);
			 setTip("删除成功！");
		} catch (Exception e) {
			// TODO: handle exception
			 setTip(e.getMessage());
		}
		 
		 return SUCCESS;
	 } 
	 
	 //文件上传
     public String addDocument(){
    	 try {
    		 
    		 //上传文件
    		 String filePath = HRMConstant.fileUpload(file,fileFileName);
    		 
    		 //将文件路径存放在document对象中
    		 document.setUrl(filePath);
    		 
    		 hrmService.addDocument(document);
    		 
			setTip("上传成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			setTip(e.getMessage());
		}
    	 return SUCCESS;
    	 
     }
     
     //根据文档id获取文档信息
     public String showUpdateDocument(){
    	try {
			document = hrmService.getDocumentById(id);
					
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	 return SUCCESS;
     }
     
     //修改文档
     public String updateDocument(){
    	 try {
    		 
    		 //获取历史文件的路径
    		 String oldUrl = document.getUrl();
    		 //判断用户是否上传了新的文档
    		 if(file!=null){
    			String newPath =  HRMConstant.fileUpload(file, fileFileName);
    			document.setUrl(newPath);
    		 }
    		 hrmService.updateDocument(document,oldUrl);
    		 
			setTip("修改成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			setTip(e.getMessage());
		}
    	 return SUCCESS;
    	 
     }
     
     
     //文件下载
     public InputStream getFileStream(){
    	 
    	 //判断文件是否存在
    	 String projectPath = ServletActionContext.getServletContext().getRealPath("/");
    	 System.out.println("projectPath+url:"+(projectPath+url));
    	 File f = new File(projectPath+url);
    	 if(!f.exists()){
    		 return null;
    	 }
    	 //设置下载的文件名
    	 fileFileName = document.getTitle()+"."+FilenameUtils.getExtension(url);


		// 对浏览器进行判断(msie)
		String userAgent =  ServletActionContext.getRequest().getHeader("user-agent");
			try {
			if (userAgent.toLowerCase().indexOf("msie") != -1){
				
				fileFileName = URLEncoder.encode(fileFileName, "utf-8");
				// msie
			}else{
				fileFileName = new String(fileFileName.getBytes("utf-8"), "iso8859-1");
			}
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
    	 return ServletActionContext.getServletContext().getResourceAsStream(url);
    	 
    	 
    	 
     }
     
     
	public Document getDocument() {
		return document;
	}


	public void setDocument(Document document) {
		this.document = document;
	}


	public List<Document> getDocuments() {
		return documents;
	}


	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public String getFileFileName() {
		return fileFileName;
	}

	public void setFileFileName(String fileFileName) {
		this.fileFileName = fileFileName;
	}

	public String getFileContentType() {
		return fileContentType;
	}

	public void setFileContentType(String fileContentType) {
		this.fileContentType = fileContentType;
	}
	 
	 
	 
	
	 
}
