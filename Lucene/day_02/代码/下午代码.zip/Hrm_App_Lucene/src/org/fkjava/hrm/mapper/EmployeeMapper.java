package org.fkjava.hrm.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.fkjava.hrm.bean.Employee;
import org.fkjava.hrm.bean.Employee_demo;

/**
 * EmployeeMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-07-04 15:43:57
 * @version 1.0
 */
public interface EmployeeMapper {

	int findTotalEmployee(Map<String, Object> params);

	List<Employee> findEmployeeByPage(Map<String, Object> params);

	@Delete("delete from hrm_employee where id = #{id}")
	void deleteEmployee(int id);

	//根据用户输入的查询条件获取导出员工信息
	List<Employee_demo> findEmployeeByParams(Map<String, Object> params);

   //保存员工信息
	void save(Employee employee);
	
	



}