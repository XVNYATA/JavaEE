package org.fkjava.hrm.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.fkjava.hrm.bean.Notice;

/**
 * NoticeMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-07-04 15:43:57
 * @version 1.0
 */
public interface NoticeMapper {

	//获取公告总数量
	int findTotalNotice(Map<String, Object> params);

	//公告分页查询
	List<Notice> findNoticeByPage(Map<String, Object> params);

	//删除公告
	void deleteNoticesByIds(@Param("ids")String[] ids);

	//根据公告id获取公告信息
	@Select("select * from hrm_notice where id = #{id}")
	Notice get(int id);

	//添加公告
	void saveNotice(Notice notice);

	//更新公告
	void updateNotice(Notice notice);



}