package org.fkjava.hrm.mapper;

import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.analysis.cn.smart.SmartChineseAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexReader;
import org.apache.lucene.queryparser.classic.MultiFieldQueryParser;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.search.highlight.Formatter;
import org.apache.lucene.search.highlight.Fragmenter;
import org.apache.lucene.search.highlight.Highlighter;
import org.apache.lucene.search.highlight.QueryScorer;
import org.apache.lucene.search.highlight.Scorer;
import org.apache.lucene.search.highlight.SimpleFragmenter;
import org.apache.lucene.search.highlight.SimpleHTMLFormatter;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.poi.poifs.filesystem.DocumentOutputStream;
import org.fkjava.hrm.bean.Article;
import org.fkjava.hrm.util.webTag.Page;

//与Lucene索引库进行数据的交互
public class ArticleDao {

	//文章分页查询
	public List<Article> selectArticle(String keyword, Page page) {
		// TODO Auto-generated method stub
		try {
			//指定索引库目录
			Directory directory = FSDirectory.open(Paths.get("G:\\Lucene\\tb_article"));
		
			//读取索引库
			IndexReader reader = DirectoryReader.open(directory);
			
			//创建检索对象
			IndexSearcher indexSearcher = new IndexSearcher(reader);
			
			
			List<Article> list = new ArrayList<>();
			//假设用户没有输入任何查询条件
			if(keyword==null||keyword.equals("")){
				
				//获取索引库中所有的记录数
				int totalNum = reader.maxDoc();
				page.setTotalNum(totalNum);
				
				//获取需要显示的最大行号
				int max = page.getPageIndex() * page.getPageSize() > totalNum ? totalNum : page.getPageIndex() * page.getPageSize();
				for(int i=page.getStartNum();i<max;i++){
					Document document = indexSearcher.doc(i);
					//封装数据
					Article article = new Article();
					article.setId(document.get("id"));
					article.setContent(document.get("content"));
					article.setTitle(document.get("title"));
					article.setCreateDate(document.get("createDate"));
					list.add(article);
				}
				
				return list;
			}else{
				Analyzer analyzer = new SmartChineseAnalyzer();
				
				String[] fields = {"title","content"};
				//创建query对象，根据关键字进行检索    new Term：不会对关键字进行分词
				QueryParser parse = new MultiFieldQueryParser(fields, analyzer);
				
				Query query = parse.parse(keyword);
			
		
				//指定高亮的格式     高亮格式器
				Formatter formatter = new SimpleHTMLFormatter("<font color='red'>", "</font>");
				
				//创建Scorer对象，通过Scorer 对象封装查询相关信息
				Scorer scorer = new QueryScorer(query);
				
				
				//创建高亮对象
				Highlighter highlighter = new Highlighter(formatter, scorer);
				
				//设置格式化片段   参数：指定需要截取的数据的长度
			    Fragmenter fragmenter = new SimpleFragmenter(9);
			        
			    highlighter.setTextFragmenter(fragmenter);
				
			    System.out.println("page.getPageIndex() * page.getPageSize():"+page.getPageIndex() * page.getPageSize());
				//根据用户输入的条件进行全文检索     页面：2     每页：2   
				TopDocs topDoc = indexSearcher.search(query, page.getPageIndex() * page.getPageSize());
				
				//获取总记录数
				int totalNum = topDoc.totalHits;
				
				//将获取到的总记录数存放在page分页实体中，便于页面分页
				page.setTotalNum(totalNum);
				
				//根据用户输入的关键字获取相关文章信息
			    ScoreDoc[] 	scoreDocs = topDoc.scoreDocs;
	
				int max = page.getPageIndex() * page.getPageSize() > totalNum ? totalNum : page.getPageIndex() * page.getPageSize();
			    
			    if(scoreDocs!=null){
					for(int i = (page.getPageIndex() -1)*page.getPageSize();i<max;i++){
                        Document document = indexSearcher.doc(i);
						//封装数据
						Article article = new Article();
						article.setId(document.get("id"));
						String articleTitle = document.get("title");
						String highLightTitle = highlighter.getBestFragment(analyzer, "title", articleTitle);
						article.setTitle((highLightTitle==null||highLightTitle.equals(""))?articleTitle  : highLightTitle);
						
						String content = document.get("content");
						//获取高亮后的'内容'数据     highLightContent为空  说明highLightContent中不包括关键字
						String highLightContent = highlighter.getBestFragment(analyzer, "content", content);
						
						//判断内容中是否包括关键字  ，如果不包括，则需要对内容进行截取
						if(highLightContent==null||highLightContent.equals("")){
							highLightContent =content.length()<=20 ? content :  content.substring(0,20)+"...";
						}
						article.setContent(highLightContent);
						
						article.setCreateDate(document.get("createDate"));
						list.add(article);
					}
		
				}
				
			    return list;
			}
			
		
		
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		return null;
	}


	

}
