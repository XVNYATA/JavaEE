package org.fkjava.hrm.util;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

//指定该注解保留的事件段
@Retention(RetentionPolicy.RUNTIME)
public @interface AutoMapper {
    
	boolean required() default true;
}
