package org.fkjava.hrm.util.webTag;

//分页实体    可以通过分页实体封装查询的条件
public class Page {
	
	private int pageIndex=1;//当前页码
	
	private int pageSize = 2;//每页显示的记录数
	
	private int totalNum;//总记录

	public int getPageIndex() {
		
		//如果当前页码大于总页码，就将总页码赋给当前页码	
		return pageIndex;
	}

	public void setPageIndex(int pageIndex) {
		System.out.println("pageIndex:"+pageIndex);
		if(pageIndex==0){
			pageIndex  = 1;
		}
		this.pageIndex = pageIndex;
	}

	public int getPageSize() {
		
		return pageSize;
	}

	public void setPageSize(int pageSize) {

		this.pageSize = pageSize;
	}

	public int getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(int totalNum) {
		this.totalNum = totalNum;
	}
	
	
	//计算开始行号
	public int getStartNum(){
		
		return (this.getPageIndex() - 1) * this.getPageSize();
	}
	
	//计算总页码
	public int getTotalPage(){
	
	return this.getTotalNum() % this.getPageSize() ==0?this.getTotalNum() / this.getPageSize() :this.getTotalNum() / this.getPageSize() +1;
		
	}
	
	

}
