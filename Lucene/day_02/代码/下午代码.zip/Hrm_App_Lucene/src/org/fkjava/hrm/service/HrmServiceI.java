package org.fkjava.hrm.service;

import java.util.List;

import org.fkjava.hrm.bean.Article;
import org.fkjava.hrm.bean.Dept;
import org.fkjava.hrm.bean.Document;
import org.fkjava.hrm.bean.Employee;
import org.fkjava.hrm.bean.Employee_demo;
import org.fkjava.hrm.bean.Job;
import org.fkjava.hrm.bean.Notice;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.service.impl.HrmService;
import org.fkjava.hrm.util.webTag.Page;

public interface HrmServiceI{

    //根据用户名以及密码获取用户信息
	User findUserByNameAndPass(String loginName, String password);

	//根据公告标题以及分页实体进行分页查询
	List<Notice> findNoticeByPage(Notice notice, Page page);

	//删除公告
	void deleteNoticesByIds(String[] split);

	//异步加载公告
	Notice ajaxLoadNotice(int id);

	//添加公告
	void saveNotice(Notice notice);
	
	//更新公告
	void updateNotice(Notice notice);
    /*#########################文档模块###########################*/
	List<Document> findDocumentByPage(Document document, Page page);

	//删除文档
	void deleteDocumentById(int id,String url);

	//添加文档
	void addDocument(Document document);

	//根据文档id获取文档
	Document getDocumentById(int id);

	//更新文档
	void updateDocument(Document document, String oldUrl);
	
	
	/*#########################员工模块###########################*/
  
	List<Employee> selectEmployeeByPage(Employee employee, Page page);

	//获取所有的部门
	List<Dept> findAllDepts();
	//获取所有的职位
	List<Job> findAllJobs();

	//删除员工信息
	void deleteEmployee(int id);

	//根据用户输入的查询条件获取导出员工信息
	List<Employee_demo> findEmployeeByParams(Employee employee);

	//保存员工信息
	void saveEmployee(Employee employee);

	//文章分页查询
	List<Article> selectArticle(String keyword, Page page);

	

}
