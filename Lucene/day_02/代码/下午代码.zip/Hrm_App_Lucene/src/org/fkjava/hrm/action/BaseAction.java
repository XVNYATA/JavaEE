package org.fkjava.hrm.action;

import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.service.impl.HrmService;
import org.fkjava.hrm.service.proxy.ServiceProxy;
import org.fkjava.hrm.util.webTag.Page;

import com.opensymphony.xwork2.ActionSupport;

public class BaseAction extends ActionSupport {
	
	
    public String ids;
	
	private String tip;
	public int id;
	
	//分页实体
	public Page page = new Page();
	
	//创建动态代理对象
	public HrmServiceI hrmService = new ServiceProxy().bind(new HrmService());

	

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	public String getTip() {
		return tip;
	}

	public void setTip(String tip) {
		this.tip = tip;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Page getPage() {
		return page;
	}

	public void setPage(Page page) {
		this.page = page;
	}
	
	

}
