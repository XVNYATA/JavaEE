package org.fkjava.hrm.action.notice;

import java.io.IOException;
import java.util.List;

import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.action.BaseAction;
import org.fkjava.hrm.bean.Notice;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.service.impl.HrmService;
import org.fkjava.hrm.service.proxy.ServiceProxy;
import org.fkjava.hrm.util.webTag.Page;

import com.opensymphony.xwork2.ActionSupport;

public class NoticeAction extends BaseAction {
	
	private Notice notice;

	private List<Notice> notices;
	
	
	
	
	//公告分页查询
	 public String selectNoticeByPage(){
		
		 //根据公告标题以及分页实体进行分页查询
		 notices = hrmService.findNoticeByPage(notice,page);
		 
		 return SUCCESS;
		 
	 }
	 
	 //删除公告
	 public String deleteNoticesByIds(){
		 try {
			 hrmService.deleteNoticesByIds(ids.split(","));
			 setTip("删除成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			setTip(e.getMessage());
		}

		 return SUCCESS;
	 }
	 
	 //异步加载公告内容
	 public String ajaxLoadNotice(){
		 
		 notice = hrmService.ajaxLoadNotice(id);
		 try {
			ServletActionContext.getResponse().getWriter().print(notice.getContent());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return NONE;
	 }
	 
	 
	 //添加公告
	 public String addNotice(){
		 
		 try {
			 hrmService.saveNotice(notice);
			 setTip("添加成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			setTip("添加失败！");
		}
		 return SUCCESS;
	 }
	 
	    //更新公告
		 public String updateNotice(){ 
			 try {
				 hrmService.updateNotice(notice);
				 setTip("更新成功！");
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				setTip("更新失败！");
			}
			 return SUCCESS;
		 }
	 
	 //跳转至更新公告页面
	 public String showUpdateNotice(){
		
		 notice = hrmService.ajaxLoadNotice(id);
		 
		 return SUCCESS;
	 }
	 

	public Notice getNotice() {
		return notice;
	}

	public void setNotice(Notice notice) {
		this.notice = notice;
	}

	public List<Notice> getNotices() {
		return notices;
	}

	public void setNotices(List<Notice> notices) {
		this.notices = notices;
	}

	
	
	 
	 
}
