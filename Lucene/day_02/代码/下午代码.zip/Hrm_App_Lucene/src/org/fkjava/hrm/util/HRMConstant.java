package org.fkjava.hrm.util;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.exception.HRMException;

public class HRMConstant {

	 //session中用户信息对应的key值
	 public static final String SESSION_USER = "session_user";
	 
	 
	//验证码对应的key值
    public static final String VCODE = "vcode";
    
    
    //文档模块 文件上传
    public static String fileUpload(File file,String fileName){
    	//获取项目部署路径
    			String projectPath = ServletActionContext.getServletContext().getRealPath("/document");
    			
    			File f = new File(projectPath);
    			if(!f.exists()){
    				f.mkdirs();
    			}
    			
    			//给文件重命名
    			String newName  =UUID.randomUUID().toString() + "." + FilenameUtils.getExtension(fileName);
    			
    			//上传文件至指定目录
    			try {
    				FileUtils.copyFile(file, new File(projectPath+File.separator+newName));
    				//将图片路径响应至前台
    				return "/document/"+newName;
    			} catch (IOException e) {
    				// TODO Auto-generated catch block
    				e.printStackTrace();
    				throw new HRMException("上传失败", e);
    			}
    	    
    	
    }
}
