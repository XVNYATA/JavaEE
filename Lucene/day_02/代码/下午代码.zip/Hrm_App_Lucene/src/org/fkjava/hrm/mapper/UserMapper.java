package org.fkjava.hrm.mapper;

import org.apache.ibatis.annotations.Param;
import org.fkjava.hrm.bean.User;

/**
 * UserMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-07-04 15:43:57
 * @version 1.0
 */
public interface UserMapper {

	
	User findUserByNameAndPass(@Param("loginName")String loginName, @Param("password")String password);



}