package org.fkjava.hrm.util;

import java.io.IOException;
import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

//数据库连接工厂
public class ConnectionFactory {
	
	private static SqlSessionFactory sqlSessionFactory;
	//由于SqlSession是非线程安全的，可以ThreadLocal保证线程安全
	private static ThreadLocal<SqlSession> threadLocal = new ThreadLocal<>();
	
	//初始化数据源
	static{

		InputStream inputStream = null;
		try {
			inputStream = Resources.getResourceAsStream("mybatis-config.xml");
			sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			if(inputStream!=null){
				try {
					inputStream.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	
	//获取连接  
	public static SqlSession getSqlSession() {
		// TODO Auto-generated method stub
		SqlSession session = threadLocal.get();
		if(session==null){
			session = sqlSessionFactory.openSession();
			threadLocal.set(session);
		}
		
		return session;
	}

	//关闭连接
	public static void closeSqlSession() {
		// TODO Auto-generated method stub
		SqlSession session = threadLocal.get();
		if(session!=null){
			session.close();
			threadLocal.remove();
		}
  
	}
	
	
	

}
