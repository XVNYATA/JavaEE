package org.fkjava.hrm.action.employee;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.action.BaseAction;
import org.fkjava.hrm.bean.Dept;
import org.fkjava.hrm.bean.Document;
import org.fkjava.hrm.bean.Employee;
import org.fkjava.hrm.bean.Employee_demo;
import org.fkjava.hrm.bean.Job;
import org.fkjava.hrm.bean.Notice;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.service.impl.HrmService;
import org.fkjava.hrm.service.proxy.ServiceProxy;
import org.fkjava.hrm.util.HRMConstant;
import org.fkjava.hrm.util.excel.ExcelExport;
import org.fkjava.hrm.util.webTag.Page;

import com.opensymphony.xwork2.ActionSupport;

public class EmployeeAction extends BaseAction {
	
	private Employee employee;
	private List<Employee> employees;
	private List<Dept> depts;
	private List<Job> jobs;
	
	

	//员工分页查询
	 public String selectEmployeeByPage(){
		
		 employees = hrmService.selectEmployeeByPage(employee,page);
		 depts = hrmService.findAllDepts();
		 jobs  = hrmService.findAllJobs();
		 
		 return SUCCESS;
		 
	 }

	 //删除员工
	 public String deleteEmployee(){
		 try {
			
			 hrmService.deleteEmployee(id);
			 setTip("删除成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			setTip(e.getMessage());
		}
		 return SUCCESS;
	 }
	 
	 //导出员工信息至excel文件
	 public String exportEmployee(){
		 //根据用户输入的查询条件获取员工信息
		 List<Employee_demo> list = hrmService.findEmployeeByParams(employee);
		 //定义导出数据的标题行
		 String[] titles = {"编号", "姓名", "性别", "手机号码", "邮箱", "职位", "学历", "身份证号码", "部门", "联系地址", "建档日期"};

		 //第一个参数：数据头部信息     第二个参数：excel文件名    第三个参数：工作单名称    第四个参数：目标数据  
		 ExcelExport.exportData(titles,"员工信息表.xls","员工信息",list,ServletActionContext.getResponse());
		
		 return NONE;
	 }
	 
	 //跳转至添加员工页面
	 public String showAddEmp(){
		 
		 depts = hrmService.findAllDepts();
		 jobs  = hrmService.findAllJobs();
		 return SUCCESS;
	 }
	 
	 //添加员工
public String addEmp(){
		 
	try {
		   //设置创建时间
		   employee.setCreateDate(new Date());
		   hrmService.saveEmployee(employee);
		   setTip("添加成功！");
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			setTip(e.getMessage());
		}
	return SUCCESS;
	 }

	public Employee getEmployee() {
		return employee;
	}


	public void setEmployee(Employee employee) {
		this.employee = employee;
	}


	public List<Employee> getEmployees() {
		return employees;
	}


	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}


	public List<Dept> getDepts() {
		return depts;
	}


	public void setDepts(List<Dept> depts) {
		this.depts = depts;
	}


	public List<Job> getJobs() {
		return jobs;
	}


	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}
	 
	 
	 
	 

	
	
	 
}
