package org.fkjava.hrm.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;
import org.fkjava.hrm.bean.Document;

/**
 * DocumentMapper 数据访问类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-07-04 15:43:57
 * @version 1.0
 */
public interface DocumentMapper {
	
    //文档分页查询
	List<Document> findDocumentByPage(Map<String, Object> params);

	//获取文档总数量
	int findTotalDocument(Map<String, Object> params);

	//删除文档
	@Delete("delete from hrm_document where id = #{id}")
	void deleteDocumentById(int id);

	void save(Document document);

	@Select("select * from hrm_document where id = #{id}")
	Document get(int id);

	//更新文档
	void update(Document document);



}