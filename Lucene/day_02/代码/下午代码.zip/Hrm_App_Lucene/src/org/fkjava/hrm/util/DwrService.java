package org.fkjava.hrm.util;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;
import org.directwebremoting.WebContextFactory;
import org.directwebremoting.io.FileTransfer;

public class DwrService {
    
	//由于dwr请求不会经过struts2,导致 ServletActionContext为空
	public String fileUpload(FileTransfer file){
		//获取项目部署路径
		String projectPath = WebContextFactory.get().getServletContext().getRealPath("/image/employee");
		File f = new File(projectPath);
		if(!f.exists()){
			f.mkdirs();
		}
		//给文件重命名
		String newName = UUID.randomUUID().toString()+"."+FilenameUtils.getExtension(file.getFilename());
		//拷贝文件
		try {
			FileUtils.copyInputStreamToFile(file.getInputStream(), new File(projectPath + File.separator+newName));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//返回文件路径
		return "/image/employee/"+newName;
	}
	
}
