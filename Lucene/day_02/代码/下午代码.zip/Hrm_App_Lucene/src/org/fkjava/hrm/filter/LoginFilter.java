package org.fkjava.hrm.filter;

import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.util.HRMConstant;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class LoginFilter extends AbstractInterceptor {

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		// TODO Auto-generated method stub
		//从session中获取用户信息
		User user = (User)ServletActionContext.getRequest().getSession().getAttribute(HRMConstant.SESSION_USER);
		//判断用户信息是否为空
		if(user!=null){
			return invocation.invoke();
		}else{
			return Action.LOGIN;
		}
	}

}
