package org.fkjava.hrm.action.user;

import java.io.IOException;

import org.apache.struts2.ServletActionContext;
import org.fkjava.hrm.bean.User;
import org.fkjava.hrm.service.HrmServiceI;
import org.fkjava.hrm.service.impl.HrmService;
import org.fkjava.hrm.service.proxy.ServiceProxy;
import org.fkjava.hrm.util.HRMConstant;

import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends ActionSupport {

	private String loginName;
	private String password;
	private String vcode;
	
	
	ServiceProxy serviceProxy = new ServiceProxy();
	HrmServiceI hrmService = serviceProxy.bind(new HrmService());
	
	//用户异步登录
	 public String userLogin(){
		 //判断验证码是否正确
		 String code = (String)ServletActionContext.getRequest().getSession().getAttribute(HRMConstant.VCODE);
		 String tip = "";
		 if(!code.equals(vcode)){
			 tip = "您输入的验证码不正确，请重新输入！";
		 }else{
			 //根据用户名以及密码获取用户信息
			User user =  hrmService.findUserByNameAndPass(loginName,password);
			if(user!=null){
				//用户存在时将用户信息存放在session中
				ServletActionContext.getRequest().getSession().setAttribute(HRMConstant.SESSION_USER, user);
			}else{
				tip = "您输入的用户名或密码不正确，请核实！";
			}
		 }
		 
		 if(!tip.equals("")){
			 try {
				 //将提示信息响应给用户
				ServletActionContext.getResponse().getWriter().print(tip);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
		 return NONE;
		 
	 }
	 
	 
	 //用户退出
	 public String userLogout(){
		 //将用户信息从session中清除
		 ServletActionContext.getRequest().getSession().removeAttribute(HRMConstant.SESSION_USER);
		 
		 return SUCCESS;
	 }
	 
	 

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getVcode() {
		return vcode;
	}

	public void setVcode(String vcode) {
		this.vcode = vcode;
	}
	 
	 
	 
}
