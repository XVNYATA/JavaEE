package org.fkjava.hrm.util.excel;

import java.lang.reflect.Field;
import java.net.URLEncoder;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.struts2.ServletActionContext;
import org.apache.tomcat.jni.User;

/**
 * 通过poi将数据导出至excel表格
 * 
 * **/
public class ExcelExport {
	
	//导出数据至excel文件
	public static void exportData(String[] titles,String fileName,String sheetName,List<?> list,HttpServletResponse response) {
		// TODO Auto-generated method stub
		// 创建工作簿
		HSSFWorkbook workBook = new HSSFWorkbook();
		//创建工作单
		HSSFSheet sheet =  workBook.createSheet(sheetName);
		//创建行
		HSSFRow row = sheet.createRow(0);
		
		
		//填充标题头信息
		for(int i=0;i<titles.length;i++){
			//创建列
			HSSFCell cell = row.createCell(i);
			//填充数据
			cell.setCellValue(titles[i]);
		}
		
		//通过for循环将获取到的数据填充至excel文件
		for(int i=0;i<list.size();i++){
			//创建行
			HSSFRow row2 = sheet.createRow(i+1);
			
			//获取目标对象
			Object obj = list.get(i);
			//获取目标对象中所有的属性 包括私有属性
			Field[] fields = obj.getClass().getDeclaredFields();
			for(int j=0;j<fields.length;j++){
				//通过行创建列
				HSSFCell cell2 = row2.createCell(j);
				//假设属性是私有的 设置属性可访问
				if(!fields[j].isAccessible()){
					fields[j].setAccessible(true);
				}
			
				//获取字段值
				try {
					Object value = fields[j].get(obj); 
					//将数据填充至列中
					cell2.setCellValue(value==null?"":value.toString());
					//<param name="contentDisposition">attachment;filename="${fileDownName}"</param>
					// 对浏览器进行判断(msie)
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  
			}
		}
		
		try {
			String userAgent =  ServletActionContext.getRequest().getHeader("user-agent");
            if (userAgent.toLowerCase().indexOf("msie") != -1){
				
           	 fileName = URLEncoder.encode(fileName, "utf-8");
				// msie
			}else{
				fileName = new String(fileName.getBytes("utf-8"), "iso8859-1");
			}
			//设置响应头
			response.setHeader("Content-Disposition", "attachment;filename="+fileName);
			//将excel文件响应给客户
			workBook.write(response.getOutputStream());
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
	}
	
	

}
