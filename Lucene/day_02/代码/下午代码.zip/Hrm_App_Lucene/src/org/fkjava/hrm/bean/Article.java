package org.fkjava.hrm.bean;

import java.util.Date;

/**
 * Dept 数据传输类
 * @author CHUNLONG.LUO
 * @email 584614151@qq.com
 * @date 2016-07-04 15:43:57
 * @version 1.0
 */
public class Article implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	private String id;
	private String title;
	private String content;
	private String createDate;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}


	
	
}