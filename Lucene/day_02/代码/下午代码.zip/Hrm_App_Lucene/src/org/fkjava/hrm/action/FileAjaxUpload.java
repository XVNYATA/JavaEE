package org.fkjava.hrm.action;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;


public class FileAjaxUpload extends ActionSupport {

	private File pic;
	private String picFileName;
	private String picContentType;
	
	public String ajaxUploadFile(){
		System.out.println("==================");
		
		//获取项目部署路径
		String projectPath = ServletActionContext.getServletContext().getRealPath("/images/notice");
		
		File file = new File(projectPath);
		if(!file.exists()){
			file.mkdirs();
		}
		
		//给文件重命名
		String newName  =UUID.randomUUID().toString() + "." + FilenameUtils.getExtension(picFileName);
		
		//上传文件至指定目录
		try {
			FileUtils.copyFile(pic, new File(projectPath+File.separator+newName));
			//将图片路径响应至前台
			ServletActionContext.getResponse().getWriter().print("/images/notice/"+newName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return NONE;
	}

	public File getPic() {
		return pic;
	}

	public void setPic(File pic) {
		this.pic = pic;
	}

	public String getPicFileName() {
		return picFileName;
	}

	public void setPicFileName(String picFileName) {
		this.picFileName = picFileName;
	}

	public String getPicContentType() {
		return picContentType;
	}

	public void setPicContentType(String picContentType) {
		this.picContentType = picContentType;
	}

	
	
	
	
}
