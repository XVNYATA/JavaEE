package org.fkjava.hrm.action.article;

import java.util.List;

import org.fkjava.hrm.action.BaseAction;
import org.fkjava.hrm.bean.Article;

public class ArticleAction extends BaseAction {
	
	private List<Article> articles;
	private String keyword;
	
	//文章分页查询
	public String selectArticleByPage(){
		try {
			
			articles = hrmService.selectArticle(keyword,page);
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return SUCCESS;
	}

	public List<Article> getArticles() {
		return articles;
	}

	public void setArticles(List<Article> articles) {
		this.articles = articles;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	
	
	 
}
