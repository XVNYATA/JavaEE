package org.fkjava.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionFactory {

	public ConnectionFactory() {
		// TODO Auto-generated constructor stub
	}

	//获取数据库连接
	public static Connection getConnection() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/jss", "root", "123456");
			return con;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	//关闭数据库连接
	public static void closeConnection(ResultSet rs, Statement pstm, Connection con) {

		try {
			if (rs != null) {
				rs.close();
			}
			if (pstm != null) {
				pstm.close();
			}
			if (con != null) {
				con.close();
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
}
