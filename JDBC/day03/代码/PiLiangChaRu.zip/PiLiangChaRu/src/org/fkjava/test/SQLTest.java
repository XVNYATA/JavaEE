package org.fkjava.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.fkjava.util.ConnectionFactory;

public class SQLTest {

	public static void main(String[] args) {
		// 获取连接 -> sql语句 -> 执行sql -> 关闭连接

		// 获取连接
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement pstm = null;
		// sql 语句
		String sql = "INSERT INTO student(id,NAME,sex) VALUES(?,?,?)";
		
		List<Student> stus = new ArrayList<>();
		
		//添加student
		Student stu = new Student();
		stu.setId(921);
		stu.setName("Jss");
		stu.setSex("男");
		
		Student stu2 = new Student();
		stu2.setId(922);
		stu2.setName("Jss");
		stu2.setSex("男");

		Student stu3 = new Student();
		stu3.setId(923);
		stu3.setName("Jss");
		stu3.setSex("男");
		
		Student stu4 = new Student();
		stu4.setId(924);
		stu4.setName("Jss");
		stu4.setSex("男");
		
		stus.add(stu);
		stus.add(stu2);
		stus.add(stu3);
		stus.add(stu4);
		
		
		// 通过使用 addBatch()方法，将一组参数添加到此 Statement 对象的批处理命令中
		try {
			pstm = con.prepareStatement(sql);
			
			for(int i = 0; i < stus.size(); i++) {
				
				pstm.setInt(1, stus.get(i).getId());
				pstm.setString(2, stus.get(i).getName());
				pstm.setString(3, stus.get(i).getSex());
				
				//将存储的信息存起来
				pstm.addBatch();
			}

			// 执行语句
			int[] flag = pstm.executeBatch();

			System.out.println("执行成功的次数：" + flag.length);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			ConnectionFactory.closeConnection(null, pstm, con);
		}

	}

	public static void PreparedStatementTest() {
		// 获取连接
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement pstm = null;
		// sql 语句
		String sql1 = "INSERT INTO student(id,NAME,sex) VALUES('917','Jss01','男')";
		String sql2 = "INSERT INTO student(id,NAME,sex) VALUES('918','Jss02','男')";
		String sql3 = "INSERT INTO student(id,NAME,sex) VALUES('919','Jss03','男')";
		String sql4 = "INSERT INTO student(id,NAME,sex) VALUES('920','Jss04','男')";

		// 通过使用 addBatch()方法，将一组参数添加到此 Statement 对象的批处理命令中
		try {
			pstm = con.prepareStatement(sql2);

			// 使用 addBatch()方法
			pstm.addBatch(sql1);
			pstm.addBatch(sql2);
			pstm.addBatch(sql3);
			pstm.addBatch(sql4);

			// 执行语句
			int[] flag = pstm.executeBatch();

			System.out.println("执行成功的次数：" + flag.length);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			ConnectionFactory.closeConnection(null, pstm, con);
		}
	}

	public static void StatementTest() {
		// 获取连接
		Connection con = ConnectionFactory.getConnection();
		Statement stm = null;
		// sql 语句
		String sql1 = "INSERT INTO student(id,NAME,sex) VALUES('911','Jss01','男')";
		String sql2 = "INSERT INTO student(id,NAME,sex) VALUES('908','Jss02','男')";
		String sql3 = "INSERT INTO student(id,NAME,sex) VALUES('909','Jss03','男')";
		String sql4 = "INSERT INTO student(id,NAME,sex) VALUES('910','Jss04','男')";

		// 通过使用 addBatch()方法，将一组参数添加到此 Statement 对象的批处理命令中
		try {
			stm = con.createStatement();

			// 使用 addBatch()方法
			stm.addBatch(sql1);
			stm.addBatch(sql2);
			stm.addBatch(sql3);
			stm.addBatch(sql4);

			// 执行语句
			int[] flag = stm.executeBatch();

			System.out.println("执行成功的次数：" + flag.length);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			ConnectionFactory.closeConnection(null, stm, con);
		}

	}
}
