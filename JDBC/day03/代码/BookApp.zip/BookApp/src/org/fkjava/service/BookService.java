package org.fkjava.service;

import java.util.List;

import org.fkjava.bean.Book;
import org.fkjava.dao.BookDao;

public class BookService {
	
	BookDao bookDao = new BookDao();

	//获取所有的书籍信息
	public List<Book> findAllBooks(){
		
		return bookDao.findAllBooks();
	}
	
	//根据图书id来获取图书
	public Book getBookById(String id){
		
		return bookDao.getBookById(id);
	}
	
	//根据图书id来删除
	public void deleteBookById(String id){
		
		bookDao.deleteBookById(id);
	}


}
