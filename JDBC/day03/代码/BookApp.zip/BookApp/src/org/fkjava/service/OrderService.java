package org.fkjava.service;

import org.fkjava.bean.Item;
import org.fkjava.bean.Order;
import org.fkjava.dao.OrderDao;

public class OrderService {

	OrderDao orderDao = new OrderDao();
	
	public void saveOrder(Order order, Item item){
		
		orderDao.saveOrder(order, item);
	}
}
