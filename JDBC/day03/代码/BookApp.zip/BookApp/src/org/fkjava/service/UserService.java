package org.fkjava.service;

import org.fkjava.bean.User;
import org.fkjava.dao.UserDao;

public class UserService {
	
	UserDao userDao = new UserDao();
	
	public User findUserByNameAndPassWord(String username , String password){
		
		return userDao.findUserByNameAndPassWord(username, password);
	}
	
	public User findUserByName(String loginName){
		
		return userDao.findUserByName(loginName);
	}
	
	public void saveUser(User user){
		
		userDao.saveUser(user);
	}

}
