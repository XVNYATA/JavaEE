package org.fkjava.action;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.Item;
import org.fkjava.bean.Order;
import org.fkjava.bean.User;
import org.fkjava.dao.OrderDao;
import org.fkjava.service.OrderService;

/**
 * Servlet implementation class OrderServlet
 */
@WebServlet("/order.action")
public class OrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//获取订单相关信息
		//总价
		String totalPrice = request.getParameter("totalPrice");
		//id
		String bookId = request.getParameter("bookId");
		//数量
		String buyNum = request.getParameter("buyNum");
		
		if(totalPrice!=null&&!totalPrice.equals("")&&bookId!=null&&!bookId.equals("")&&buyNum!=null&&!buyNum.equals("")){
			//初始化 Order 订单对象
			Order order = new Order();
			//拼装订单号
			StringBuffer orderNO = new StringBuffer();
			//创建事件格式化
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
			orderNO.append("PO-").append(sdf.format(new Date()));
			order.setOrder_no(orderNO.toString());
			//设置创建时间
			order.setCruedate(new Date());
			//从session中获取用户信息
			User user = (User)request.getSession().getAttribute("session_user");
			order.setUser(user);
			//设置订单总额
			order.setMoney(Double.valueOf(totalPrice));
			
			//准备订单明细相关数据
			Item item = new Item();
			item.setBook_id(Integer.valueOf(bookId));
			item.setAmount(Integer.valueOf(buyNum));
			
			//OrderDao orderDao = new OrderDao();
			OrderService orderService = new OrderService();
			
			try {
				//保存订单
				//orderDao.saveOrder(order, item);
				orderService.saveOrder(order, item);
				
				request.setAttribute("message", "您订单成功了。");
			} catch (Exception e) {
				request.setAttribute("message", "您订单稍稍有问题了。");
			}
			request.getRequestDispatcher("/main.action").forward(request, response);
		}else {
			request.getRequestDispatcher("/main.action").forward(request, response);
		}
	}
}
