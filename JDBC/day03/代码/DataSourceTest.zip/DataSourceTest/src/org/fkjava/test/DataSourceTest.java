package org.fkjava.test;

import java.sql.Connection;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;

public class DataSourceTest {

	public static void main(String[] args) {
		
		//创建BasicDataSource的实现类
		BasicDataSource basicDataSource = new BasicDataSource();
		//设置数据库的驱动
		basicDataSource.setDriverClassName("com.mysql.jdbc.Driver");
		//设置连接的url地址
		basicDataSource.setUrl("jdbc:mysql://127.0.0.1:3306/bank");
		//设置数据库的用户名和密码
		basicDataSource.setUsername("root");
		basicDataSource.setPassword("123456");
		
		//设置最大的连接数
		basicDataSource.setMaxActive(4);
		//设置连接的保存数
		basicDataSource.setMaxIdle(3);
		//设置超时等待时间（单位是毫秒）
		basicDataSource.setMaxWait(5000);


		//获取连接
		try {
			Connection con1 = basicDataSource.getConnection();
			Connection con2 = basicDataSource.getConnection();
			Connection con3 = basicDataSource.getConnection();
			Connection con4 = basicDataSource.getConnection();
			System.out.println(con1);
			System.out.println(con2);
			System.out.println(con3);
			System.out.println(con4);
			System.out.println("---------------------");
			con1.close();
			con2.close();
			con3.close();
			con4.close();
	
			Connection con5 = basicDataSource.getConnection();
			Connection con6 = basicDataSource.getConnection();
			Connection con7 = basicDataSource.getConnection();
			Connection con8 = basicDataSource.getConnection();
			System.out.println(con5);
			System.out.println(con6);
			System.out.println(con7);
			System.out.println(con8);
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
