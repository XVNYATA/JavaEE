package org.fkjava.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.fkjava.util.ConnectionFactory;

public class Test {

	public static void main(String[] args) {
		
		transfer("001", "002", 5000);

	}

	private static void transfer(String formAccount, String toAccount, int amount) {

		// 获取连接
		Connection con = ConnectionFactory.getConnection();
		// sql语句
		// sqk1 -> 从某个账户中转出多少钱
		String sql1 = "update tb_card set amount = amount - ? where account = ?";
		// sqk2 -> 从某个账户中转出多少钱
		String sql2 = "update tb_card set amount = amount + ? where account = ?";

		try {
			
			//自动提交 -> 手动提交  （设置）
			con.setAutoCommit(false);
			
			//转账
			PreparedStatement pstm = con.prepareStatement(sql1);
			pstm.setInt(1, amount);
			pstm.setString(2, formAccount);
			
			//执行
			int i = pstm.executeUpdate();
			System.out.println("---------- 转账成功 -----------");
			
			int a = 50 / 0;
			
			//回滚 -> 复原   rollback();
			
			
			pstm = con.prepareStatement(sql2);
			pstm.setInt(1, amount);
			pstm.setString(2, toAccount);
			//执行
			int j = pstm.executeUpdate();
			
			System.out.println("---------- 收款成功 -----------");
			
			con.commit();
			
		} catch (SQLException e) {
			// 回滚数据
			try {
				con.rollback();
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}
