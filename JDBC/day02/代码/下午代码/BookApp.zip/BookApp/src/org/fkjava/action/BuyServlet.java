package org.fkjava.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.Book;
import org.fkjava.dao.BookDao;

/**
 * Servlet implementation class BuyServlet
 */
@WebServlet("/buy.action")
public class BuyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BuyServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// 根据id 获取图书
		String id = request.getParameter("id");
		String buyNum = request.getParameter("buyNum");
		
		System.out.println(id + buyNum);

		if (id != null && !id.equals("") && buyNum != null && !buyNum.equals("")) {

			BookDao bookDao = new BookDao();

			// 根据书籍 id 来获取图书
			Book book = bookDao.getBookById(id);
			// 计算金额，合计
			Double totalPrice = book.getPrice() * Integer.valueOf(buyNum);

			// 设置图书的数量
			book.setBuyNum(Integer.valueOf(buyNum));

			// 把信息丢到 request
			request.setAttribute("book", book);
			request.setAttribute("totalPrice", totalPrice);
			request.getRequestDispatcher("/WEB-INF/jsp/order.jsp").forward(request, response);
		} else {
			// 假设 id 和 buyNum 为空的话，调到首页重新挑选
			request.getRequestDispatcher("/main.action").forward(request, response);

		}

	}

}
