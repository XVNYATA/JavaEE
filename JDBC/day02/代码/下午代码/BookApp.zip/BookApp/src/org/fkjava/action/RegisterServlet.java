package org.fkjava.action;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.fkjava.bean.User;
import org.fkjava.dao.UserDao;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register.action")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String flag = request.getParameter("flag");
		
		if (flag != null && flag.equals("validUser")) {
			UserDao userDao = new UserDao();
			// 校验用户名是否存在
			// 获取用户名
			String loginName = request.getParameter("loginName");
			// 根据登录名判断用户是否存在
			User user = userDao.findUserByName(loginName);
			if (user != null) {
				response.getWriter().print("您输入的用户名已存在，请重新输入！");
			}

		} else if (flag != null && flag.equals("addUser")) {
			// 注册用户
			String loginname = request.getParameter("loginname");
			String userName = request.getParameter("username");
			String password = request.getParameter("password");
			User user = new User();
			user.setLoginname(loginname);
			user.setUsername(userName);
			user.setPassword(password);
			UserDao userDao = new UserDao();
			try {
				// 保存用户信息
				userDao.saveUser(user);
				request.setAttribute("message", "恭喜您，注册成功！");
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				request.setAttribute("message", "不好意思，注册失败！");
			}
			// 跳转至登录页面
			request.getRequestDispatcher("/login.jsp").forward(request, response);

		} else {
			// 跳转至注册页面
			request.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(request, response);
		}
	}
}

/*
 * // 跳转注册页面
 * request.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(request,
 * response);
 * 
 * String flag = request.getParameter("flag");
 * 
 * if (flag != null && flag.equals("validUser")) {
 * 
 * UserDao userDao = new UserDao(); // 获取用户名进行比较 String loginname =
 * request.getParameter("loginname"); User user =
 * userDao.findUserByName(loginname);
 * 
 * // 判断，如果用户存在则不允许输入 if (user != null) {
 * response.getWriter().println("您输入的用户名已经存在，请重新起名字。"); } } else if (flag !=
 * null && flag.equals("addUser")) { // 注册用户 String loginname =
 * request.getParameter("loginname"); String username =
 * request.getParameter("username"); String password =
 * request.getParameter("password"); // 因为要注册用户，所以给user的字段赋值 User user = new
 * User(); user.setLoginname(loginname); user.setUsername(username);
 * user.setPassword(password);
 * 
 * UserDao userDao = new UserDao(); try { // 存储用户 userDao.saveUser(user);
 * request.setAttribute("message", "恭喜你，注册成功"); } catch (Exception e) { // TODO:
 * handle exception request.setAttribute("message", "不好意思，注册失败"); }
 * 
 * // 注册之后，应该跳转登录页面 request.getRequestDispatcher("/login.jsp").forward(request,
 * response);
 * 
 * } else {
 * 
 * // 跳转注册页面 //
 * request.getRequestDispatcher("/WEB-INF/jsp/register.jsp").forward(request, //
 * response); }
 * 
 * }
 */
