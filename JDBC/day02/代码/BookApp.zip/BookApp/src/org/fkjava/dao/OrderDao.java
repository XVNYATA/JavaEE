package org.fkjava.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.fkjava.bean.Book;
import org.fkjava.bean.Item;
import org.fkjava.bean.Order;
import org.fkjava.util.ConnectionFactory;

import com.mysql.jdbc.Statement;

public class OrderDao {

	public void saveOrder(Order order, Item item) {
		// 获取连接
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement pstm = null;

		// sql语句
		String sql1 = "insert into tb_order(order_no,cruedate,user_id,money) values(?,?,?,?)";
		String sql2 = "insert into tb_item(book_id,order_id,amount) values(?,?,?)";

		try {
			// 将提交的方式设置为手动提交
			con.setAutoCommit(false);

			pstm = con.prepareStatement(sql1, Statement.RETURN_GENERATED_KEYS);
			// 设置值
			pstm.setString(1, order.getOrder_no());
			pstm.setDate(2, new java.sql.Date(order.getCruedate().getTime()));
			pstm.setInt(3, order.getUser().getId());
			pstm.setDouble(4, order.getMoney());
			// 执行
			int i = pstm.executeUpdate();
			// 获取自动生成的主键
			if (i > 0) {
				ResultSet rs = pstm.getGeneratedKeys();
				rs.next();
				int orderId = rs.getInt(1);
				System.out.println("orderId--->" + orderId);

				// 将id放入到 item
				item.setOrder_id(orderId);

				// 在 tb_item 表中插入数据
				pstm = con.prepareStatement(sql2);
				// 设置值
				pstm.setInt(1, item.getBook_id());
				pstm.setInt(2, item.getOrder_id());
				pstm.setInt(3, item.getAmount());

				// 执行
				pstm.executeUpdate();
			}

			// 提交事务
			con.commit();

		} catch (SQLException e) {

			try {
				con.rollback();
			} catch (Exception e2) {
				// TODO: handle exception
			}

		} finally {

			// 关闭连接
			ConnectionFactory.closeConnection(null, pstm, con);
		}

	}

}
